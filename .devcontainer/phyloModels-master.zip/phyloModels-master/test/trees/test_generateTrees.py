import unittest
__unittest = True

# Import the library for reading in trees
from ete3 import Tree

# Import functions that generate trees for testing
from phylomodels.trees import generate_treeFromFile
#TODO add more tests for generate_treeFromFile and its subfunctions
from phylomodels.trees import transform_joinTrees
#TODO add more tests for transform_joinTrees and its sufunctions
from phylomodels.trees import transform_transToPhyloTree
#TODO add more tests for transform_transToPhyloTree and its sufunctions
from phylomodels.trees import transform_downSample
#TODO add more tests for transform_transToPhyloTree and its sufunctions
from phylomodels.trees import transform_makeTreeBifurcating
#TODO add more tests for transform_transToPhyloTree and its sufunctions

# Import util function to help
#TODO write tests for these
from phylomodels.trees.utils.check_tree_equality import check_tree_equality
#from phylomodels.trees.utils.is_bifurcating import is_bifurcating

# Import pandas to read in line list
import pandas as pd
from numpy import nan

class test_generateTrees(unittest.TestCase):
    def setUp(self):
        self.fileName = 'lineListAB.csv'
        self.treeA = Tree('treeA.newick', format=1)
        self.treeB = Tree('treeB.newick', format=1)
        self.changeTimeToFloat(self.treeA)
        self.changeTimeToFloat(self.treeB)
        pass

    def changeTimeToFloat(self, tree):
        for node in tree.traverse():
            node.time = float(node.time)

    def tearDown(self):
        self.treeA = None
        self.treeB = None

    def test_read_treeFromLineList_singleTree(self):
        trees = generate_treeFromFile.generate_treeFromFile('lineListA.csv', fileType='lineList')
        passes = check_tree_equality(trees[0], self.treeA)
        self.assertTrue(passes, msg="Reading from line list tree A wrong (treeA.newick)")

    def test_read_treeFromLineList_features(self):
        trees = generate_treeFromFile.generate_treeFromFile('lineListB.csv', fileType='lineList', features=[])
        passes = not check_tree_equality(trees[0], self.treeB)
        self.assertTrue(passes, msg="Reading from line list tree B wrong")
        features = trees[0].children[0].features
        expected_features = ['name', 'dist', 'support', 'time', 'infectTime', 'id', 'timeInfected', 'infectedById', 'gender', 'neighborhood']
        passes = len(features) == len(expected_features)
        for feature in expected_features:
            passes &= feature in features
        self.assertTrue(passes, msg="Wrong features read in (treeB.newick)")


    def test_read_treeFromLineList_multiTree(self):
        trees = generate_treeFromFile.generate_treeFromFile(self.fileName, fileType='lineList')
        if trees[0].name[0] == 'A':
            passes = check_tree_equality(trees[0], self.treeA)
            self.assertTrue(passes, msg="Reading from line list tree A wrong (treeA.newick)")
            passes = check_tree_equality(trees[1], self.treeB)
            self.assertTrue(passes, msg="Reading from line list tree B wrong (treeB.newick)")
        else:
            passes = check_tree_equality(trees[1], self.treeA)
            self.assertTrue(passes, msg="Reading from line list tree A wrong (treeA.newick)")
            passes = check_tree_equality(trees[0], self.treeB)
            self.assertTrue(passes, msg="Reading from line list tree B wrong (treeB.newick)")

    def test_joinUsingConstantCoalescent(self):
        tree = transform_joinTrees.transform_joinTrees([self.treeA, self.treeB], method='constant_coalescent')
        self.assertTrue(len(tree.children)==2, msg="Wrong number of children for the root")
        treeA = self.treeA.copy('deepcopy')
        treeB = self.treeB.copy('deepcopy')
        if tree.children[0].name[0] == 'A':
            treeA.dist = tree.children[0].time - tree.time
            passes = check_tree_equality(tree.children[0], treeA)
            self.assertTrue(passes, msg="Subtree A is wrong in combined tree (treeA.newick)")
            passes = tree.children[0] != self.treeA
            self.assertTrue(passes, msg="Subtree A not a copy")
            treeB.dist = tree.children[1].time - tree.time
            passes = check_tree_equality(tree.children[1], treeB)
            self.assertTrue(passes, msg="Subtree B is wrong in combined tree (treeB.newick)")
            passes = tree.children[1] != self.treeB
            self.assertTrue(passes, msg="Subtree B not a copy")
        else:
            treeA.dist = tree.children[1].time - tree.time
            passes = check_tree_equality(tree.children[1], treeA)
            self.assertTrue(passes, msg="Subtree A is wrong in combined tree (treeA.newick)")
            passes = tree.children[1] != self.treeA
            self.assertTrue(passes, msg="Subtree A not a copy")
            treeB.dist = tree.children[0].time - tree.time
            passes = check_tree_equality(tree.children[0], treeB)
            self.assertTrue(passes, msg="Subtree B is wrong in combined tree (treeA.newick)")
            passes = tree.children[0] != self.treeB
            self.assertTrue(passes, msg="Subtree B not a copy")

    def test_getPopSize(self):
        N = transform_joinTrees.getPopSize([self.treeA])
        passes = round(N*52*12) == 44
        self.assertTrue(passes, msg="Population size for tree A is wrong.")
        N = transform_joinTrees.getPopSize([self.treeB])
        passes = round(N*52*2) == 12
        self.assertTrue(passes, msg="Population size for tree B is wrong.")

    def test_transform_transToPhyloTree(self):
        trees = generate_treeFromFile.generate_treeFromFile('lineListAB.csv', fileType='lineList', sampleTime='sampledTime')
        # Test tree A
        if trees[0].name[0] == 'A':
            idx = 0
        else:
            idx = 1
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[idx])
        treeA = Tree('treeA_phylo.newick', format=1)
        passes = check_tree_equality(tree, treeA)
        self.assertTrue(passes, msg="Phylo tree A is wrong (treeA_phylo.newick)")

        # Test tree B
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[~idx])
        treeB = Tree('treeB_phylo.newick', format=1)
        passes = check_tree_equality(tree, treeB)
        self.assertTrue(passes, msg="Phylo tree B is wrong (treeB_phylo.newick)")
        
    def test_partial_sampling(self):
        lineList = pd.read_csv('lineListAB.csv')
        sampledNodes = ['E','F','L','M','W','Z','H','I']
        lineList.loc[~lineList['id'].isin(sampledNodes), 'sampledTime'] = nan
        trees = generate_treeFromFile.read_treeFromLineList(lineList, fileType='lineList', sampleTime='sampledTime')
        # Test tree A
        if trees[0].name[0] == 'A':
            idx = 0
        else:
            idx = 1
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[idx])
        treeA = Tree('treeA_partialSample.newick', format=1)
        passes = check_tree_equality(tree, treeA)
        self.assertTrue(passes, msg="Partially sampled tree A is wrong (treeA_partialSample.newick)")

        # Test tree B
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[~idx])
        treeB = Tree('treeB_partialSample.newick', format=1)
        passes = check_tree_equality(tree, treeB)
        self.assertTrue(passes, msg="Partially sampled tree B is wrong (treeB_partialSample.newick)")

    def test_partial_sampling_import(self):
        lineList = pd.read_csv('lineListImports.csv')
        trees = generate_treeFromFile.read_treeFromLineList(lineList, fileType='lineList', sampleTime='sampledTime')

        for i, tree in enumerate(trees):
            trees[i] = transform_transToPhyloTree.transform_transToPhyloTree(tree)

        # Test the number of leaves
        tree = transform_joinTrees.transform_joinTrees(trees)
        passes = len(tree) == 4
        self.assertTrue(passes, msg="Partially sampled tree with many imports has the wrong number of leaves")

    def test_downSampling(self):
        lineList = pd.read_csv('lineListAB.csv')
        sampledNodes = ['E','F','L','M','W','Z','H','I']
        trees = generate_treeFromFile.read_treeFromLineList(lineList, fileType='lineList', sampleTime='sampledTime')
        # Test tree A
        if trees[0].name[0] == 'A':
            idx = 0
        else:
            idx = 1
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[idx])
        tree = transform_downSample.transform_downSample(tree, sampledNodes)
        treeA = Tree('treeA_downSample.newick', format=1)
        passes = check_tree_equality(tree, treeA)
        self.assertTrue(passes, msg="Down sampled tree A is wrong (treeA_partialSample.newick)")

        # Test tree B
        tree = transform_transToPhyloTree.transform_transToPhyloTree(trees[~idx])
        tree = transform_downSample.transform_downSample(tree, sampledNodes)
        treeB = Tree('treeB_downSample.newick', format=1)
        passes = check_tree_equality(tree, treeB)
        self.assertTrue(passes, msg="Down sampled tree B is wrong (treeB_partialSample.newick)")

    def test_makeBifurcating(self):
        tree = transform_joinTrees.transform_joinTrees([self.treeA, self.treeB], method='constant_coalescent')
        tree = transform_makeTreeBifurcating.transform_makeTreeBifurcating(tree) 
        self.assertTrue(len(tree.children)==2, msg="Wrong number of children for the root")
        treeA = Tree('treeA_bi.newick', format=1)
        treeB = Tree('treeB_bi.newick', format=1)
        if tree.children[0].name[0] == 'A':
            treeA.dist = tree.children[0].time - tree.time
            passes = check_tree_equality(tree.children[0], treeA)
            self.assertTrue(passes, msg="Subtree A is wrong in the bifurcating tree (treeA_bi.newick)")
            passes = tree.children[0] != self.treeA
            self.assertTrue(passes, msg="Subtree A not a copy")
            treeB.dist = tree.children[1].time - tree.time
            passes = check_tree_equality(tree.children[1], treeB)
            self.assertTrue(passes, msg="Subtree B is wrong in the bifurcating tree (treeB_bi.newick)")
            passes = tree.children[1] != self.treeB
            self.assertTrue(passes, msg="Subtree B not a copy")
        else:
            treeA.dist = tree.children[1].time - tree.time
            passes = check_tree_equality(tree.children[1], treeA)
            self.assertTrue(passes, msg="Subtree A is wrong in the bifurcating tree (treeA_bi.newick)")
            passes = tree.children[1] != self.treeA
            self.assertTrue(passes, msg="Subtree A not a copy")
            treeB.dist = tree.children[0].time - tree.time
            passes = check_tree_equality(tree.children[0], treeB)
            self.assertTrue(passes, msg="Subtree B is wrong in the bifurcating tree (treeB_bi.newick)")
            passes = tree.children[0] != self.treeB
            self.assertTrue(passes, msg="Subtree B not a copy")


if __name__ == "__main__":
    unittest.main()
