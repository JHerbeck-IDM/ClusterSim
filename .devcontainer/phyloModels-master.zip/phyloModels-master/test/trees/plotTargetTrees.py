#from phylomodels.trees.generate_treeFromFile import generate_treeFromFile
#from phylomodels.trees.transform_transToPhyloTree import transform_transToPhyloTree
from ete3 import faces, AttrFace, TreeStyle, Tree

def my_layout(node):
    if node.is_leaf():
         # If terminal node, draws its name
         name_face = AttrFace("name")
    else:
         # If internal node, draws label with smaller font size
         name_face = AttrFace("name", fsize=10)
    # Adds the name face to the image at the preferred position
    faces.add_face_to_node(name_face, node, column=0, position="branch-right")

ts = TreeStyle()
# Do not add leaf names automatically
ts.show_leaf_name = False
ts.show_branch_length = True
ts.scale = 5000
# Use my custom layout
ts.layout_fn = my_layout

# transmission trees
tree = Tree('treeA.newick', format=1)
tree.render('targetTreePlots/treeA.png', tree_style=ts)
tree = Tree('treeB.newick', format=1)
tree.render('targetTreePlots/treeB.png', tree_style=ts)

# phylogenetic trees
tree = Tree('treeA_phylo.newick', format=1)
tree.render('targetTreePlots/treeA_phylo.png', tree_style=ts)
tree = Tree('treeB_phylo.newick', format=1)
tree.render('targetTreePlots/treeB_phylo.png', tree_style=ts)

# partially sampled phylogenetic trees
tree = Tree('treeA_partialSample.newick', format=1)
tree.render('targetTreePlots/treeA_partialSample.png', tree_style=ts)
tree = Tree('treeB_partialSample.newick', format=1)
tree.render('targetTreePlots/treeB_partialSample.png', tree_style=ts)

# bifurcating trees
tree = Tree('treeA_bi.newick', format=1)
tree.render('targetTreePlots/treeA_bi.png', tree_style=ts)
tree = Tree('treeB_bi.newick', format=1)
tree.render('targetTreePlots/treeB_bi.png', tree_style=ts)