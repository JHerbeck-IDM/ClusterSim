import unittest
import xmlrunner

from calibration_historyMatching_sir.calibration_historyMatching_sir_test \
     import calibration_historyMatching_sir_test



class testPhyloModels( unittest.TestCase ):

    def test_calibration_historyMatching_sir( self ):
        self.assertTrue( calibration_historyMatching_sir_test() )



if __name__ == '__main__':
    with open('./phylomodels/test/unittest_results.xml', 'wb') as output:
        unittest.main(
            testRunner=xmlrunner.XMLTestRunner(output=output),
            failfast=False, buffer=False, catchbreak=False)

