=====
Test
=====

The *test* directory contains a battery of tests for validating numerical and/or
computational performance of library components.


File structure
==============

This directory is organized in subdirectories, with each subdirectory
containing one or more stand-alone tests (one test per file in the
subdirectory).


**Naming conventions.** Subdirectories should be named as follows::

  [type of test]_[main method/algorithm][_ other labels/description],

with:

* ``type of test`` assigning a category to the example. In general, categories
  refer to the main operation that is being verified in the test. Possible
  types of tests are:

* buildTree
* calibration_historyMatching_sir
* computeDegree
* features
* sampling


  Note that a test may use components from more than one module of the library.
  The type of test describes the *main* component that is being tested. It
  *does not* list all the modules/components that are being used in the test.

* ``main method/algorithm`` describing the main method or function that is being
  used in the test. For example, it can be the name of the initializer of a
  calibration method, or the name of a model contained in the models module,
  or a sampling strategy contained in the sampling module.

* ``other labels/description`` being any other string that completes the
  description of the test.



**Test functions.** There must be exactly one test per file. The entry point
of the file (i.e., the test function) is given by the name of the file and the
suffix ``_test``. This function should not receive any parameters and it must be
self-contained. All the code relevant to a given test should be inside the
corresponding test file (this requirement aids in defining tests that are short
and self-contained).

Each test must return a boolean state indicating if the test was successful or
if it failed.



phyloModels test script
=======================

The file `phylomodels_test.py` contains a script that executes all the tests
necessary for validating the correct installation/operation of the library.
Calls to any test that is considered important for library validation should
be added to this file.


