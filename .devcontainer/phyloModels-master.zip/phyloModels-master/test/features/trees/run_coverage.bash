#!/bin/bash
coverage run -m unittest discover
echo 'Creating HTML report'
coverage html
echo 'Running report...'
coverage report
