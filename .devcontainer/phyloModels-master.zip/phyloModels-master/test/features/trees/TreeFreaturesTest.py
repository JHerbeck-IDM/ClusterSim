import unittest
__unittest = True

from math import isinf, isnan
from abc import ABC, abstractmethod
# Import the library for reading in trees
from ete3 import Tree


class TreeFeaturesTest(unittest.TestCase, ABC):
    def setUp(self):
        self.define_tree_filename()
        self.tree = Tree(self.file_name + '.newick', format=1)
        with open(self.file_name + '.expVal', 'r') as dict_file:
            self.expected_values = eval(dict_file.read())
        self.tolerance = 5e-5
        self.expected_value = None
        self.calculated_value = None
        print(f"Running test for {self._testMethodName} with file_name = {self.file_name}")
        pass

    def tearDown(self):
        self.tree = None
        self.tolerance = 5e-5
        self.expected_value = None
        self.calculated_value = None

    @abstractmethod
    def define_tree_filename(self):
        """
                Actual tree filename is defined in each sub class.
        """
        self.file_name = None

    def is_within_tolerance(self):
        if isinf(self.calculated_value) and isinf(self.expected_value):
            return True
        if isnan(self.calculated_value) and isnan(self.expected_value):
            return True
        difference = abs(self.calculated_value - self.expected_value)
        if abs(self.expected_value) < self.tolerance:
            if difference < self.tolerance:
                return True
            else:
                return False
        else:
            if difference / self.expected_value < self.tolerance:
                return True
            else:
                return False

    def form_error_message(self, feature):
        msg = f"FEATURE: {feature} Calculated value: {self.calculated_value} out of tolerance ({self.tolerance}) of " \
              f"expected value: {self.expected_value}"
        return msg


class BITreeFeaturesTest(TreeFeaturesTest):
    def setUp(self):
        super(BITreeFeaturesTest, self).setUp()
        pass

    def define_tree_filename(self):
        self.file_name = 'biTree'


class FullTreeFeaturesTest(TreeFeaturesTest):
    def setUp(self):
        super(FullTreeFeaturesTest, self).setUp()
        pass

    def define_tree_filename(self):
        self.file_name = 'fullTree'


class AttrTreeFeaturesTest(TreeFeaturesTest):
    def setUp(self):
        super(AttrTreeFeaturesTest, self).setUp()
        pass

    def define_tree_filename(self):
        self.file_name = 'attrTree'


class UnhappyBITreeFeaturesTest(TreeFeaturesTest):
    def setUp(self):
        super(UnhappyBITreeFeaturesTest, self).setUp()
        pass

    def define_tree_filename(self):
        self.file_name = 'treefile/biTree'


class UnhappyFullTreeNegativeLength(TreeFeaturesTest):
    def setUp(self):
        self.define_tree_filename()
        self.tree = Tree(self.file_name + '.newick', format=1)
        print(f"Running test for {self._testMethodName} with file_name = {self.file_name}")
        pass

    def define_tree_filename(self):
        self.file_name = 'treefile/FullBiTree_negative_length'


class UnhappyFullTreeZeroLength(TreeFeaturesTest):
    def define_tree_filename(self):
        self.file_name = 'treefile/FullBiTree_zero_length'


class UnhappyFullTreeNanLength(TreeFeaturesTest):
    def setUp(self):
        self.define_tree_filename()
        print(f"Running test for {self._testMethodName} with file_name = {self.file_name}")
        pass
    def define_tree_filename(self):
        self.file_name = 'treefile/FullBiTree_nan_length'


class UnhappyNonBifurcatingTree(UnhappyFullTreeNegativeLength):
    def define_tree_filename(self):
        self.file_name = 'treefile/NonBifurcatingTree'


# class UnhappyFullTreeFeaturesTest(TreeFeaturesTest):
#     def setUp(self):
#         super(UnhappyFullTreeFeaturesTest, self).setUp()
#         pass
#
#     def define_tree_filename(self):
#         self.file_name = 'treefile/resultFullBiTree'



