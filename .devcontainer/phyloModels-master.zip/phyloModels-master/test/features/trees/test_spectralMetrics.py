from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Spectrum based summary statistics
from phylomodels.features.trees.spectral_calculate_min_adj_eigen import spectral_calculate_min_adj_eigen
from phylomodels.features.trees.spectral_calculate_max_adj_eigen import spectral_calculate_max_adj_eigen
from phylomodels.features.trees.spectral_calculate_min_lap_eigen import spectral_calculate_min_lap_eigen
from phylomodels.features.trees.spectral_calculate_max_lap_eigen import spectral_calculate_max_lap_eigen
from phylomodels.features.trees.spectral_calculate_max_distLap_eigen import spectral_calculate_max_distLap_eigen
from phylomodels.features.trees.spectral_calculate_eigen_gap import spectral_calculate_eigen_gap
from phylomodels.features.trees.spectral_calculate_skewness import spectral_calculate_skewness
from phylomodels.features.trees.spectral_calculate_kurtosis import spectral_calculate_kurtosis


class test_spectralMetrics_biTree(BITreeFeaturesTest):
    def test_spectral_calculate_min_adj_eigen(self):
        eigen = spectral_calculate_min_adj_eigen(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigenvalue_min_adj']
        self.expected_value = self.expected_values['eigenvalue_min_adj']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum (positive) eigenvalue of the (weighted) adjacency matrix"))

    def test_spectral_calculate_min_adj_eigen_topology(self):
        eigen = spectral_calculate_min_adj_eigen(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigenvalue_min_adj_topology']
        self.expected_value = self.expected_values['eigenvalue_min_adj_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum (positive) eigenvalue of the (unweighted) adjacency matrix"))

    def test_spectral_calculate_max_adj_eigen(self):
        eigen = spectral_calculate_max_adj_eigen(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_adj']
        self.expected_value = self.expected_values['eigenvalue_max_adj']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (weighted) adjacency matrix"))

    def test_spectral_calculate_max_adj_eigen_topology(self):
        eigen = spectral_calculate_max_adj_eigen(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_adj_topology']
        self.expected_value = self.expected_values['eigenvalue_max_adj_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (unweighted) adjacency matrix"))

    def test_spectral_calculate_min_lap_eigen(self):
        eigen = spectral_calculate_min_lap_eigen(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigenvalue_min_lap']
        self.expected_value = self.expected_values['eigenvalue_min_lap']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum (positive) eigenvalue of the (weighted) Laplacian matrix"))

    def test_spectral_calculate_min_lap_eigen_topology(self):
        eigen = spectral_calculate_min_lap_eigen(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigenvalue_min_lap_topology']
        self.expected_value = self.expected_values['eigenvalue_min_lap_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum (positive) eigenvalue of the (unweighted) Laplacian matrix"))

    def test_spectral_calculate_max_lap_eigen(self):
        eigen = spectral_calculate_max_lap_eigen(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_lap']
        self.expected_value = self.expected_values['eigenvalue_max_lap']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (weighted) Laplacian matrix"))

    def test_spectral_calculate_max_lap_eigen_topology(self):
        eigen = spectral_calculate_max_lap_eigen(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_lap_topology']
        self.expected_value = self.expected_values['eigenvalue_max_lap_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (unweighted) Laplacian matrix"))

    def test_spectral_calculate_max_distLap_eigen(self):
        eigen = spectral_calculate_max_distLap_eigen(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_dLap']
        self.expected_value = self.expected_values['eigenvalue_max_dLap']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (weighted) distance Laplacian matrix"))

    def test_spectral_calculate_max_distLap_eigen_topology(self):
        eigen = spectral_calculate_max_distLap_eigen(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigenvalue_max_dLap_topology']
        self.expected_value = self.expected_values['eigenvalue_max_dLap_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum (positive) eigenvalue of the (unweighted) distance Laplacian matrix"))

    def test_spectral_calculate_eigen_gap(self):
        eigen = spectral_calculate_eigen_gap(self.tree, topology_only=False)
        self.calculated_value = eigen.iloc[0]['eigen_gap']
        self.expected_value = self.expected_values['eigen_gap']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The size of the eigen gap of the spectral distrubition of the (weighted) distance Laplacian matrix"))

    def test_spectral_calculate_eigen_gap_topology(self):
        eigen = spectral_calculate_eigen_gap(self.tree, topology_only=True)
        self.calculated_value = eigen.iloc[0]['eigen_gap_topology']
        self.expected_value = self.expected_values['eigen_gap_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The size of the eigen gap of the spectral distrubition of the (unweighted) distance Laplacian matrix"))

    def test_spectral_calculate_skewness(self):
        mu3 = spectral_calculate_skewness(self.tree, topology_only=False)
        self.calculated_value = mu3.iloc[0]['skewness']
        self.expected_value = self.expected_values['skewness']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The skewness of the spectral distrubition of the (weighted) distance Laplacian matrix"))

    def test_spectral_calculate_skewness_topology(self):
        mu3 = spectral_calculate_skewness(self.tree, topology_only=True)
        self.calculated_value = mu3.iloc[0]['skewness_topology']
        self.expected_value = self.expected_values['skewness_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The skewness of the spectral distrubition of the (unweighted) distance Laplacian matrix"))

    def test_spectral_calculate_kurtosis(self):
        mu4 = spectral_calculate_kurtosis(self.tree, topology_only=False)
        self.calculated_value = mu4.iloc[0]['kurtosis']
        self.expected_value = self.expected_values['kurtosis']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The kurtosis of the spectral distrubition of the (weighted) distance Laplacian matrix"))

    def test_spectral_calculate_kurtosis_topology(self):
        mu4 = spectral_calculate_kurtosis(self.tree, topology_only=True)
        self.calculated_value = mu4.iloc[0]['kurtosis_topology']
        self.expected_value = self.expected_values['kurtosis_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("The kurtosis of the spectral distrubition of the (unweighted) distance Laplacian matrix"))


class test_spectralMetrics_attrTree(AttrTreeFeaturesTest, test_spectralMetrics_biTree):
    pass


class test_spectralMetrics_fullTree(FullTreeFeaturesTest, test_spectralMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
