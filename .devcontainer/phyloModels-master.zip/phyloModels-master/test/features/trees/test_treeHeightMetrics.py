from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Tree height summary statistics
from phylomodels.features.trees.tree_height_calculate_min import tree_height_calculate_min
from phylomodels.features.trees.tree_height_calculate_max import tree_height_calculate_max
from phylomodels.features.trees.tree_height_calculate_mean import tree_height_calculate_mean


class test_treeHeightMetrics_biTree(BITreeFeaturesTest):
    def test_min_height(self):
        min_H = tree_height_calculate_min(self.tree, normalize=False)
        self.calculated_value = min_H.iloc[0]['min_height']
        self.expected_value = self.expected_values['min_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum tree height"))

    def test_max_height(self):
        max_H = tree_height_calculate_max(self.tree, normalize=False)
        self.calculated_value = max_H.iloc[0]['max_height']
        self.expected_value = self.expected_values['max_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum tree height"))

    def test_mean_height(self):
        mean_H = tree_height_calculate_mean(self.tree, normalize=False)
        self.calculated_value = mean_H.iloc[0]['mean_height']
        self.expected_value = self.expected_values['mean_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height"))

    def test_min_height_topology(self):
        min_H = tree_height_calculate_min(self.tree, normalize=False, topology_only=True)
        self.calculated_value = min_H.iloc[0]['min_height_topology']
        self.expected_value = self.expected_values['min_height_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum tree height using topology"))

    def test_max_height_topology(self):
        max_H = tree_height_calculate_max(self.tree, normalize=False, topology_only=True)
        self.calculated_value = max_H.iloc[0]['max_height_topology']
        self.expected_value = self.expected_values['max_height_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum tree height using topology"))

    def test_mean_height_topology(self):
        mean_H = tree_height_calculate_mean(self.tree, normalize=False, topology_only=True)
        self.calculated_value = mean_H.iloc[0]['mean_height_topology']
        self.expected_value = self.expected_values['mean_height_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height using topology"))


class test_treeHeightMetrics_attrTree(AttrTreeFeaturesTest):
    def test_min_height(self):
        min_H = tree_height_calculate_min(self.tree, attr="population")
        self.calculated_value = min_H.iloc[0]['min_height']
        self.expected_value = self.expected_values['min_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum tree height (all)"))
        self.calculated_value = min_H.iloc[0]['min_height_A']
        self.expected_value = self.expected_values['min_height_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum tree height (population A)"))
        self.calculated_value = min_H.iloc[0]['min_height_B']
        self.expected_value = self.expected_values['min_height_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum tree height (population B)"))

    def test_max_height(self):
        max_H = tree_height_calculate_max(self.tree, attr="population", attr_values=['A'])
        self.calculated_value = max_H.iloc[0]['max_height']
        self.expected_value = self.expected_values['max_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum tree height (all)"))
        self.calculated_value = max_H.iloc[0]['max_height_A']
        self.expected_value = self.expected_values['max_height_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum tree height (population A)"))

    def test_mean_height(self):
        mean_H = tree_height_calculate_mean(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = mean_H.iloc[0]['mean_height']
        self.expected_value = self.expected_values['mean_height']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height (all)"))
        self.calculated_value = mean_H.iloc[0]['mean_height_A']
        self.expected_value = self.expected_values['mean_height_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height (population A)"))
        self.calculated_value = mean_H.iloc[0]['mean_height_B']
        self.expected_value = self.expected_values['mean_height_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height (population B)"))


class test_treeHeightMetrics_fullTree(FullTreeFeaturesTest, test_treeHeightMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
