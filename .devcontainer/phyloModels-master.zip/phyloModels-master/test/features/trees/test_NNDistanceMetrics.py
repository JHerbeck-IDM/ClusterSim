from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Nearest neighbor distance summary statistics
from phylomodels.features.trees.mean_NN_distance import mean_NN_distance

class test_NNDistanceMetrics_biTree(BITreeFeaturesTest):
    def test_mean_NN_distance(self):
        mean_dist = mean_NN_distance(self.tree)
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist']
        self.expected_value = self.expected_values['mean_NN_dist']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance"))

    def test_mean_NN_topology(self):
        mean_dist = mean_NN_distance(self.tree, topology_only=True)
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_topology']
        self.expected_value = self.expected_values['mean_NN_dist_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance using topology"))


class test_NNDistanceMetrics_attrTree(AttrTreeFeaturesTest):
    def test_mean_NN_distance(self):
        mean_dist = mean_NN_distance(self.tree, attr="population")
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist']
        self.expected_value = self.expected_values['mean_NN_dist']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance (all)"))
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_A']
        self.expected_value = self.expected_values['mean_NN_dist_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance (population A)"))
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_B']
        self.expected_value = self.expected_values['mean_NN_dist_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance (population B)"))

    def test_mean_NN_distance_topology(self):
        mean_dist = mean_NN_distance(self.tree, attr="population", attr_values=['A','B'], topology_only=True)
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_topology']
        self.expected_value = self.expected_values['mean_NN_dist_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance using topology (all)"))
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_topology_A']
        self.expected_value = self.expected_values['mean_NN_dist_topology_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance using topology (population A)"))
        self.calculated_value = mean_dist.iloc[0]['mean_NN_dist_topology_B']
        self.expected_value = self.expected_values['mean_NN_dist_topology_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean nearest neighbor distance using topology (population B)"))


class test_NNDistanceMetrics_fullTree(FullTreeFeaturesTest, test_NNDistanceMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
