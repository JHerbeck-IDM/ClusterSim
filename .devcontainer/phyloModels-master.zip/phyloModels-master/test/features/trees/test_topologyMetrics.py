from TreeFreaturesTest import *

## Import the summary statistics to be tested
# Topology based summary statistics
from phylomodels.features.trees.top_calculate_colless import top_calculate_colless
from phylomodels.features.trees.top_calculate_sackin import top_calculate_sackin
from phylomodels.features.trees.top_calculate_sackin_var import top_calculate_sackin_var
from phylomodels.features.trees.top_calculate_frac_imbalance import top_calculate_frac_imbalance
from phylomodels.features.trees.top_calculate_mean_imbalance_ratio import top_calculate_mean_imbalance_ratio
from phylomodels.features.trees.top_calculate_frac_ladder import top_calculate_frac_ladder
from phylomodels.features.trees.top_calculate_max_ladder import top_calculate_max_ladder
from phylomodels.features.trees.top_calculate_max_dW import top_calculate_max_dW
from phylomodels.features.trees.top_calculate_WD_ratio import top_calculate_WD_ratio
from phylomodels.features.trees.top_calculate_FurnasR import top_calculate_FurnasR
from phylomodels.features.trees.top_calculate_B1 import top_calculate_B1
from phylomodels.features.trees.top_calculate_B2 import top_calculate_B2


class test_topologyMetrics_biTree(BITreeFeaturesTest):
    def test_top_calculate_colless(self):
        C = top_calculate_colless(self.tree, normalize=False)
        self.calculated_value = C.iloc[0]['colless']
        self.expected_value = self.expected_values['colless']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Colless metric"))

    def test_top_calculate_sackin(self):
        S = top_calculate_sackin(self.tree, normalize=False)
        self.calculated_value = S.iloc[0]['sackin']
        self.expected_value = self.expected_values['sackin']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric"))

    def test_top_calculate_sackin_var(self):
        S = top_calculate_sackin_var(self.tree)
        self.calculated_value = S.iloc[0]['sackin_var']
        self.expected_value = self.expected_values['sackin_var']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric variance"))

    def test_top_calculate_frac_imbalance(self):
        imbalance = top_calculate_frac_imbalance(self.tree)
        self.calculated_value = imbalance.iloc[0]['frac_imbalance']
        self.expected_value = self.expected_values['frac_imbalance']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of internal nodes that are imbalanced"))

    def test_top_calculate_mean_imbalance_ratio(self):
        imbalance = top_calculate_mean_imbalance_ratio(self.tree)
        self.calculated_value = imbalance.iloc[0]['mean_imbalance_ratio']
        self.expected_value = self.expected_values['mean_imbalance_ratio']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean ratio of number of leaves on the right vs left (imbalance)"))

    def test_top_calculate_frac_ladder(self):
        ladder = top_calculate_frac_ladder(self.tree)
        self.calculated_value = ladder.iloc[0]['frac_ladder']
        self.expected_value = self.expected_values['frac_ladder']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of nodes in ladders"))

    def test_top_calculate_max_ladder(self):
        ladder = top_calculate_max_ladder(self.tree)
        self.calculated_value = ladder.iloc[0]['max_ladder']
        self.expected_value = self.expected_values['max_ladder']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of nodes in largest ladder"))

    def test_top_calculate_max_dW(self):
        dW = top_calculate_max_dW(self.tree)
        self.calculated_value = dW.iloc[0]['max_dW']
        self.expected_value = self.expected_values['max_dW']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum difference in widths between depths"))

    def test_top_calculate_WD_ratio(self):
        ratio = top_calculate_WD_ratio(self.tree)
        self.calculated_value = ratio.iloc[0]['WD_ratio']
        self.expected_value = self.expected_values['WD_ratio']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Max width to depth ratio"))

    def test_top_calculate_FurnasR(self):
        R = top_calculate_FurnasR(self.tree)
        self.calculated_value = R.iloc[0]['Furnas_R']
        self.expected_value = self.expected_values['Furnas_R']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Furnas ranking"))

    def test_top_calculate_B1(self):
        B_1 = top_calculate_B1(self.tree, normalize=False)
        self.calculated_value = B_1.iloc[0]['B1']
        self.expected_value = self.expected_values['B1']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B1 statistic"))

    def test_top_calculate_B2(self):
        B_2 = top_calculate_B2(self.tree, normalize=False)
        self.calculated_value = B_2.iloc[0]['B2']
        self.expected_value = self.expected_values['B2']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B2 statistic"))


class test_topologyMetrics_attrTree(AttrTreeFeaturesTest):
    def test_top_calculate_colless(self):
        C = top_calculate_colless(self.tree, attr="population")
        self.calculated_value = C.iloc[0]['colless']
        self.expected_value = self.expected_values['colless']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Colless metric (all)"))
        self.calculated_value = C.iloc[0]['colless_A']
        self.expected_value = self.expected_values['colless_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Colless metric (population A)"))
        self.calculated_value = C.iloc[0]['colless_B']
        self.expected_value = self.expected_values['colless_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Colless metric (population B)"))

    def test_top_calculate_sackin(self):
        S = top_calculate_sackin(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = S.iloc[0]['sackin']
        self.expected_value = self.expected_values['sackin']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric (all)"))
        self.calculated_value = S.iloc[0]['sackin_A']
        self.expected_value = self.expected_values['sackin_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric (population A)"))
        self.calculated_value = S.iloc[0]['sackin_B']
        self.expected_value = self.expected_values['sackin_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric (population B)"))

    def test_top_calculate_sackin_var(self):
        S = top_calculate_sackin_var(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = S.iloc[0]['sackin_var']
        self.expected_value = self.expected_values['sackin_var']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric variance (all)"))
        self.calculated_value = S.iloc[0]['sackin_var_A']
        self.expected_value = self.expected_values['sackin_var_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric variance (population A)"))
        self.calculated_value = S.iloc[0]['sackin_var_B']
        self.expected_value = self.expected_values['sackin_var_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Sackin metric variance (population B)"))

    def test_top_calculate_frac_imbalance(self):
        imbalance = top_calculate_frac_imbalance(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = imbalance.iloc[0]['frac_imbalance']
        self.expected_value = self.expected_values['frac_imbalance']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of nodes that are imbalanced (all)"))
        self.calculated_value = imbalance.iloc[0]['frac_imbalance_A']
        self.expected_value = self.expected_values['frac_imbalance_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height (population A)"))
        self.calculated_value = imbalance.iloc[0]['frac_imbalance_B']
        self.expected_value = self.expected_values['frac_imbalance_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean tree height (population B)"))

    def test_top_calculate_mean_imbalance_ratio(self):
        imbalance = top_calculate_mean_imbalance_ratio(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = imbalance.iloc[0]['mean_imbalance_ratio']
        self.expected_value = self.expected_values['mean_imbalance_ratio']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean ratio of right leaves to left leaves (all)"))
        self.calculated_value = imbalance.iloc[0]['mean_imbalance_ratio_A']
        self.expected_value = self.expected_values['mean_imbalance_ratio_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean ratio of right leaves to left leaves (A)"))
        self.calculated_value = imbalance.iloc[0]['mean_imbalance_ratio_B']
        self.expected_value = self.expected_values['mean_imbalance_ratio_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean ratio of right leaves to left leaves (population B)"))

    def test_top_calculate_frac_ladder(self):
        ladder = top_calculate_frac_ladder(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = ladder.iloc[0]['frac_ladder']
        self.expected_value = self.expected_values['frac_ladder']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of nodes that are in ladders (all)"))
        self.calculated_value = ladder.iloc[0]['frac_ladder_A']
        self.expected_value = self.expected_values['frac_ladder_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of nodes that are in ladders (population A)"))
        self.calculated_value = ladder.iloc[0]['frac_ladder_B']
        self.expected_value = self.expected_values['frac_ladder_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of nodes that are in ladders (population B)"))

    def test_top_calculate_max_ladder(self):
        ladder = top_calculate_max_ladder(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = ladder.iloc[0]['max_ladder']
        self.expected_value = self.expected_values['max_ladder']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of nodes in the largest ladder (all)"))
        self.calculated_value = ladder.iloc[0]['max_ladder_A']
        self.expected_value = self.expected_values['max_ladder_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of nodes in the largest ladder (population A)"))
        self.calculated_value = ladder.iloc[0]['max_ladder_B']
        self.expected_value = self.expected_values['max_ladder_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of nodes tin the largest ladders (population B)"))

    def test_top_calculate_B1(self):
        B_1 = top_calculate_B1(self.tree, attr="population")
        self.calculated_value = B_1.iloc[0]['B1']
        self.expected_value = self.expected_values['B1']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B1 statistic (all)"))
        self.calculated_value = B_1.iloc[0]['B1_A']
        self.expected_value = self.expected_values['B1_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B1 statistic (population A)"))
        self.calculated_value = B_1.iloc[0]['B1_B']
        self.expected_value = self.expected_values['B1_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B1 statistic (population B)"))

    def test_top_calculate_B2(self):
        B_2 = top_calculate_B2(self.tree, attr="population")
        self.calculated_value = B_2.iloc[0]['B2']
        self.expected_value = self.expected_values['B2']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B2 statistic (all)"))
        self.calculated_value = B_2.iloc[0]['B2_A']
        self.expected_value = self.expected_values['B2_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B2 statistic (population A)"))
        self.calculated_value = B_2.iloc[0]['B2_B']
        self.expected_value = self.expected_values['B2_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("B2 statistic (population B)"))


class test_topologyMetrics_fullTree(FullTreeFeaturesTest, test_topologyMetrics_biTree):
    def test_top_calculate_FurnasR(self):
        try:
            R = top_calculate_FurnasR(self.tree)
        except Exception as e:
            self.assertTrue(True, msg=self.form_error_message("Furnas ranking"))
        else:
            self.assertTrue(False, msg=self.form_error_message("Furnas ranking"))


if __name__ == "__main__":
    import unittest
    unittest.main()
