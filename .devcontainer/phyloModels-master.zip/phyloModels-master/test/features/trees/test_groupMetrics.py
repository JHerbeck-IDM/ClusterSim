from TreeFreaturesTest import *

## Import the summary statistics to be tested
# Group based summary statistics
from phylomodels.features.trees.group_calculate_max import group_calculate_max
from phylomodels.features.trees.group_calculate_mean import group_calculate_mean
from phylomodels.features.trees.group_calculate_median import group_calculate_median
from phylomodels.features.trees.group_calculate_min import group_calculate_min
from phylomodels.features.trees.group_calculate_mode import group_calculate_mode
from phylomodels.features.trees.group_calculate_num import group_calculate_num
from phylomodels.features.trees.group_calculate_std import group_calculate_std
#TODO need a better example tree for testing these
#TODO these metrics probably need some sort of normalization


class test_clusterMetrics_biTree(BITreeFeaturesTest):
    def test_group_calculate_num(self):
        group_calculate_number = group_calculate_num(self.tree, normalize=False)
        self.calculated_value = group_calculate_number.iloc[0]['group_num']
        self.expected_value = self.expected_values['group_num']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of groups"))

    def test_group_calculate_max(self):
        max_size = group_calculate_max(self.tree, normalize=False)
        self.calculated_value = max_size.iloc[0]['group_max']
        self.expected_value = self.expected_values['group_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum group size"))

    def test_group_calculate_min(self):
        min_size = group_calculate_min(self.tree, normalize=False)
        self.calculated_value = min_size.iloc[0]['group_min']
        self.expected_value = self.expected_values['group_min']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum group size"))

    def test_group_calculate_mean(self):
        mean_size = group_calculate_mean(self.tree, normalize=False)
        self.calculated_value = mean_size.iloc[0]['group_mean']
        self.expected_value = self.expected_values['group_mean']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean group size"))

    def test_group_calculate_median(self):
        median_size = group_calculate_median(self.tree, normalize=False)
        self.calculated_value = median_size.iloc[0]['group_median']
        self.expected_value = self.expected_values['group_median']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median group size"))

    def test_group_calculate_mode(self):
        mode_size = group_calculate_mode(self.tree, normalize=False)
        self.calculated_value = mode_size.iloc[0]['group_mode']
        self.expected_value = self.expected_values['group_mode']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mode of group sizes"))

    def test_group_calculate_std(self):
        std_size = group_calculate_std(self.tree, normalize=False)
        self.calculated_value = std_size.iloc[0]['group_std']
        self.expected_value = self.expected_values['group_std']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of group sizes"))


class test_clusterMetrics_attrTree(AttrTreeFeaturesTest):
    def test_group_calculate_num(self):
        group_calculate_number = group_calculate_num(self.tree, attr="population")
        self.calculated_value = group_calculate_number.iloc[0]['group_num']
        self.expected_value = self.expected_values['group_num']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of groups (all)"))
        self.calculated_value = group_calculate_number.iloc[0]['group_num_A']
        self.expected_value = self.expected_values['group_num_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of groups (population A)"))
        self.calculated_value = group_calculate_number.iloc[0]['group_num_B']
        self.expected_value = self.expected_values['group_num_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of groups (population B)"))

    def test_group_calculate_max(self):
        max_size = group_calculate_max(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = max_size.iloc[0]['group_max']
        self.expected_value = self.expected_values['group_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum group size (all)"))
        self.calculated_value = max_size.iloc[0]['group_max_A']
        self.expected_value = self.expected_values['group_max_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum group size (population A)"))
        self.calculated_value = max_size.iloc[0]['group_max_B']
        self.expected_value = self.expected_values['group_max_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum group size (population B)"))

    def test_group_calculate_min(self):
        min_size = group_calculate_min(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = min_size.iloc[0]['group_min']
        self.expected_value = self.expected_values['group_min']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum group size (all)"))
        self.calculated_value = min_size.iloc[0]['group_min_A']
        self.expected_value = self.expected_values['group_min_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum group size (population A)"))
        self.calculated_value = min_size.iloc[0]['group_min_B']
        self.expected_value = self.expected_values['group_min_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum group size (population B)"))

    def test_group_calculate_mean(self):
        mean_size = group_calculate_mean(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = mean_size.iloc[0]['group_mean']
        self.expected_value = self.expected_values['group_mean']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean group size (all)"))
        self.calculated_value = mean_size.iloc[0]['group_mean_A']
        self.expected_value = self.expected_values['group_mean_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean group size (A)"))
        self.calculated_value = mean_size.iloc[0]['group_mean_B']
        self.expected_value = self.expected_values['group_mean_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean group size (population B)"))

    def test_group_calculate_median(self):
        median_size = group_calculate_median(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = median_size.iloc[0]['group_median']
        self.expected_value = self.expected_values['group_median']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median group size (all)"))
        self.calculated_value = median_size.iloc[0]['group_median_A']
        self.expected_value = self.expected_values['group_median_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median group size (population A)"))
        self.calculated_value = median_size.iloc[0]['group_median_B']
        self.expected_value = self.expected_values['group_median_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median group size (population B)"))

    def test_group_calculate_mode(self):
        mode_size = group_calculate_mode(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = mode_size.iloc[0]['group_mode']
        self.expected_value = self.expected_values['group_mode']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mode of group sizes (all)"))
        self.calculated_value = mode_size.iloc[0]['group_mode_A']
        self.expected_value = self.expected_values['group_mode_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mode of group sizes (population A)"))
        self.calculated_value = mode_size.iloc[0]['group_mode_B']
        self.expected_value = self.expected_values['group_mode_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mode of group sizes (population B)"))

    def test_group_calculate_std(self):
        std_size = group_calculate_std(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = std_size.iloc[0]['group_std']
        self.expected_value = self.expected_values['group_std']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of group sizes (all)"))
        self.calculated_value = std_size.iloc[0]['group_std_A']
        self.expected_value = self.expected_values['group_std_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of group sizes (population A)"))
        self.calculated_value = std_size.iloc[0]['group_std_B']
        self.expected_value = self.expected_values['group_std_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of group sizes (population B)"))


class test_clusterMetrics_fullTree(FullTreeFeaturesTest, test_clusterMetrics_biTree):
    pass


# class test_clusterMetrics_fullTree_unhappy_tests(UnhappyFullTreeFeaturesTest, test_clusterMetrics_biTree):
#     def test_group_calculate_num(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_num(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_max(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_max(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_min(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_min(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_mean(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_mean(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_median(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_median(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_mode(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_mode(self)
#         self.assertTrue('False is not true' in str(context.exception))
#
#     def test_group_calculate_std(self):
#         with self.assertRaises(Exception) as context:
#             test_clusterMetrics_biTree.test_group_calculate_std(self)
#         self.assertTrue('False is not true' in str(context.exception))


if __name__ == "__main__":
    import unittest
    unittest.main()
