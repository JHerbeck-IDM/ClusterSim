import math
from numpy import amax
from numpy import amin

from TreeFreaturesTest import *

## Import the summary statistics to be tested
from phylomodels.features.trees.helper.calculate_branch_length_metrics import calculate_branch_length_metrics
from phylomodels.features.trees.calculate_external_branch_length_metrics import calculate_external_branch_length_metrics
# All branch length  summary statistics
from phylomodels.features.trees.BL_calculate_min import BL_calculate_min
from phylomodels.features.trees.BL_calculate_max import BL_calculate_max
from phylomodels.features.trees.BL_calculate_mean import BL_calculate_mean
from phylomodels.features.trees.BL_calculate_median import BL_calculate_median
from phylomodels.features.trees.BL_calculate_std import BL_calculate_std
# External branch length  summary statistics
from phylomodels.features.trees.BL_calculate_external_min import BL_calculate_external_min
from phylomodels.features.trees.BL_calculate_external_max import BL_calculate_external_max
from phylomodels.features.trees.BL_calculate_external_mean import BL_calculate_external_mean
from phylomodels.features.trees.BL_calculate_external_median import BL_calculate_external_median
from phylomodels.features.trees.BL_calculate_external_std import BL_calculate_external_std
# Internal branch length  summary statistics
from phylomodels.features.trees.BL_calculate_internal_min import BL_calculate_internal_min
from phylomodels.features.trees.BL_calculate_internal_max import BL_calculate_internal_max
from phylomodels.features.trees.BL_calculate_internal_mean import BL_calculate_internal_mean
from phylomodels.features.trees.BL_calculate_internal_median import BL_calculate_internal_median
from phylomodels.features.trees.BL_calculate_internal_std import BL_calculate_internal_std
# Ratio of internal and external branch length  summary statistics
from phylomodels.features.trees.BL_calculate_ratio_min import BL_calculate_ratio_min
from phylomodels.features.trees.BL_calculate_ratio_max import BL_calculate_ratio_max
from phylomodels.features.trees.BL_calculate_ratio_mean import BL_calculate_ratio_mean
from phylomodels.features.trees.BL_calculate_ratio_median import BL_calculate_ratio_median
from phylomodels.features.trees.BL_calculate_ratio_std import BL_calculate_ratio_std


class test_branchLengthMetrics_biTree(BITreeFeaturesTest):
    def test_min_branch_length(self):
        BL_metric = BL_calculate_min(self.tree)
        self.calculated_value = BL_metric.iloc[0]['min_branch_length']
        self.expected_value = self.expected_values['min_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum branch length"))

    def test_max_branch_length(self):
        BL_metric = BL_calculate_max(self.tree)
        self.calculated_value = BL_metric.iloc[0]['max_branch_length']
        self.expected_value = self.expected_values['max_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum branch length"))

    def test_mean_branch_length(self):
        BL_metric = BL_calculate_mean(self.tree)
        self.calculated_value = BL_metric.iloc[0]['mean_branch_length']
        self.expected_value = self.expected_values['mean_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean branch length"))

    def test_median_branch_length(self):
        BL_metric = BL_calculate_median(self.tree)
        self.calculated_value = BL_metric.iloc[0]['median_branch_length']
        self.expected_value = self.expected_values['median_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median branch length"))

    def test_std_branch_length(self):
        BL_metric = BL_calculate_std(self.tree)
        self.calculated_value = BL_metric.iloc[0]['std_branch_length']
        self.expected_value = self.expected_values['std_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of branch length"))

    def test_min_ex_branch_length(self):
        BL_metric = BL_calculate_external_min(self.tree)
        self.calculated_value = BL_metric.iloc[0]['min_ex_branch_length']
        self.expected_value = self.expected_values['min_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum external branch length"))

    def test_max_ex_branch_length(self):
        BL_metric = BL_calculate_external_max(self.tree)
        self.calculated_value = BL_metric.iloc[0]['max_ex_branch_length']
        self.expected_value = self.expected_values['max_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum external branch length"))

    def test_mean_ex_branch_length(self):
        BL_metric = BL_calculate_external_mean(self.tree)
        self.calculated_value = BL_metric.iloc[0]['mean_ex_branch_length']
        self.expected_value = self.expected_values['mean_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean external branch length"))

    def test_median_ex_branch_length(self):
        BL_metric = BL_calculate_external_median(self.tree)
        self.calculated_value = BL_metric.iloc[0]['median_ex_branch_length']
        self.expected_value = self.expected_values['median_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median external branch length"))

    def test_std_ex_branch_length(self):
        BL_metric = BL_calculate_external_std(self.tree)
        self.calculated_value = BL_metric.iloc[0]['std_ex_branch_length']
        self.expected_value = self.expected_values['std_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of external branch lengths"))

    def test_min_in_branch_length(self):
        min_BL = BL_calculate_internal_min(self.tree)
        self.calculated_value = min_BL.iloc[0]['min_in_branch_length']
        self.expected_value = self.expected_values['min_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum internal branch length"))

    def test_max_in_branch_length(self):
        max_BL = BL_calculate_internal_max(self.tree)
        self.calculated_value = max_BL.iloc[0]['max_in_branch_length']
        self.expected_value = self.expected_values['max_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum internal branch length"))

    def test_mean_in_branch_length(self):
        mean_BL = BL_calculate_internal_mean(self.tree)
        self.calculated_value = mean_BL.iloc[0]['mean_in_branch_length']
        self.expected_value = self.expected_values['mean_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean internal branch length"))

    def test_median_in_branch_length(self):
        median_BL = BL_calculate_internal_median(self.tree)
        self.calculated_value = median_BL.iloc[0]['median_in_branch_length']
        self.expected_value = self.expected_values['median_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median internal branch length"))

    def test_std_in_branch_length(self):
        std_BL = BL_calculate_internal_std(self.tree)
        self.calculated_value = std_BL.iloc[0]['std_in_branch_length']
        self.expected_value = self.expected_values['std_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of internal branch lengths"))

    def test_min_branch_length_ratio(self):
        min_BL = BL_calculate_ratio_min(self.tree)
        self.calculated_value = min_BL.iloc[0]['min_ratio_branch_length']
        self.expected_value = self.expected_values['min_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of minimum branch lengths"))

    def test_max_branch_length_ratio(self):
        max_BL = BL_calculate_ratio_max(self.tree)
        self.calculated_value = max_BL.iloc[0]['max_ratio_branch_length']
        self.expected_value = self.expected_values['max_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of maximum branch lengths"))

    def test_mean_branch_length_ratio(self):
        mean_BL = BL_calculate_ratio_mean(self.tree)
        self.calculated_value = mean_BL.iloc[0]['mean_ratio_branch_length']
        self.expected_value = self.expected_values['mean_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of mean branch lengths"))

    def test_median_branch_length_ratio(self):
        median_BL = BL_calculate_ratio_median(self.tree)
        self.calculated_value = median_BL.iloc[0]['median_ratio_branch_length']
        self.expected_value = self.expected_values['median_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of median branch lengths"))

    def test_std_branch_length_ratio(self):
        std_BL = BL_calculate_ratio_std(self.tree)
        self.calculated_value = std_BL.iloc[0]['std_ratio_branch_length']
        self.expected_value = self.expected_values['std_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of standard deviation of branch lengths"))


class test_branchLengthMetrics_attrTree(AttrTreeFeaturesTest):
    def test_min_branch_length(self):
        BL_metric = BL_calculate_min(self.tree, attr="population")
        self.calculated_value = BL_metric.iloc[0]['min_branch_length']
        self.expected_value = self.expected_values['min_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['min_branch_length_A']
        self.expected_value = self.expected_values['min_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['min_branch_length_B']
        self.expected_value = self.expected_values['min_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum branch length (population B)"))

    def test_max_branch_length(self):
        BL_metric = BL_calculate_max(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['max_branch_length']
        self.expected_value = self.expected_values['max_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['max_branch_length_A']
        self.expected_value = self.expected_values['max_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['max_branch_length_B']
        self.expected_value = self.expected_values['max_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum branch length (population B)"))

    def test_mean_branch_length(self):
        BL_metric = BL_calculate_mean(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['mean_branch_length']
        self.expected_value = self.expected_values['mean_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['mean_branch_length_A']
        self.expected_value = self.expected_values['mean_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['mean_branch_length_B']
        self.expected_value = self.expected_values['mean_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean branch length (population B)"))

    def test_median_branch_length(self):
        BL_metric = BL_calculate_median(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['median_branch_length']
        self.expected_value = self.expected_values['median_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['median_branch_length_A']
        self.expected_value = self.expected_values['median_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['median_branch_length_B']
        self.expected_value = self.expected_values['median_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median branch length (population B)"))

    def test_std_branch_length(self):
        BL_metric = BL_calculate_std(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['std_branch_length']
        self.expected_value = self.expected_values['std_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of branch lengths (all)"))
        self.calculated_value = BL_metric.iloc[0]['std_branch_length_A']
        self.expected_value = self.expected_values['std_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of branch lengths (population A)"))
        self.calculated_value = BL_metric.iloc[0]['std_branch_length_B']
        self.expected_value = self.expected_values['std_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of branch lengths (population B)"))

    def test_min_ex_branch_length(self):
        BL_metric = BL_calculate_external_min(self.tree, attr="population")
        self.calculated_value = BL_metric.iloc[0]['min_ex_branch_length']
        self.expected_value = self.expected_values['min_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum external branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['min_ex_branch_length_A']
        self.expected_value = self.expected_values['min_ex_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum external branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['min_ex_branch_length_B']
        self.expected_value = self.expected_values['min_ex_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum external branch length (population B)"))

    def test_max_ex_branch_length(self):
        BL_metric = BL_calculate_external_max(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['max_ex_branch_length']
        self.expected_value = self.expected_values['max_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum external branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['max_ex_branch_length_A']
        self.expected_value = self.expected_values['max_ex_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum external branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['max_ex_branch_length_B']
        self.expected_value = self.expected_values['max_ex_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum external branch length (population B)"))

    def test_mean_ex_branch_length(self):
        BL_metric = BL_calculate_external_mean(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['mean_ex_branch_length']
        self.expected_value = self.expected_values['mean_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean external branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['mean_ex_branch_length_A']
        self.expected_value = self.expected_values['mean_ex_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean external branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['mean_ex_branch_length_B']
        self.expected_value = self.expected_values['mean_ex_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean external branch length (population B)"))

    def test_median_ex_branch_length(self):
        BL_metric = BL_calculate_external_median(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['median_ex_branch_length']
        self.expected_value = self.expected_values['median_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median external branch length (all)"))
        self.calculated_value = BL_metric.iloc[0]['median_ex_branch_length_A']
        self.expected_value = self.expected_values['median_ex_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median external branch length (population A)"))
        self.calculated_value = BL_metric.iloc[0]['median_ex_branch_length_B']
        self.expected_value = self.expected_values['median_ex_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median external branch length (population B)"))

    def test_std_ex_branch_length(self):
        BL_metric = BL_calculate_external_std(self.tree, attr="population", attr_values=['A','B'])
        self.calculated_value = BL_metric.iloc[0]['std_ex_branch_length']
        self.expected_value = self.expected_values['std_ex_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of external branch lengths (all)"))
        self.calculated_value = BL_metric.iloc[0]['std_ex_branch_length_A']
        self.expected_value = self.expected_values['std_ex_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of external branch lengths (A)"))
        self.calculated_value = BL_metric.iloc[0]['std_ex_branch_length_B']
        self.expected_value = self.expected_values['std_ex_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of external branch lengths (B)"))

    def test_min_in_branch_length(self):
        min_BL = BL_calculate_internal_min(self.tree, attr="population")
        self.calculated_value = min_BL.iloc[0]['min_in_branch_length']
        self.expected_value = self.expected_values['min_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum internal branch length (all)"))
        self.calculated_value = min_BL.iloc[0]['min_in_branch_length_A']
        self.expected_value = self.expected_values['min_in_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum internal branch length (population A)"))
        self.calculated_value = min_BL.iloc[0]['min_in_branch_length_B']
        self.expected_value = self.expected_values['min_in_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Minimum internal branch length (population B)"))

    def test_max_in_branch_length(self):
        max_BL = BL_calculate_internal_max(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = max_BL.iloc[0]['max_in_branch_length']
        self.expected_value = self.expected_values['max_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum internal branch length (all)"))
        self.calculated_value = max_BL.iloc[0]['max_in_branch_length_A']
        self.expected_value = self.expected_values['max_in_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum internal branch length (population A)"))
        self.calculated_value = max_BL.iloc[0]['max_in_branch_length_B']
        self.expected_value = self.expected_values['max_in_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum internal branch length (population B)"))

    def test_mean_in_branch_length(self):
        mean_BL = BL_calculate_internal_mean(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = mean_BL.iloc[0]['mean_in_branch_length']
        self.expected_value = self.expected_values['mean_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean internal branch length (all)"))
        self.calculated_value = mean_BL.iloc[0]['mean_in_branch_length_A']
        self.expected_value = self.expected_values['mean_in_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean internal branch length (population A)"))
        self.calculated_value = mean_BL.iloc[0]['mean_in_branch_length_B']
        self.expected_value = self.expected_values['mean_in_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean internal branch length (population B)"))

    def test_median_in_branch_length(self):
        median_BL = BL_calculate_internal_median(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = median_BL.iloc[0]['median_in_branch_length']
        self.expected_value = self.expected_values['median_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median internal branch length (all)"))
        self.calculated_value = median_BL.iloc[0]['median_in_branch_length_A']
        self.expected_value = self.expected_values['median_in_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median internal branch length (population A)"))
        self.calculated_value = median_BL.iloc[0]['median_in_branch_length_B']
        self.expected_value = self.expected_values['median_in_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Median internal branch length (population B)"))

    def test_std_in_branch_length(self):
        std_BL = BL_calculate_internal_std(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = std_BL.iloc[0]['std_in_branch_length']
        self.expected_value = self.expected_values['std_in_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of internal branch lengths (all)"))
        self.calculated_value = std_BL.iloc[0]['std_in_branch_length_A']
        self.expected_value = self.expected_values['std_in_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of internal branch lengths (A)"))
        self.calculated_value = std_BL.iloc[0]['std_in_branch_length_B']
        self.expected_value = self.expected_values['std_in_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Standard deviation of internal branch lengths (B)"))

    def test_min_branch_length_ratio(self):
        min_BL = BL_calculate_ratio_min(self.tree, attr="population")
        self.calculated_value = min_BL.iloc[0]['min_ratio_branch_length']
        self.expected_value = self.expected_values['min_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of minimum branch lengths (all)"))
        self.calculated_value = min_BL.iloc[0]['min_ratio_branch_length_A']
        self.expected_value = self.expected_values['min_ratio_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of minimum branch lengths (population A)"))
        self.calculated_value = min_BL.iloc[0]['min_ratio_branch_length_B']
        self.expected_value = self.expected_values['min_ratio_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of minimum branch lengths (population B)"))

    def test_max_branch_length_ratio(self):
        max_BL = BL_calculate_ratio_max(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = max_BL.iloc[0]['max_ratio_branch_length']
        self.expected_value = self.expected_values['max_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of maximum branch lengths (all)"))
        self.calculated_value = max_BL.iloc[0]['max_ratio_branch_length_A']
        self.expected_value = self.expected_values['max_ratio_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of maximum branch lengths (population A)"))
        self.calculated_value = max_BL.iloc[0]['max_ratio_branch_length_B']
        self.expected_value = self.expected_values['max_ratio_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of maximum branch lengths (population B)"))

    def test_mean_branch_length_ratio(self):
        mean_BL = BL_calculate_ratio_mean(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = mean_BL.iloc[0]['mean_ratio_branch_length']
        self.expected_value = self.expected_values['mean_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of mean branch lengths (all)"))
        self.calculated_value = mean_BL.iloc[0]['mean_ratio_branch_length_A']
        self.expected_value = self.expected_values['mean_ratio_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of mean branch lengths (population A)"))
        self.calculated_value = mean_BL.iloc[0]['mean_ratio_branch_length_B']
        self.expected_value = self.expected_values['mean_ratio_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of mean branch lengths (population B)"))

    def test_median_branch_length_ratio(self):
        median_BL = BL_calculate_ratio_median(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = median_BL.iloc[0]['median_ratio_branch_length']
        self.expected_value = self.expected_values['median_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of median branch lengths (all)"))
        self.calculated_value = median_BL.iloc[0]['median_ratio_branch_length_A']
        self.expected_value = self.expected_values['median_ratio_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of median branch lengths (population A)"))
        self.calculated_value = median_BL.iloc[0]['median_ratio_branch_length_B']
        self.expected_value = self.expected_values['median_ratio_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of median branch length (population B)"))

    def test_std_branch_length_ratio(self):
        std_BL = BL_calculate_ratio_std(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = std_BL.iloc[0]['std_ratio_branch_length']
        self.expected_value = self.expected_values['std_ratio_branch_length']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of standard deviation of branch lengths (all)"))
        self.calculated_value = std_BL.iloc[0]['std_ratio_branch_length_A']
        self.expected_value = self.expected_values['std_ratio_branch_length_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of standard deviation of branch lengths (A)"))
        self.calculated_value = std_BL.iloc[0]['std_ratio_branch_length_B']
        self.expected_value = self.expected_values['std_ratio_branch_length_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of standard deviation of branch lengths (B)"))


class test_branchLengthMetrics_fullTree(FullTreeFeaturesTest, test_branchLengthMetrics_biTree):
    pass


class test_branchLengthMetrics_biTree_unhappy_tests(UnhappyBITreeFeaturesTest, test_branchLengthMetrics_biTree):
    """
    treefile/biTree.newick is has the same structure as biTree.newick with only 2 of the branch lengths are different.
    The tests for max_**, mean_**, std_** should return a different value while most of min_** will remain the same(0.0).
    """
    def test_min_branch_length(self):
        test_branchLengthMetrics_biTree.test_min_branch_length(self)

    def test_max_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_max_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_mean_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_mean_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_median_branch_length(self):
        test_branchLengthMetrics_biTree.test_median_branch_length(self)

    def test_std_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_std_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_min_ex_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_min_ex_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_max_ex_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_max_ex_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_mean_ex_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_mean_ex_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_median_ex_branch_length(self):
        test_branchLengthMetrics_biTree.test_median_ex_branch_length(self)

    def test_std_ex_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_std_ex_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_min_in_branch_length(self):
        test_branchLengthMetrics_biTree.test_min_in_branch_length(self)

    def test_max_in_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_max_in_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_mean_in_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_mean_in_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_median_in_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_median_in_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_std_in_branch_length(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_std_in_branch_length(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_min_branch_length_ratio(self):
        test_branchLengthMetrics_biTree.test_min_branch_length_ratio(self)

    def test_max_branch_length_ratio(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_max_branch_length_ratio(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_mean_branch_length_ratio(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_mean_branch_length_ratio(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_median_branch_length_ratio(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_median_branch_length_ratio(self)
        self.assertTrue('False is not true' in str(context.exception))

    def test_std_branch_length_ratio(self):
        with self.assertRaises(Exception) as context:
            test_branchLengthMetrics_biTree.test_std_branch_length_ratio(self)
        self.assertTrue('False is not true' in str(context.exception))

    pass


class test_branchLengthMetrics_negative_length(UnhappyFullTreeNegativeLength):
    def test_min_branch_length(self):
        with self.assertRaises(Exception) as context:
            # should throw exception about negative branch length
            min_BL = calculate_branch_length_metrics(self.tree, functions_dict={'min': amin})
        self.assertTrue('< 0' in str(context.exception))


class test_branchLengthMetrics_zero_length(UnhappyFullTreeZeroLength, test_branchLengthMetrics_biTree):
    # overwrite how to test the ratios

    def test_max_branch_length_ratio(self):
        max_BL = BL_calculate_ratio_max(self.tree)
        self.calculated_value = max_BL.iloc[0]['max_ratio_branch_length']
        self.expected_value = self.expected_values['max_ratio_branch_length']
        #passes = math.isnan(self.calculated_value)
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of maximum branch lengths"))

    def test_mean_branch_length_ratio(self):
        mean_BL = BL_calculate_ratio_mean(self.tree)
        self.calculated_value = mean_BL.iloc[0]['mean_ratio_branch_length']
        self.expected_value = self.expected_values['mean_ratio_branch_length']
        #passes = math.isnan(self.calculated_value)
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of mean branch lengths"))

    def test_median_branch_length_ratio(self):
        median_BL = BL_calculate_ratio_median(self.tree)
        self.calculated_value = median_BL.iloc[0]['median_ratio_branch_length']
        self.expected_value = self.expected_values['median_ratio_branch_length']
        #passes = math.isnan(self.calculated_value)
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of median branch lengths"))

    def test_std_branch_length_ratio(self):
        std_BL = BL_calculate_ratio_std(self.tree)
        self.calculated_value = std_BL.iloc[0]['std_ratio_branch_length']
        self.expected_value = self.expected_values['std_ratio_branch_length']
        #passes = math.isnan(self.calculated_value)
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Ratio of standard deviation of branch lengths"))

    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
