from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Small configuration based summary statistics
from phylomodels.features.trees.smallConfig_calculate_cherries import smallConfig_calculate_cherries
from phylomodels.features.trees.smallConfig_calculate_double_cherries import smallConfig_calculate_double_cherries
from phylomodels.features.trees.smallConfig_calculate_pitchforks import smallConfig_calculate_pitchforks
from phylomodels.features.trees.smallConfig_calculate_fourprong import smallConfig_calculate_fourprong
#TODO these metrics probably need some sort of normalization


class test_smallConfigurationMetrics_biTree(BITreeFeaturesTest):
    def test_smallConfig_calculate_cherries(self):
        cherry_num = smallConfig_calculate_cherries(self.tree, normalize=False)
        self.calculated_value = cherry_num.iloc[0]['cherries']
        self.expected_value = self.expected_values['cherries']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of cherries"))

    def test_smallConfig_calculate_double_cherries(self):
        double_cherry_num = smallConfig_calculate_double_cherries(self.tree, normalize=False)
        self.calculated_value = double_cherry_num.iloc[0]['double_cherries']
        self.expected_value = self.expected_values['double_cherries']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of double cherries"))

    def test_smallConfig_calculate_pitchforks(self):
        pitchfork_num = smallConfig_calculate_pitchforks(self.tree, normalize=False)
        self.calculated_value = pitchfork_num.iloc[0]['pitchforks']
        self.expected_value = self.expected_values['pitchforks']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of pitchforks"))

    def test_smallConfig_calculate_fourprong(self):
        fourprong_num = smallConfig_calculate_fourprong(self.tree, normalize=False)
        self.calculated_value = fourprong_num.iloc[0]['fourprong']
        self.expected_value = self.expected_values['fourprong']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of 4-caterpillars"))


class test_smallConfigurationMetrics_attrTree(AttrTreeFeaturesTest):
    def test_smallConfig_calculate_cherries(self):
        cherry_num = smallConfig_calculate_cherries(self.tree, attr="population")
        self.calculated_value = cherry_num.iloc[0]['cherries']
        self.expected_value = self.expected_values['cherries']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of cherries (all)"))
        self.calculated_value = cherry_num.iloc[0]['cherries_A']
        self.expected_value = self.expected_values['cherries_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of cherries (population A)"))
        self.calculated_value = cherry_num.iloc[0]['cherries_B']
        self.expected_value = self.expected_values['cherries_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of cherries (population B)"))

    def test_smallConfig_calculate_double_cherries(self):
        double_cherry_num = smallConfig_calculate_double_cherries(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = double_cherry_num.iloc[0]['double_cherries']
        self.expected_value = self.expected_values['double_cherries']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of double cherries (all)"))
        self.calculated_value = double_cherry_num.iloc[0]['double_cherries_A']
        self.expected_value = self.expected_values['double_cherries_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of double cherries (population A)"))
        self.calculated_value = double_cherry_num.iloc[0]['double_cherries_B']
        self.expected_value = self.expected_values['double_cherries_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of double cherries (population B)"))

    def test_smallConfig_calculate_pitchforks(self):
        pitchfork_num = smallConfig_calculate_pitchforks(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = pitchfork_num.iloc[0]['pitchforks']
        self.expected_value = self.expected_values['pitchforks']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of pitchforks (all)"))
        self.calculated_value = pitchfork_num.iloc[0]['pitchforks_A']
        self.expected_value = self.expected_values['pitchforks_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of pitchforks (population A)"))
        self.calculated_value = pitchfork_num.iloc[0]['pitchforks_B']
        self.expected_value = self.expected_values['pitchforks_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of pitchforks (population B)"))

    def test_smallConfig_calculate_fourprong(self):
        fourprong_num = smallConfig_calculate_fourprong(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = fourprong_num.iloc[0]['fourprong']
        self.expected_value = self.expected_values['fourprong']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of 4-caterpillars (all)"))
        self.calculated_value = fourprong_num.iloc[0]['fourprong_A']
        self.expected_value = self.expected_values['fourprong_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of 4-caterpillars (population A)"))
        self.calculated_value = fourprong_num.iloc[0]['fourprong_B']
        self.expected_value = self.expected_values['fourprong_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Number of 4-caterpillars (population B)"))


class test_smallConfigurationMetrics_fullTree(FullTreeFeaturesTest, test_smallConfigurationMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
