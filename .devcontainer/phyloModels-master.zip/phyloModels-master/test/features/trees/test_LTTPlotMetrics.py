from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Lineage through time (LTT) summary statistics
from phylomodels.features.trees.LTT_calculate_max_lineages import LTT_calculate_max_lineages
from phylomodels.features.trees.LTT_calculate_t_max_lineages import LTT_calculate_t_max_lineages
from phylomodels.features.trees.LTT_calculate_mean_b_time import LTT_calculate_mean_b_time
from phylomodels.features.trees.LTT_calculate_mean_s_time import LTT_calculate_mean_s_time
from phylomodels.features.trees.LTT_calculate_slope_1 import LTT_calculate_slope_1
from phylomodels.features.trees.LTT_calculate_slope_2 import LTT_calculate_slope_2
from phylomodels.features.trees.LTT_calculate_slope_ratio import LTT_calculate_slope_ratio


class test_LTTPlotMetrics_biTree(BITreeFeaturesTest):
    def test_LTT_calculate_max_lineages(self):
        max_L = LTT_calculate_max_lineages(self.tree)
        self.calculated_value = max_L.iloc[0]['max_lineages']
        self.expected_value = self.expected_values['max_lineages']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum lineages"))

    def test_LTT_calculate_t_max_lineages(self):
        t_max_L = LTT_calculate_t_max_lineages(self.tree)
        self.calculated_value = t_max_L.iloc[0]['t_max_lineages']
        self.expected_value = self.expected_values['t_max_lineages']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Time of maximum lineages"))

    def test_LTT_calculate_mean_b_time(self):
        mean_b_time = LTT_calculate_mean_b_time(self.tree)
        self.calculated_value = mean_b_time.iloc[0]['mean_b_time']
        self.expected_value = self.expected_values['mean_b_time']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean branching time"))

    def test_LTT_calculate_mean_s_time(self):
        mean_s_time = LTT_calculate_mean_s_time(self.tree)
        self.calculated_value = mean_s_time.iloc[0]['mean_s_time']
        self.expected_value = self.expected_values['mean_s_time']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean sampling time"))

    def test_LTT_calculate_slope_1(self):
        slope_1 = LTT_calculate_slope_1(self.tree)
        self.calculated_value = slope_1.iloc[0]['slope_1']
        self.expected_value = self.expected_values['slope_1']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("LTT slope 1"))

    def test_LTT_calculate_slope_2(self):
        slope_2 = LTT_calculate_slope_2(self.tree)
        self.calculated_value = slope_2.iloc[0]['slope_2']
        self.expected_value = self.expected_values['slope_2']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("LTT slope 2"))

    def test_LTT_calculate_slope_ratio(self):
        slope_ratio = LTT_calculate_slope_ratio(self.tree)
        self.calculated_value = slope_ratio.iloc[0]['slope_ratio']
        self.expected_value = self.expected_values['slope_ratio']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("LTT slope ratio"))


class test_LTTPlotMetrics_attrTree(AttrTreeFeaturesTest, test_LTTPlotMetrics_biTree):
    pass


class test_LTTPlotMetrics_fullTree(FullTreeFeaturesTest, test_LTTPlotMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
