from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Local based summary statistics
from phylomodels.features.trees.local_calculate_LBI_mean import local_calculate_LBI_mean
from phylomodels.features.trees.local_calculate_frac_basal import local_calculate_frac_basal


class test_localMetrics_biTree(BITreeFeaturesTest):
    def test_local_calculate_LBI_mean(self):
        LBI = local_calculate_LBI_mean(self.tree)
        self.calculated_value = LBI.iloc[0]['mean_LBI']
        self.expected_value = self.expected_values['mean_LBI']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean local branching index"))

    def test_local_calculate_frac_basal(self):
        basal = local_calculate_frac_basal(self.tree, topology_only=True)
        self.calculated_value = basal.iloc[0]['frac_basal']
        self.expected_value = self.expected_values['frac_basal']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of leaves that are basal opposed to terminal"))


class test_localMetrics_attrTree(AttrTreeFeaturesTest):
    def test_local_calculate_LBI_mean(self):
        LBI = local_calculate_LBI_mean(self.tree, attr="population")
        self.calculated_value = LBI.iloc[0]['mean_LBI']
        self.expected_value = self.expected_values['mean_LBI']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean local branching index (all)"))
        self.calculated_value = LBI.iloc[0]['mean_LBI_A']
        self.expected_value = self.expected_values['mean_LBI_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean local branching index (population A)"))
        self.calculated_value = LBI.iloc[0]['mean_LBI_B']
        self.expected_value = self.expected_values['mean_LBI_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean local branching index (population B)"))

    def test_local_calculate_frac_basal(self):
        basal = local_calculate_frac_basal(self.tree, attr="population", attr_values=['A','B'], topology_only=True)
        self.calculated_value = basal.iloc[0]['frac_basal']
        self.expected_value = self.expected_values['frac_basal']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of leaves that are basal opposed to terminal (all)"))
        self.calculated_value = basal.iloc[0]['frac_basal_A']
        self.expected_value = self.expected_values['frac_basal_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of leaves that are basal opposed to terminal (population A)"))
        self.calculated_value = basal.iloc[0]['frac_basal_B']
        self.expected_value = self.expected_values['frac_basal_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Fraction of leaves that are basal opposed to terminal (population B)"))


class test_localMetrics_fullTree(FullTreeFeaturesTest):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
