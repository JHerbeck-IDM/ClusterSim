from TreeFreaturesTest import BITreeFeaturesTest, FullTreeFeaturesTest, AttrTreeFeaturesTest

## Import the summary statistics to be tested
# Network science based summary statistics
from phylomodels.features.trees.netSci_calculate_betweenness_max import netSci_calculate_betweenness_max
from phylomodels.features.trees.netSci_calculate_closeness_max import netSci_calculate_closeness_max
from phylomodels.features.trees.netSci_calculate_eigen_centrality_max import netSci_calculate_eigen_centrality_max
from phylomodels.features.trees.netSci_calculate_diameter import netSci_calculate_diameter
from phylomodels.features.trees.netSci_calculate_mean_path import netSci_calculate_mean_path

class test_networkScienceMetrics_biTree(BITreeFeaturesTest):
    def test_netSci_calculate_betweenness_max(self):
        betweenness = netSci_calculate_betweenness_max(self.tree)
        self.calculated_value = betweenness.iloc[0]['betweenness_max']
        self.expected_value = self.expected_values['betweenness_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum betweenness value"))

    def test_netSci_calculate_closeness_max(self):
        closeness = netSci_calculate_closeness_max(self.tree)
        self.calculated_value = closeness.iloc[0]['closeness_max']
        self.expected_value = self.expected_values['closeness_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value"))

    def test_netSci_calculate_closeness_max_topology(self):
        closeness = netSci_calculate_closeness_max(self.tree, topology_only=True)
        self.calculated_value = closeness.iloc[0]['closeness_max_topology']
        self.expected_value = self.expected_values['closeness_max_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value"))

    def test_netSci_calculate_eigen_centrality_max(self):
        eigenvector = netSci_calculate_eigen_centrality_max(self.tree)
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max']
        self.expected_value = self.expected_values['eigenvector_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector"))

    def test_netSci_calculate_eigen_centrality_max_unweighted(self):
        eigenvector = netSci_calculate_eigen_centrality_max(self.tree, topology_only=True)
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_unweighted']
        self.expected_value = self.expected_values['eigenvector_max_unweighted']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector"))

    def test_netSci_calculate_diameter(self):
        dia = netSci_calculate_diameter(self.tree)
        self.calculated_value = dia.iloc[0]['diameter']
        self.expected_value = self.expected_values['diameter']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) using branch lengths"))

    def test_netSci_calculate_diameter_topology(self):
        dia = netSci_calculate_diameter(self.tree, topology_only=True)
        self.calculated_value = dia.iloc[0]['diameter_topology']
        self.expected_value = self.expected_values['diameter_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) not using branch lengths"))

    def test_netSci_calculate_mean_path(self):
        path_length = netSci_calculate_mean_path(self.tree)
        self.calculated_value = path_length.iloc[0]['mean_path']
        self.expected_value = self.expected_values['mean_path']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) using branch lengths"))

    def test_netSci_calculate_mean_path_topology(self):
        path_length = netSci_calculate_mean_path(self.tree, topology_only=True)
        self.calculated_value = path_length.iloc[0]['mean_path_topology']
        self.expected_value = self.expected_values['mean_path_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) not using branch lengths"))


class test_networkScienceMetrics_attrTree(AttrTreeFeaturesTest):
    def test_netSci_calculate_betweenness_max(self):
        betweenness = netSci_calculate_betweenness_max(self.tree, attr="population")
        self.calculated_value = betweenness.iloc[0]['betweenness_max']
        self.expected_value = self.expected_values['betweenness_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum betweenness value (all)"))
        self.calculated_value = betweenness.iloc[0]['betweenness_max_A']
        self.expected_value = self.expected_values['betweenness_max_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum betweenness value (population A)"))
        self.calculated_value = betweenness.iloc[0]['betweenness_max_B']
        self.expected_value = self.expected_values['betweenness_max_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum betweenness value (population B)"))

    def test_netSci_calculate_closeness_max(self):
        closeness = netSci_calculate_closeness_max(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = closeness.iloc[0]['closeness_max']
        self.expected_value = self.expected_values['closeness_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (all)"))
        self.calculated_value = closeness.iloc[0]['closeness_max_A']
        self.expected_value = self.expected_values['closeness_max_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (population A)"))
        self.calculated_value = closeness.iloc[0]['closeness_max_B']
        self.expected_value = self.expected_values['closeness_max_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (population B)"))

    def test_netSci_calculate_closeness_max_topology(self):
        closeness = netSci_calculate_closeness_max(self.tree, attr="population", attr_values=['A', 'B'], topology_only=True)
        self.calculated_value = closeness.iloc[0]['closeness_max_topology']
        self.expected_value = self.expected_values['closeness_max_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (all)"))
        self.calculated_value = closeness.iloc[0]['closeness_max_topology_A']
        self.expected_value = self.expected_values['closeness_max_topology_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (population A)"))
        self.calculated_value = closeness.iloc[0]['closeness_max_topology_B']
        self.expected_value = self.expected_values['closeness_max_topology_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum closeness value (population B)"))

    def test_netSci_calculate_eigen_centrality_max(self):
        eigenvector = netSci_calculate_eigen_centrality_max(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max']
        self.expected_value = self.expected_values['eigenvector_max']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (all)"))
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_A']
        self.expected_value = self.expected_values['eigenvector_max_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (population A)"))
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_B']
        self.expected_value = self.expected_values['eigenvector_max_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (population B)"))

    def test_netSci_calculate_eigen_centrality_max_unweighted(self):
        eigenvector = netSci_calculate_eigen_centrality_max(self.tree, attr="population", attr_values=['A', 'B'], topology_only=True)
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_unweighted']
        self.expected_value = self.expected_values['eigenvector_max_unweighted']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (all)"))
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_unweighted_A']
        self.expected_value = self.expected_values['eigenvector_max_unweighted_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (population A)"))
        self.calculated_value = eigenvector.iloc[0]['eigenvector_max_unweighted_B']
        self.expected_value = self.expected_values['eigenvector_max_unweighted_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Maximum value from the Perron-Frobenius eigenvector (population B)"))

    def test_netSci_calculate_diameter(self):
        dia = netSci_calculate_diameter(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = dia.iloc[0]['diameter']
        self.expected_value = self.expected_values['diameter']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) using branch lengths (all)"))
        self.calculated_value = dia.iloc[0]['diameter_A']
        self.expected_value = self.expected_values['diameter_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) using branch lengths (population A)"))
        self.calculated_value = dia.iloc[0]['diameter_B']
        self.expected_value = self.expected_values['diameter_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) using branch lengths (population B)"))

    def test_netSci_calculate_diameter_topology(self):
        dia = netSci_calculate_diameter(self.tree, attr="population", attr_values=['A', 'B'], topology_only=True)
        self.calculated_value = dia.iloc[0]['diameter_topology']
        self.expected_value = self.expected_values['diameter_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) not using branch lengths (all)"))
        self.calculated_value = dia.iloc[0]['diameter_topology_A']
        self.expected_value = self.expected_values['diameter_topology_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) not using branch lengths (population A)"))
        self.calculated_value = dia.iloc[0]['diameter_topology_B']
        self.expected_value = self.expected_values['diameter_topology_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Diameter of the graph (tree) not using branch lengths (population B)"))

    def test_netSci_calculate_mean_path(self):
        path_length = netSci_calculate_mean_path(self.tree, attr="population", attr_values=['A', 'B'])
        self.calculated_value = path_length.iloc[0]['mean_path']
        self.expected_value = self.expected_values['mean_path']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) using branch lengths (all)"))
        self.calculated_value = path_length.iloc[0]['mean_path_A']
        self.expected_value = self.expected_values['mean_path_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) using branch lengths (population A)"))
        self.calculated_value = path_length.iloc[0]['mean_path_B']
        self.expected_value = self.expected_values['mean_path_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) using branch lengths (population B)"))

    def test_netSci_calculate_mean_path_topology(self):
        path_length = netSci_calculate_mean_path(self.tree, attr="population", attr_values=['A', 'B'], topology_only=True)
        self.calculated_value = path_length.iloc[0]['mean_path_topology']
        self.expected_value = self.expected_values['mean_path_topology']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) not using branch lengths (all)"))
        self.calculated_value = path_length.iloc[0]['mean_path_topology_A']
        self.expected_value = self.expected_values['mean_path_topology_A']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) not using branch lengths (population A)"))
        self.calculated_value = path_length.iloc[0]['mean_path_topology_B']
        self.expected_value = self.expected_values['mean_path_topology_B']
        passes = self.is_within_tolerance()
        self.assertTrue(passes, msg=self.form_error_message("Mean path through the graph (tree) not using branch lengths (population B)"))


class test_networkScienceMetrics_fullTree(FullTreeFeaturesTest, test_networkScienceMetrics_biTree):
    pass


if __name__ == "__main__":
    import unittest
    unittest.main()
