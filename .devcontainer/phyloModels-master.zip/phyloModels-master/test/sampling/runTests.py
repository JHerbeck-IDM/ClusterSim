import pandas as pd
from scipy.stats import chisquare
import numpy as np

def printResults(p_val, min_count, test):
    print()
    print("=====" + test + " Sampling Test=====")
    print("Lowest count in the expected is", min_count)
    print("Using the chi-squared test to see if your output is different from the expected output")
    print("p-value:", p_val)
    if(p_val>.25):
        print("Test definitely passed!")
    elif(p_val>.05):
        print("Test probably passed, why not run the example again to be safe?")
    else:
        print("Test failed, check that any changes you made to the model are correct!")

def countObserved(f_observe, locations, neighborhoods):
    for i in range(len(locations)):
        for j in range(len(neighborhoods)):
            f_observe[i*len(neighborhoods)+j] = np.sum(np.logical_and(lineList["samplingLocation"]==locations[i], lineList["NEIGHBORHOOD_DISTRICT_NAME"]==neighborhoods[j]))

#Check the uniformly sampling example
lineList = pd.read_csv('observedLineListUniformTest.csv', na_filter=False)
locations = ["atHome", "clinic", "hospital"]
neighborhoods = ['Ballard', 'Central', 'Delridge Neighborhoods', 'Downtown', 'East',
                 'Greater Duwamish', 'Lake Union', 'Magnolia/Queen Anne', 'North',
                 'Northeast', 'Northwest', 'Southeast', 'Southwest', 'NA']
f_expect = []
f_observe = [0]*(len(locations)*len(neighborhoods))
countObserved(f_observe, locations, neighborhoods)

chi2, p_val = chisquare(f_observe)
printResults(p_val, 300/14, "Uniform")

#Check the proportional sampling example
lineList = pd.read_csv('observedLineListProportionalTest.csv', na_filter=False)

f_expect = np.array([413, 612, 428, 366, 568, 467, 650, 1093, 513, 544, 601, 404, 392, 386,
        635, 1217, 523, 484, 969, 741, 1316, 2472, 843, 968, 1159, 451, 499, 8730,
        879, 1938, 688, 578, 1425, 1020, 2106, 3879, 1139, 1260, 1679, 559, 591, 17955])
f_expect = f_expect*(1000/64140)
f_observe = np.zeros(len(locations)*len(neighborhoods))
countObserved(f_observe, locations, neighborhoods)

chi2, p_val = chisquare(f_observe, f_expect)
printResults(p_val, min(f_expect), "Proportional")

#Check the "List" samping example
lineList = pd.read_csv('observedLineListListTest.csv', na_filter=False)

f_expect = np.array([0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828, 0.00828,
        0, 0.0164, 0.00819, 0.0491, 0.0164, 0.0164, 0.0328, 0.0164, 0.0819, 0.0164, 0.0164, 0.0491, 0.00819, 0,
        0.0278, 0.0557, 0.0139, 0.0557, 0.0278, 0.0278, 0.0557, 0.0278, 0.1112, 0.0278, 0.0278, 0.0278, 0.0139, 0.0557])
f_expect = f_expect*(700)
f_observe = np.zeros(len(locations)*len(neighborhoods))
countObserved(f_observe, locations, neighborhoods)

idx = f_expect!=0
f_expect = f_expect[idx]
f_observe = f_observe[idx]
chi2, p_val = chisquare(f_observe, f_expect)
printResults(p_val, min(f_expect), "List")

