#!/bin/bash

echo "Running Uniform sampling example"
python ../../phylomodels/sampling/sample_treeIndependent.py --config configUniformTest.yaml

echo ""
echo "Running Proportional sampling example"
python ../../phylomodels/sampling/sample_treeIndependent.py --config configProportionalTest.yaml

echo ""
echo "Running List sampling example"
python ../../phylomodels/sampling/sample_treeIndependent.py --config configListTest.yaml
