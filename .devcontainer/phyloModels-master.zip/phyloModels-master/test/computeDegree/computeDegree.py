""" computeTreeDegree

Compute in/out/min/max-degree of a tree.

"""
# Python packages (native, 3rd party)
import numpy
import networkx as nx
import matplotlib
from matplotlib import pyplot as plt
matplotlib.pyplot.switch_backend('TKAgg')


# phyloModels packages/modules
import phylomodels
help(phylomodels)



#---- Parameters ---------------------------------------------------------------
n = 10          # Number of nodes in the tree
seed = 1111     # Seed for random number generation
#-------------------------------------------------------------------------------


# Generate tree
tree = nx.gn_graph( n, seed=seed ).reverse()


# Compute degrees
inDegree = tree.in_degree()
outDegree = tree.out_degree()
degree = tree.degree()

degreeVec = numpy.zeros( n )
for i in range(0,n):
    degreeVec[i] = degree(i)
maxDegree = max( degreeVec )
minDegree = min( degreeVec )


# Display results
print("\n*** in-degree: ", inDegree )
print("\n*** out-degree: ", outDegree )
print("\n*** max-degree: ", maxDegree )
print("\n*** min-degree: ", minDegree )

# plt.figure()
# nx.draw( tree, with_labels=True )
# plt.show()
