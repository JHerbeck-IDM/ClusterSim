from phylomodels.network import phyloTree
import matplotlib.pyplot as plt
from Bio import Phylo


lineList = phyloTree.readLineList('infectionTestLineList.csv')
origTree = phyloTree.transTreeFromLineList(lineList)

# Test the full tree with nothing but subtree joining
# and branch length calculation done.
phyloTree.joinSubtrees(origTree)
phyloTree.calcBranchLength(origTree)

filename = 'resultFullOriginalTree.tre'
phyloTree.writeTreeToFile(origTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetFullOriginalTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Original Full Tree',))

# Test making the full tree bifurcating.
fullBiTree = origTree.copy()
phyloTree.makeBifurcating(fullBiTree)
phyloTree.calcBranchLength(fullBiTree)

filename = 'resultFullBiTree.tre'
phyloTree.writeTreeToFile(fullBiTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetFullBiTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Original Bifurcating Tree',))

# Test pruning internal nodes with only one child
# from the full tree.
prunedBiTree = fullBiTree.copy()
leafNodes = [node for node, degree in (prunedBiTree.out_degree(prunedBiTree.nodes)) if degree==0]
phyloTree.prune(prunedBiTree, leafNodes)
phyloTree.calcBranchLength(prunedBiTree)

filename = 'resultPrunedBiTree.tre'
phyloTree.writeTreeToFile(prunedBiTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetPrunedBiTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Pruned Bifurcating Tree',))

# Test sampling a tree, but no bifurcating or forcing
# sampled nodes to be leaves.
sampledTree = phyloTree.buildTree('infectionTestLineList.csv', sampleIds='sampleIdsTest.csv', leaves=False, bifurcate=False)

filename = 'resultSampledTree.tre'
phyloTree.writeTreeToFile(sampledTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetSampledTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Sampled Tree',))

# Test sampling a tree with bifurcation, but not
# or forcing sampled nodes to be leaves.
sampledBiTree = phyloTree.buildTree('infectionTestLineList.csv', sampleIds='sampleIdsTest.csv', leaves=False, bifurcate=True)

filename = 'resultSampledBiTree.tre'
phyloTree.writeTreeToFile(sampledBiTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetSampledBiTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Sampled Bifurcating Tree',))

# Test sampling a tree forcing sampled nodes
# to be leaves, but not bifurcation.
sampledLeafTree = phyloTree.buildTree('infectionTestLineList.csv', sampleIds='sampleIdsTest.csv', leaves=True, bifurcate=False)

filename = 'resultSampledLeafTree.tre'
phyloTree.writeTreeToFile(sampledLeafTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetSampledLeafTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Sampled Tree with Samples as Leaves',))

# Test sampling a tree enforcing bifurcation
# and sampled nodes must be leveas
sampledBiLeafTree = phyloTree.buildTree('infectionTestLineList.csv', sampleIds='sampleIdsTest.csv', leaves=True, bifurcate=True)

filename = 'resultSampledBiLeafTree.tre'
phyloTree.writeTreeToFile(sampledBiLeafTree, filename)

ax1 = plt.subplot(2, 1, 1)
tree = Phylo.read('targetSampledBiLeafTree.tre', 'newick')
Phylo.draw(tree, do_show=False, axes=ax1, title=('Target Tree',), xlabel=(None,))

ax2 = plt.subplot(2, 1, 2)
tree = Phylo.read(filename, 'newick')
Phylo.draw(tree, axes=ax2, title=('Your Tree',), suptitle=('Sampled Bifurcating Tree with Samples as Leaves',))