#
# calibration_historyMatching_sir test
#
#
#



# Python libraries (native, 3rd party)
import numpy
import pandas
import math


# Python libraries (internal)
from phylomodels.models.sir_taoLeap_getIncidence \
     import sir_taoLeap_getIncidence
from phylomodels.calibration.init_historyMatching_poissonGlmBasis \
     import init_historyMatching_poissonGlmBasis
from phylomodels.calibration.cal_parameterSweep \
     import cal_parameterSweep




def calibration_historyMatching_sir_test():

    #---- Parameters -----------------------------------------------------------

    # Test parameters ( Ro/gamma, gamma \in {0.001, 5} )
    Ro          = 1.6
    gamma       = 1.0
    nCandidates = 500    # Should be >10
    tolerance   = 1e-1

    # Model parameters (for data generation)
    beta = Ro/gamma
    xref_name = [ "beta", "gamma",  "s0", "i0", "r0", "nDays" ]
    xref_val  = [   beta,   gamma,  9995,    5,    0,     20  ]

    # Model parameters (for calibration)
    x_name = [ "beta", "gamma",  "s0", "i0", "r0", "nDays" ]
    x_min  = [   1e-3,    1e-3,  9995,    5,    0,      20 ]
    x_max  = [      5,       5,  9995,    5,    0,      20 ]

    hmParams = { "model_discrepancy"      : 2,     # standard dev. metric
                 "observation_uncertainty": 2,     # ditto
                 "max_rejection_rate"     : 99,    # exit condition (percentage)
                 "max_iter"               : 5,     # exit condition (hm waves)
                 "n_candidates"           : nCandidates,   # grid size
                }

    calParams = { "trials"      : 10,
                  "cost_metric" : "L1"
                 }

    # Other parameters
    jobId = "calibration_historyMatching_sir_testResults"
    seed  = 1000
    #---------------------------------------------------------------------------




    # Initialization -----------------------------------------------------------
    numpy.random.seed(seed=seed)




    # Generate problem data ----------------------------------------------------
    xref = pandas.DataFrame( columns=xref_name )
    xref.loc[0] = xref_val
    yref = sir_taoLeap_getIncidence( xref )




    # Calibration init ---------------------------------------------------------
    xInfo = pandas.DataFrame( {  'Name': x_name,
                                 'Min' : x_min,
                                 'Max' : x_max
                              } ).set_index('Name')

    xInit = init_historyMatching_poissonGlmBasis( xInfo,
                                                  yref,
                                                  sir_taoLeap_getIncidence,
                                                  jobId,
                                                  hmParams
                                                 )
    xInit.to_csv( "xInit.csv" )




    # Calibration --------------------------------------------------------------
    xHat = cal_parameterSweep( xInfo,
                               xInit,
                               yref,
                               sir_taoLeap_getIncidence,
                               calParams )



    # Numerical validation -----------------------------------------------------
    success = False   # This flag is set to True in the following loop if the
                      # problem was successfully solved
    for i in range(0, 10):
        betaHat  = xHat.iloc[i]["beta" ]
        gammaHat = xHat.iloc[i]["gamma"]
        RoHat    = betaHat / gammaHat

        betaDiff  = math.fabs( betaHat  - beta  )
        gammaDiff = math.fabs( gammaHat - gamma )

        print( "" )
        print( "... Analyzing results:" )
        print( "        i         = ", i         )
        print( "        beta      = ", beta      )
        print( "        betaHat   = ", betaHat   )
        print( "        betaDiff  = ", betaDiff  )
        print( "        gamma     = ", gamma     )
        print( "        gammaHat  = ", gammaHat  )
        print( "        gammaDiff = ", gammaDiff )
        print( "        tolerance = ", tolerance )

        if (  max( betaDiff, gammaDiff ) < tolerance  ):
            success = True
            print( "        SUCCESS" )
            break




    # Finalize and return ------------------------------------------------------
    return success
#
# End
#-------------------------------------------------------------------------------
