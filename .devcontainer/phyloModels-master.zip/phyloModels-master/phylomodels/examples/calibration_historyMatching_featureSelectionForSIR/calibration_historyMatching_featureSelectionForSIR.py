#
# calibration_historyMatching_featureSelectionForSIR example
#
#
#



# Python libraries (native, 3rd party)
import numpy
import pandas
import logging
import warnings
import matplotlib
from matplotlib import pyplot as plt
matplotlib.pyplot.switch_backend("TKAgg")


# Python libraries (internal)
from phylomodels.visualization.parallelCoordinates import parallelCoordinates

from phylomodels.models.sir_taoLeap_getIncidenceSampled             \
     import sir_taoLeap_getIncidenceSampled
from phylomodels.calibration.init_historyMatching_poissonGlmBasis   \
     import init_historyMatching_poissonGlmBasis
from phylomodels.calibration.cal_parameterSweep                     \
     import cal_parameterSweep


#---- Parameters ---------------------------------------------------------------


# Model parameters (for data generation)
xref_name = [ "beta", "gamma",     "N", "i0", "r0", "nDays",  "p"  ]
xref_val  = [    2.6,     1.2,  100000,    5,    0,      25, 0.005 ]



# Model parameters (for calibration)
Nmin = 100    ; logNmin = numpy.log10(Nmin)
Nmax = 1e7    ; logNmax = numpy.log10(Nmax)
Pmin = 1e-6   ; logPmin = numpy.log10(Pmin)
Pmax = 1.0    ; logPmax = numpy.log10(Pmax)

x_name = [ "beta", "gamma",  "i0", "r0",  "logN",  "logP", "nDays" ]
x_min  = [    0.5,     0.5,    5,     0, logNmin, logPmin,     25  ]
x_max  = [      4,       4,    5,     0, logNmax, logPmax,     25  ]

featurePool = ( "series",
                #"series_derivative",
                #"series_derivative2",
                "series_derivative_cauchyFit",
                "series_derivative2_cauchyFit",
                #"series_diff",
                "series_diff_L1",
                "series_diff_L2",
                "series_diff_Linf",
                #"series_partialSum7",
                "series_sum",
                "series_sum_Log10"
               )

hmParams = { "model_discrepancy"        : 3,     # standard dev. metric
             "observation_uncertainty"  : 10,    # ditto
             "max_rejection_rate"       : 99.5,  # exit condition (percentage)
             "max_iter"                 : 25,    # exit condition (# hm waves)
             "n_candidates"             : 2500,  # grid size
             "feature_selection_metric" : "fano",
             "feature_pool"             : featurePool,   # Enabled featureear
            }

calParams = { "trials"      : 50,
              "cost_metric" : "L1"
             }

# Other parameters
jobId = "featureSelectionForSIR"
seed  = 21 #1000





#-------------------------------------------------------------------------------




# Initialization ---------------------------------------------------------------
numpy.random.seed(seed=seed)
logging.basicConfig( level=logging.DEBUG,
                     format="%(asctime)s %(levelname)s %(message)s",
                     filename="./example.log",
                     filemode="w"
                    )



# Generate problem data --------------------------------------------------------
xref = pandas.DataFrame( columns=xref_name )
xref.loc[0] = xref_val
yref = sir_taoLeap_getIncidenceSampled( xref )






# Calibration init -------------------------------------------------------------

# Parameter space
xInfo = pandas.DataFrame( {  'Name': x_name,
                             'Min' : x_min,
                             'Max' : x_max
                          } ).set_index('Name')

# Prepare observations (including variance)
#window = 5
#yref_smoothed = yref.rolling(window, min_periods=1, center=True, axis=1).mean()
#yref_absdiff  = numpy.fabs( yref.to_numpy()-yref_smoothed.to_numpy() ).flatten()
#yref_withVariance = yref.copy()
#yref_withVariance.loc["var"] = yref_absdiff

# Run history matching iterations
xInit = init_historyMatching_poissonGlmBasis( xInfo,
                                              yref,
                                              sir_taoLeap_getIncidenceSampled,
                                              jobId,
                                              hmParams
                                             )
xInit.to_csv( "xInit.csv" )
#xInit = pandas.read_csv( "xInit.csv" )




# Calibration ------------------------------------------------------------------
xHat = cal_parameterSweep( xInfo,
                           xInit,
                           yref,
                           sir_taoLeap_getIncidenceSampled,
                           calParams )

xHat.to_csv( "xHat.csv" )


# Display results --------------------------------------------------------------


# Summary report
#
print( "\n" )
print( "Solution (with lowest cost):" )
print( "  beta  = ", "{:.2f}".format( xHat["beta" ].iloc[0] ) )
print( "  gamma = ", "{:.2f}".format( xHat["gamma"].iloc[0] ) )
print( "  p     = ", "{:.4f}".format( 10**xHat["logP"].iloc[0] ) )
print( "  N     = ", "{:.0f}".format( 10**xHat["logN"].iloc[0] ) )
print( "" )
print( "Ground truth:" )
print( "  beta  = ", "{:.2f}".format( xref["beta" ][0] ) )
print( "  gamma = ", "{:.2f}".format( xref["gamma"][0] ) )
print( "  p     = ", "{:.4f}".format( xref["p"    ].iloc[0] ) )
print( "  N     = ", "{:.0f}".format( xref["N"    ].iloc[0] ) )
print( "\n" )

# History matching output
#
titleString = "History Matching Output\n(ground truth in red)"
xHat.plot.scatter( x     = "beta",
                   y     = "gamma",
                   title = titleString,
                   grid  = True
                     )
plt.scatter( xref["beta"],          # Superimpose the actual solution
             xref["gamma"],
             marker="o" ,
             s = 60,
             linewidths =2,
             color="r",
             facecolors="none",
             alpha=0.7
            )
filename = "results_history_matching_output_gammaVsBeta.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )

titleString = "History Matching Output\n(ground truth in red)"
xHat.plot.scatter( x     = "logP",
                   y     = "logN",
                   title = titleString,
                   grid  = True
                     )
plt.scatter( numpy.log10( xref["p"]  ) ,    # Superimpose the actual solution
             numpy.log10( xref["N"] ),
             marker="o" ,
             s = 60,
             linewidths =2,
             color="r",
             facecolors="none",
             alpha=0.7
            )
filename = "results_history_matching_output_logPvsLogN.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )




# Parameter sweep output
#
titleString = "Parameter Sweep Output\n(darker is better; ground truth in red)"
xHatReverseOrder = xHat.sort_values( by=["cost"], ascending=False ) # This sets
                   # the order in which dots are rendered in the scatter plot.
                   # Dots with lower cost (i.e., better/darker) are rendered
                   # at last, ensuring that they are visible
xHatReverseOrder.plot.scatter( x        = "beta",
                               y        = "gamma",
                               c        = numpy.log10( xHatReverseOrder["cost"] ),
                               colormap = "bone",
                               title = titleString,
                               grid     = True
                              )
f = plt.gcf(); cax = f.get_axes()[1]; cax.set_ylabel("Log10(cost)")
plt.scatter( xref["beta"],          # Superimpose the actual solution
             xref["gamma"],
             marker="o" ,
             linewidths =2,
             s = 60,
             color="r",
             facecolors="none",
             alpha=0.8
            )
filename = "results_parameter_sweep_output_gammaVsBeta.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )

titleString = "Parameter Sweep Output\n(darker is better; ground truth in red)"
xHatReverseOrder = xHat.sort_values( by=["cost"], ascending=False ) # This sets
                   # the order in which dots are rendered in the scatter plot.
                   # Dots with lower cost (i.e., better/darker) are rendered
                   # at last, ensuring that they are visible
xHatReverseOrder.plot.scatter( x        = "logP",
                               y        = "logN",
                               c        = numpy.log10( xHatReverseOrder["cost"] ),
                               colormap = "bone",
                               title = titleString,
                               grid     = True
                              )
f = plt.gcf(); cax = f.get_axes()[1]; cax.set_ylabel("Log10(cost)")
plt.scatter( numpy.log10( xref["p"] ),     # Superimpose the actual solution
             numpy.log10( xref["N"] ),
             marker="o" ,
             linewidths =2,
             s = 60,
             color="r",
             facecolors="none",
             alpha=0.8
            )
filename = "results_parameter_sweep_output_logPvsLogN.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )



# parallel coordinates plot
threshold = 0.002  # Analyze top % of solutions
nThreshold = round( threshold*len(xHat) )
xHat_subset = xHat.iloc[:nThreshold][["beta", "gamma", "logN", "logP", "cost"]].copy()
xHat_subset["N"] = 10**xHat_subset["logN"]
xHat_subset["p"] = 10**xHat_subset["logP"]
xHat_subset = xHat_subset.drop( columns=["logN", "logP"] )

xHat_subset["Ro"] = xHat_subset["beta"] / xHat_subset["gamma"]
RoMin = 0.98 * xHat_subset["Ro"].min()
RoMax = 1.02 * xHat_subset["Ro"].max()
x_name_pcp    = [  "Ro",    "beta",   "gamma",    "N",   "p" ]
x_min_pcp     = [ RoMin,  x_min[0],  x_min[1],   Nmin,  Pmin ]
x_max_pcp     = [ RoMax,  x_max[0],  x_max[1],   Nmax,  Pmax ]
x_logaxis_pcp = [ False,     False,     False,   True,  True ]
x_revaxis_pcp = [ False,     False,     False,  False,  True ]

xInfo_logaxisrev = pandas.DataFrame( { "Name"    : x_name_pcp,
                                       "Min"     : x_min_pcp,
                                       "Max"     : x_max_pcp,
                                       "logaxis" : x_logaxis_pcp,
                                       "revaxis" : x_revaxis_pcp
                                      }
                                     )
parallelCoordinates( xHat_subset, xInfo_logaxisrev, c="cost", clog=False )
plt.savefig( "results_parameter_sweep_output_parallelCoordinates.png",
             bbox_inches="tight",
             dpi=250
            )






# Top solutions (timeseries)
#
nTop = 10
lastColumn = xHat.columns[-1]
topSolutions = xHat.loc[:,"i_0":lastColumn].iloc[0:nTop].copy()

titleString = "Top " + str(nTop) \
              + " solutions\n(darker is better; ground truth in red)"
legendArray = []
for i in range(0,nTop):
    legendArray.append( "[b,g,N,p] = ["                          \
                        + "{:.2f}".format( xHat["beta" ].iloc[i] )   \
                        + ", "                                       \
                        + "{:.2f}".format( xHat["gamma"].iloc[i] )   \
                        + ", "                                       \
                        + "{:.0f}".format( 10**xHat["logN"].iloc[i] )   \
                        + ", "                                       \
                        + "{:.4f}".format( 10**xHat["logP"].iloc[i] )   \
                        + "]"
                       )
colorScale = xHat["cost"].iloc[0:nTop].values
warnings.filterwarnings("ignore")  # Temporarily supress matplotlib warning
ax = topSolutions.transpose().plot( title    = titleString,
                                    c        = colorScale,
                                    colormap = "bone",
                                    grid     = True
                                   )
warnings.filterwarnings("default") # Restore warnings
ax.legend(legendArray)
ax.set_facecolor("xkcd:light light green")
yref.transpose().plot( ax     = ax,       # Superimpose ground truth
                       style  = "r--",
                       alpha  = 0.8,
                       legend = False,
                       grid   = True
                      )
filename = "results_top_" + str(nTop) + "_solutions.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )


#
# End
#-------------------------------------------------------------------------------
