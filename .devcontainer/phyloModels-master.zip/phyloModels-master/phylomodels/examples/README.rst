=========
Examples
=========

Examples of configuration and use of modules can be found in the ``examples``
directory. This directory is organized in subdirectories, with each subdirectory
containing an independent (i.e, stand-alone) example. Examples aid in 
understanding the use of different modules and, at the same time, they serve as
templates for configuring and executing modeling and calibration jobs.


Naming conventions
==================

Example subdirectories should be named as follows::

    [type of example]_[main method/algorithm][_other labels/description]


type of example
  Assigns a category to the example. In general, categories
  refer to the main operation that is being illustrated in the example. Possible
  types of examples are:

  * calibration
  * features
  * model
  * network
  * sampling
  * visualization

  Note that one example may use components from more than one module. The type
  of example describes the *main* component that is being used. It *does not*
  list all the modules that are being used in the example.
  
main method/algorithm
  Describes the main method or function that is being
  used in the example. For example, it can be the name of the initializer
  of a calibration method, or the name of a model contained in the models 
  module, or a sampling strategy contained in the sampling module.
  
other labels/description
  Any other string that completes the description of the example.
  
  
File structure
==============

All the files relevant to a given example (that are not part
of a module) should be located inside the corresponding folder. The name of the
main script (and notebook, if available) of an example should be the same used
for naming the example subdirectory.
  

Data
====

Data that may be used in more than one example should be placed in the
``examples/data`` subdirectory.

