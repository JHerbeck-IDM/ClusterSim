#
# calibration_historyMatching_sir example
#
#
#



# Python libraries (native, 3rd party)
import numpy
import pandas
import logging
import warnings
import matplotlib
from matplotlib import pyplot as plt
matplotlib.pyplot.switch_backend("TKAgg")


# Python libraries (internal)
from phylomodels.models.sir_taoLeap_getIncidence \
     import sir_taoLeap_getIncidence
from phylomodels.calibration.init_historyMatching_poissonGlmBasis \
     import init_historyMatching_poissonGlmBasis
from phylomodels.calibration.cal_parameterSweep \
     import cal_parameterSweep


#---- Parameters ---------------------------------------------------------------


# Model parameters (for data generation)
xref_name = [ "beta", "gamma",  "s0", "i0", "r0", "nDays" ]
xref_val  = [    2.2,     1.0,  9995,    5,    0,     20  ]



# Model parameters (for calibration)
x_name = [ "beta", "gamma",  "s0", "i0", "r0", "nDays" ]
x_min  = [   1e-3,    1e-3,  9995,    5,    0,      20 ]
x_max  = [      5,       5,  9995,    5,    0,      20 ]

hmParams = { "model_discrepancy"      : 2,     # standard dev. metric
             "observation_uncertainty": 2,     # ditto
             "max_rejection_rate"     : 99,    # exit condition (percentage)
             "max_iter"               : 4,     # exit condition (# of hm waves)
             "n_candidates"           : 200,   # grid size
            }

calParams = { "trials"      : 10,
              "cost_metric" : "L1"
             }

# Other parameters
jobId = "calibration_historyMatching_sir_results"
seed  = 1000



#-------------------------------------------------------------------------------




# Initialization ---------------------------------------------------------------
numpy.random.seed(seed=seed)
logging.basicConfig( level=logging.DEBUG,
                     format="%(asctime)s %(levelname)s %(message)s",
                     filename="./example.log",
                     filemode="w"
                    )



# Generate problem data --------------------------------------------------------
xref = pandas.DataFrame( columns=xref_name )
xref.loc[0] = xref_val
yref = sir_taoLeap_getIncidence( xref )




# Calibration init -------------------------------------------------------------
xInfo = pandas.DataFrame( {  'Name': x_name,
                             'Min' : x_min,
                             'Max' : x_max
                          } ).set_index('Name')

xInit = init_historyMatching_poissonGlmBasis( xInfo,
                                              yref,
                                              sir_taoLeap_getIncidence,
                                              jobId,
                                              hmParams
                                             )
xInit.to_csv( "xInit.csv" )
#xInit = pandas.read_csv( "xInit.csv" )




# Calibration ------------------------------------------------------------------
xHat = cal_parameterSweep( xInfo,
                           xInit,
                           yref,
                           sir_taoLeap_getIncidence,
                           calParams )




# Display results --------------------------------------------------------------


# Summary report
#
print( "\n" )
print( "Solution (with lowest cost):" )
print( "  beta  = ", "{:.2f}".format( xHat["beta" ].iloc[0] ) )
print( "  gamma = ", "{:.2f}".format( xHat["gamma"].iloc[0] ) )
print( "" )
print( "Ground truth:" )
print( "  beta  = ", "{:.2f}".format( xref["beta" ][0] ) )
print( "  gamma = ", "{:.2f}".format( xref["gamma"][0] ) )
print( "\n" )

# History matching output
#
titleString = "History Matching Output\n(ground truth in red)"
xHat.plot.scatter( x     = "beta",
                   y     = "gamma",
                   title = titleString,
                   grid  = True
                     )
plt.scatter( xref["beta"],          # Superimpose the actual solution
             xref["gamma"],
             marker="o" ,
             s = 60,
             linewidths =2,
             color="r",
             facecolors="none",
             alpha=0.7
            )
filename = "results_history_matching_output.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )


# Parameter sweep output
#
titleString = "Parameter Sweep Output\n(darker is better; ground truth in red)"
xHatReverseOrder = xHat.sort_values( by=["cost"], ascending=False ) # This sets
                   # the order in which dots are rendered in the scatter plot.
                   # Dots with lower cost (i.e., better/darker) are rendered
                   # at last, ensuring that they are visible
xHatReverseOrder.plot.scatter( x        = "beta",
                               y        = "gamma",
                               c        = numpy.log10( xHatReverseOrder["cost"] ),
                               colormap = "bone",
                               title = titleString,
                               grid     = True
                              )
f = plt.gcf(); cax = f.get_axes()[1]; cax.set_ylabel("Log10(cost)")
plt.scatter( xref["beta"],          # Superimpose the actual solution
             xref["gamma"],
             marker="o" ,
             linewidths =2,
             s = 60,
             color="r",
             facecolors="none",
             alpha=0.8
            )
filename = "results_parameter_sweep_output.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )


# Top solutions (timeseries)
#
nTop = 10
lastColumn = xHat.columns[-1]
topSolutions = xHat.loc[:,"i_0":lastColumn].iloc[0:nTop].copy()

titleString = "Top " + str(nTop) \
              + " solutions\n(darker is better; ground truth in red)"
legendArray = []
for i in range(0,nTop):
    legendArray.append( "[beta, gamma] = ["                          \
                        + "{:.2f}".format( xHat["beta" ].iloc[i] )   \
                        + ", "                                       \
                        + "{:.2f}".format( xHat["gamma"].iloc[i] )   \
                        + "]"
                       )
colorScale = xHat["cost"].iloc[0:nTop].values
warnings.filterwarnings("ignore")  # Temporarily supress matplotlib warning
ax = topSolutions.transpose().plot( title    = titleString,
                                    c        = colorScale,
                                    colormap = "bone",
                                    grid     = True
                                   )
warnings.filterwarnings("default") # Restore warnings
ax.legend(legendArray)
yref.transpose().plot( ax     = ax,       # Superimpose ground truth
                       style  = "r--",
                       alpha  = 0.8,
                       legend = False,
                       grid   = True
                      )
filename = "results_top_" + str(nTop) + "_solutions.png"
plt.savefig( filename, bbox_inches="tight", dpi=250 )


#
# End
#-------------------------------------------------------------------------------
