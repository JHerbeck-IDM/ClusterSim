#!/usr/bin/env python
import pandas as pd
from numpy import nan
from phylomodels.trees import generate_treeFromFile
from phylomodels.trees.transform_joinTrees import transform_joinTrees
from phylomodels.trees.transform_transToPhyloTree import transform_transToPhyloTree

# read in line list
lineList = pd.read_csv('lineListAB.csv')
# Set samples after 2011.1 to be twice as likely to sample as those before
lineList['weight'] = 1 + (lineList['sampledTime'] >= 2011.1)
# Set number of nodes to sample
n = 10
# Sample the nodes
nodes_to_keep = lineList.sample(n=n, weights='weight', replace=False, random_state=1)
# Only save only the names
nodes_to_keep = nodes_to_keep['id']
# Set sample time to nan for those not sampled
lineList.loc[~lineList['id'].isin(nodes_to_keep), 'sampledTime'] = nan

## Now build the tree
# build transmission tree(s)
trees = generate_treeFromFile.read_treeFromLineList(lineList, sampleTime='sampledTime')
# convert transmission tree(s) to phylogenetic tree(s)
for i in range(len(trees)):
    trees[i] = transform_transToPhyloTree(trees[i])
# combined transmission tree(s)
tree = transform_joinTrees(trees, method='constant_coalescent')

print(tree)
