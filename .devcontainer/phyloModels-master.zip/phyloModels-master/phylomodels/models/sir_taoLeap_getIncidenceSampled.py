# Python libraries (native, 3rd party)
import numpy
import pandas

# Python libraries (internal)
from phylomodels.models.sir_taoLeap import sirTaoLeap



def sir_taoLeap_getIncidenceSampled( x : pandas.DataFrame ):
    """Call sir_taoLeap model (where only incidence values are returned) and
    apply a binomial observation process characterized by a sampling probability
    p. Returns time series of the sampled incidence counts.

    Args:
     x : Pandas DataFrame. Each row contains a set of parameters to be used
         when calling the sirTaoLeap. The following columns define the
         parameters:

         beta
            (required) Transmission rate (>0).
         gamma
            (required) Inverse of the average transmission period (>0).
         s0
            Initial number of succeptible individuals (non-negative
            integer). This parameter is optional if i0, r0, and either N or logN are provided; otherwise is required.
         i0
            Initial number of infected individuals (non-negative
            integer). This parameter is optional if s0, r0, and either N or logN are provided; otherwise is required.
         r0
            Initial number of recovered individuals (non-negative
            integer). This parameter is optional if s0, i0, and either N or logN are provided; otherwise is required.
         N
            Population size (non-negative integer). This parameter is
            optional if logN is provided or if s0, i0, and r0 are
            provided; otherwise is required.
         logN
            Log10 of population size (non-negative integer). This
            parameter is N is provided or if s0, i0, and r0 are
            provided; otherwise is required.
         p
            Sampling probability of incidence counts. This parameter is
            optional if logP is provided; otherwise is reqiored.
         logP
            Log10 of sampling probability of incidence counts. This
            parameter is optional if p is provided; otherwise is
            required.
         nDays
            (required) Number of days (or time steps) to simulate.
         stepSize
            (optional) Step size in days (integer between 0 and 1).
            (default stepSize=0.1).

    .. note::

        The underlying model uses numpy's random number generator. Seed
        initialization, if required, should be done before calling this
        function.
    """

    # Initialize output array
    nSims    = len(x)
    nDaysMax = int( x["nDays"].max() )
    y        = numpy.full( [nSims, nDaysMax], numpy.nan )



    # Loop through every parameter set and run simulations
    for j in range(0, nSims):

        # Read model parameters
        ( beta,
          gamma,
          s0,
          i0,
          r0,
          p,
          nDays,
          stepSize ) = getModelParameters( x.loc[j] )

        # Run simulations and sample incidence
        model = sirTaoLeap.sirTaoLeap( beta,
                                       gamma,
                                       s0,
                                       i0,
                                       r0,
                                       nDays,
                                       stepSize
                                      )
        incidence = model.getIncidence()
        sampledIncidence = numpy.random.binomial( n = numpy.int64(incidence),
                                                  p = p
                                                 )

        # Save results
        y[j,:] = sampledIncidence



    # Prepare output and return
    y_df = pandas.DataFrame(y)
    y_df = y_df.add_prefix("i_")
    return y_df




def getModelParameters( x : pandas.DataFrame ):

    # Validate and get required parameters: beta, gamma, nDays
    if "beta" in x:
        beta = x["beta"]
    else:
        raise ValueError( "Missing model parameter (beta)" )

    if "gamma" in x:
        gamma = x["gamma"]
    else:
        raise ValueError( "Missing model parameter (gamma)" )

    if "nDays" in x:
        nDays = int( x["nDays"] )
    else:
        raise ValueError( "Missing model parameter (nDays)" )


    # Get p (from either "p" or "logP", but not both)
    if (  ("p" in x) and ("logP" in x)  ):
        raise ValueError( "Duplicated model parameter " +
                          "(either p or logP should be defined, but not both)"
                         )
    elif "p" in x:
        p = x["p"]
    elif "logP" in x:
        p = 10**x["logP"]
    else:
        raise ValueError( "Missing model parameter (p)" )


    # Get population parameters (i.e., s0, i0, r0, popsize)
    findS0      = True  # These flags will change to False for each of these
    findI0      = True  # parameters that is not provided as part of the
    findR0      = True  # input dataframe
    findPopsize = True  #

    if "logN" in x:
        if "N" in x:
            raise ValueError( "Duplicated model parameter (either N or logN " +
                              "should be defined, but not both)"
                             )
        else:
            popsize = 10**x["logN"]
            findPopsize = False
    elif "N" in x:
        popsize = x["N"]
        findPopsize = False
    else:
        pass

    if "s0" in x:             # Read inputs and find out if something needs to
        s0 = int( x["s0"] )   # be calculated
        findS0 = False
    if "i0" in x:
        i0 = int( x["i0"] )
        findI0 = False
    if "r0" in x:
        r0 = int( x["r0"] )
        findR0 = False

    if sum([findS0, findI0, findR0, findPopsize]) > 1:
        raise ValueError( "Missing parameter (at least 3 out of s0, i0, r0, or"+
                          " popsize must be provided)"
                         )
    elif sum([findS0, findI0, findR0, findPopsize]) == 4:
        if not (popsize == s0 + i0 + r0 ):
            raise ValueError( "Inconsistent input parameters (popsize is not " +
                              "equal to s0+i0+r0)"
                             )
    else: # Compute the missing parameter
        if findS0:
            s0 = int( popsize - i0 - r0 )
        elif findI0:
            i0 = int( popsize - s0 - r0 )
        elif findR0:
            r0 = int( popsize - s0 - i0 )
        else:
            popsize = int( s0 + i0 + r0 )


    # Optional parameters
    if "stepSize" in x:
        stepSize = x["stepSize"]
    else:
        stepSize = 0.1


    # Finalize and return
    return ( beta,
             gamma,
             s0,
             i0,
             r0,
             p,
             nDays,
             stepSize
            )
