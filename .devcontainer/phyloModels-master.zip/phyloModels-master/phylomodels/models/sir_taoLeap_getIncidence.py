# Python libraries (native, 3rd party)
import numpy
import pandas

# Python libraries (internal)
from phylomodels.models.sir_taoLeap import sirTaoLeap



def sir_taoLeap_getIncidence( x : pandas.DataFrame ):
    """Call sir_taoLeap model, where only incidence values are returned.
    
    Args:
     x : Pandas DataFrame. Each row contains a set of parameters to be used
         when calling the sirTaoLeap.
    """

    # Initialize output array
    nSims    = len(x)
    nDaysMax = int( x["nDays"].max() )
    y        = numpy.full( [nSims, nDaysMax], numpy.nan )



    # Loop through every parameter set and run simulations
    for j in range(0, nSims):

        # Read model parameters
        beta  = x.loc[j, "beta" ]
        gamma = x.loc[j, "gamma"]
        s0    = x.loc[j, "s0"   ]
        i0    = x.loc[j, "i0"   ]
        r0    = x.loc[j, "r0"   ]
        nDays = x.loc[j, "nDays"]

        # Run simulations
        model = sirTaoLeap.sirTaoLeap( beta,
                                       gamma,
                                       int(s0),
                                       int(i0),
                                       int(r0),
                                       int(nDays)
                                      )

        # Save results
        y[j,:] = model.getIncidence()



    # Prepare output and return
    y_df = pandas.DataFrame(y)
    y_df = y_df.add_prefix("i_")
    return y_df

