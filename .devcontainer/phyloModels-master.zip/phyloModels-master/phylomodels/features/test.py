from features import features
import numpy as np
import pandas as pd
import math
import unittest


class FeaturesTests(unittest.TestCase):
    """
        unit tests for features
    """
    def setUp(self) -> None:
        print("In method: ", self._testMethodName)
        pass

    def tearDown(self) -> None:
        print("Exit method: ", self._testMethodName)
        pass

    def test_xref_nan(self):
        x = pd.DataFrame.from_dict({"sim_1": np.arange(10),
                                    "sim_2": np.arange(10, 0, -1),
                                    "sim_3": 10 ** np.random.random(10)},
                                   orient="index")
        xref = pd.DataFrame.from_dict({"ref": np.append(10 ** np.random.random(9), math.nan)}, orient="index")
        with self.assertRaises(ValueError) as context:
            features(x=x, xref=xref)
        self.assertTrue("NaN" in str(context.exception))

    def test_xref_inf(self):
        x = pd.DataFrame.from_dict({"sim_1": np.arange(10),
                                    "sim_2": np.arange(10, 0, -1),
                                    "sim_3": 10 ** np.random.random(10)},
                                   orient="index")
        xref = pd.DataFrame.from_dict({"ref": np.append(10 ** np.random.random(9), math.inf)}, orient="index")
        with self.assertRaises(ValueError) as context:
            features(x=x, xref=xref)
        self.assertTrue("infinite" in str(context.exception))

    def test_array(self):
        x = pd.DataFrame.from_dict({"sim_1": np.arange(10),
                                    "sim_2": np.append(np.arange(10, 1, -1), math.inf),
                                    "sim_3": 10 ** np.random.random(10)},
                                   orient="index")
        xref = 10 ** np.random.random(10)
        with self.assertRaises(ValueError) as context:
            features(x=x, xref=xref)
        self.assertTrue("Pandas DataFrame" in str(context.exception))

    def test_empty_dataframe(self):
        x = pd.DataFrame()
        xref = pd.DataFrame.from_dict({"ref": 10 ** np.random.random(10)}, orient="index")
        with self.assertRaises(ValueError) as context:
            features(x=x, xref=xref)
        self.assertTrue("empty" in str(context.exception))

    def test_x_nan(self):
        x_dict = {"sim_1": np.arange(10),
                  "sim_2": np.append(np.arange(10, 1, -1), math.nan),
                  "sim_3": 10 ** np.random.random(10)}
        x = pd.DataFrame.from_dict(x_dict, orient="index")
        xref = pd.DataFrame.from_dict({"ref": 10 ** np.random.random(10)}, orient="index")
        f = features(x=x, xref=xref)
        del x_dict["sim_2"]
        x_expect = pd.DataFrame.from_dict(x_dict, orient="index")
        self.assertTrue(x_expect.equals(f.x))

    def test_x_inf(self):
        x_dict = {"sim_1": np.append(np.arange(9), math.inf),
                  "sim_2": np.arange(10, 0, -1),
                  "sim_3": 10 ** np.random.random(10)}
        x = pd.DataFrame.from_dict(x_dict, orient="index")
        xref = pd.DataFrame.from_dict({"ref": 10 ** np.random.random(10)}, orient="index")
        f = features(x=x, xref=xref)
        del x_dict["sim_1"]
        x_expect = pd.DataFrame.from_dict(x_dict, orient="index")
        self.assertTrue(x_expect.equals(f.x))

    def test_create_feature(self):
        x = pd.DataFrame.from_dict({"sim_1": np.arange(60),
                                    "sim_2": np.arange(60, 0, -1),
                                    "sim_3": 60 ** np.random.random(60)},
                                    orient="index")
        xref = pd.DataFrame.from_dict({"ref": np.repeat(30, 60)}, orient="index")

        f = features(x=x, xref=xref)
        # f.listActiveFeatures()
        f.compute()
        # f.printFeatures()
        self.assertTrue(f.f.shape == (3,368))


if __name__ == '__main__':
    unittest.main()


