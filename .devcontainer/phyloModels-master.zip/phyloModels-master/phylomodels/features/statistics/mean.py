import numpy
import pandas


def mean(f):
    """
    Returns mean of each column of the input dataframe.
    """

    mean = f.mean(axis=0)
    mean_df = pandas.DataFrame( {"mean": mean} )
    return mean_df
