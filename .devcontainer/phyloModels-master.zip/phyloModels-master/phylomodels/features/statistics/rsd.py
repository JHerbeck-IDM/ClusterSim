import numpy
import pandas


def rsd(f):
    """
    Returns Relative Standard Deviation (RSD) of each column of the input
    dataframe. The RSD is defined as sqrt( var/mean ).
    """

    numpy.seterr(divide="ignore", invalid="ignore")
    rsd = numpy.sqrt( f.var(axis=0)/f.mean(axis=0) )
    numpy.seterr(divide="warn", invalid="warn")

    rsd_df = pandas.DataFrame( {"rsd": rsd} )
    return rsd_df
