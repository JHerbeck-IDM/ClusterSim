import numpy
import pandas


def var(f):
    """
    Returns variance of each column of the input dataframe.
    """

    var = f.var(axis=0)
    var_df = pandas.DataFrame( {"var": var} )
    return var_df
