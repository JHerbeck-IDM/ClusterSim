import numpy
import pandas


def std(f):
    """
    Returns standard deviation of each column of the input dataframe.
    """

    std = f.std(axis=0)
    std_df = pandas.DataFrame( {"std": std} )
    return std_df
