import numpy
import pandas


def fano(f):
    """
    Returns the Fano factor of each column of the input dataframe. The Fano
    factor is defined as (var/mean).
    """

    numpy.seterr(divide="ignore", invalid="ignore")
    fano = f.var(axis=0)/f.mean(axis=0)
    numpy.seterr(divide="warn", invalid="warn")

    fano_df = pandas.DataFrame( {"fano": fano} )
    return fano_df
