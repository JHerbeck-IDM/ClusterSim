import numpy
import pandas


def qcd(f):
    """
    Returns the Quartile Coefficient of Dispersion (QCD) of each column of the
    input dataframe.
    """

    q3 = f.quantile(q=0.75, axis=0)
    q1 = f.quantile(q=0.25, axis=0)

    numpy.seterr(divide="ignore", invalid="ignore")
    qcd_df = pandas.DataFrame( {"qcd": (q3-q1)/(q3+q1) } )
    numpy.seterr(divide="warn", invalid="warn")

    return qcd_df

