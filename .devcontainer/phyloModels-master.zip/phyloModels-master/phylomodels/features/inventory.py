"""
  Functions for inventory management of features and statistics.

  See features.md in the documentation folder for any relevant information.

"""
# Python libraries (native, 3rd party)
import os
import sys
import re
import warnings
import collections

import numpy
import pandas


# Python libraries (internal)
import phylomodels.features.series
import phylomodels.features.statistics






#-------------------------------------------------------------------------------
#   getNewId
#-------------------------------------------------------------------------------
def getNewId(a):
    """
    Returns a unique identifier for a new element that would be added to the
    input array.
    """
    return len(a)




#-------------------------------------------------------------------------------
#   populateAvailableFeatures
#-------------------------------------------------------------------------------
def populateAvailableFeatures( availableFeatures ):
    """
    Update the array containing the  list of available features (i.e., summary
    statistics). Available features are those that are in the series and graphs submodules, and that pass a basic validation tests. This function returns
    the updated list along with its size.
    """

    featureCard = collections.namedtuple(
                      "featureCard", ["id", "name", "description", "subroutine"]
                  )


    # Get path to files with operations on time series
    pathToThisFile = os.path.dirname(__file__)
    fullPathToThisFile = os.path.abspath(pathToThisFile)
    pathToOperationsOnSeries = fullPathToThisFile + "/series"


    # Iterate through each of the files
    for fileName in os.listdir( pathToOperationsOnSeries ):

        if (       fileName.endswith(".py")
              and (fileName != "__init__.py")
             ):     # Only interested on this type of files


            # Extract information for featureCard
            id         = getNewId(availableFeatures)
            name       = fileName[:-3]
            moduleName = getattr( phylomodels.features.series,     name )
            subroutine = getattr( moduleName, name )

            pathToFile = pathToOperationsOnSeries + "/" + fileName
            with open(pathToFile, "r") as file:
                allLines = file.read().replace("\n", "")
                rePattern = "def\s*" +name + '\(.+\):\s*\"\"\"\s*(.+?)\s*\"\"\"'
                patternFound = re.search( rePattern, allLines )
                if patternFound:
                    description = patternFound.group(1)
                else:
                    description = "not available"


            # Test that the function executes correctly
            # NOTE: Ideally, this should be a quick by thorough self-check.
            #       The goal is to quickly validate that the function
            #       is not only callable, but also operates well numerically.
            #
            successfulSubroutineExecution = True
            try:
                mDummy = 2
                nDummy = 10
                xDummy = numpy.full( (mDummy,nDummy), 1.5 )
                xrefDummy = numpy.full( (1,nDummy), 2.1 )
                dummy = subroutine( xDummy, xrefDummy )
            except Exception as e:
                successfulSubroutineExecution = False
                msg = "An exception occurred calling " + name + ": " + str(e)
                warnings.warn(msg)


            # Add to inventory
            if successfulSubroutineExecution:

                availableFeatures.append( featureCard( id,
                                                       name,
                                                       description,
                                                       subroutine
                                                      )
                                         )

    return availableFeatures, len(availableFeatures)




#-------------------------------------------------------------------------------
#   populateAvailableStatistics
#-------------------------------------------------------------------------------
def populateAvailableStatistics( availableStats ):
    """
    Update the array containing the  list of available statistics. Available
    statistics are those that are in the statistics submodule, and that pass
    a basic validation tests. This function returns the updated list along with
    its size.
    """

    statsCard \
        = collections.namedtuple(
                        "statsCard", ["id", "name", "description", "subroutine"]
          )

    # Get path to files with statistics operations
    pathToThisFile = os.path.dirname(__file__)
    fullPathToThisFile = os.path.abspath(pathToThisFile)
    pathToStatisticsOperations = fullPathToThisFile + "/statistics"

    # Iterate through each of the files
    for fileName in os.listdir( pathToStatisticsOperations ):

        if (       fileName.endswith(".py")
              and (fileName != "__init__.py")
             ):     # Only interested on this type of files

            # Extract information for statsCard
            id         = getNewId(availableStats)
            name       = fileName[:-3]
            moduleName = getattr( phylomodels.features.statistics, name )
            subroutine = getattr( moduleName, name )


            pathToFile = pathToStatisticsOperations + "/" + fileName
            with open(pathToFile, "r") as file:
                allLines = file.read().replace("\n", "")
                rePattern = "def\s*" + name + '\(x\):\s*\"\"\"\s*(.+?)\s*\"\"\"'
                patternFound = re.search( rePattern, allLines )
                if patternFound:
                    description = patternFound.group(1)
                else:
                    description = "not available"


            # Test that the function executes correctly
            successfulSubroutineExecution = True
            try:
                dummyData   = pandas.DataFrame({ "dummy": [0]} )
                dummyResult = subroutine( dummyData )
            except Exception as e:
                successfulSubroutineExecution = False
                msg = "An exception occurred calling " + name + ": " + str(e)
                warnings.warn(msg)


            # Add to inventory
            if successfulSubroutineExecution:

                availableStats.append( statsCard( id,
                                                  name,
                                                  description,
                                                  subroutine
                                                 )
                                      )


    return availableStats, len(availableStats)

