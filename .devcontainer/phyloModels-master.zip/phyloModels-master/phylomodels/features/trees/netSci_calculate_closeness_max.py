import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, topology_param, distance_mat_param

@tree_param
@attr_param
def netSci_calculate_closeness_max(trees, attr, attr_values, **kwargs):
    """
    Return the maximum closeness of the nodes. This can be calculated
    using branch lengths (default) or topology (number of edges). Additionally
    it can be calculated for the whole tree or conditionally based on the
    attribute values of attr of the nodes.
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the tree height
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and building
                               a list of values found in them.
        topology_only (bool) : Optional. If set to True (default False)
                               calculate the height using the "topology"
                               (number of branches) instead of branch lengths.
        distance_mat (dict)  : Optional. A dictionary of the distance matrix for
        distance_mat_topology  each tree. If the branch lengths are used for 
                               distances then use the shorter name. If instead
                               the "topology" distance is used then the topology
                               sufix should be used in teh name.

    Returns:
        DataFrame            : The maximum closenss of the nodes for the whole
                               tree and if an attr is provided, conditionally
                               for each unique value of the attribute.

    """

    topology_only, kwargs = topology_param(**kwargs)
    distance_mats, kwargs = distance_mat_param(trees, topology_only, **kwargs)

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'closeness_max_topology'
    else:
        feature_name = 'closeness_max'

    # Initialize output dataframe
    closeness_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        distance = distance_mats[name]
        nodes = [tree] + tree.get_descendants('levelorder')
        num_nodes = len(nodes)
        node_attrs = []
        for i in np.arange(num_nodes):
            node_attrs.append(getattr(nodes[i], attr, "None")) if attr else None

        closeness_df.loc[name, feature_name] = np.amax(1/np.sum(distance, axis=1))
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If no attr_value in node_attrs
                if np.any(idx):
                    closeness_df.loc[name, feature_name + '_' + attr_value] = np.amax(1/np.sum(distance[idx,:][:,idx], axis=1))
                else:
                    closeness_df.loc[name, feature_name + '_' + attr_value] = 0

    return closeness_df
