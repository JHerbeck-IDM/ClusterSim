import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, normalize_param

@tree_param
@attr_param
def top_calculate_sackin(trees, attr, attr_values, **kwargs):
    """
    Return sum of the number of nodes between the leaves and root. If an
    attribute is given this is calculated for each unique value of the attribute
    among the leaf nodes.
    Sackin Systematic Biology 21(2) p.225-226 (1972)

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use in
                                conditionally calculating the statistic
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and buildng
                                a list of values found in them.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics.

    Returns:
        DataFrame             : The sum of the number of nodes between the leaves
                                and the root for the whole tree and if an attr is
                                provided, conditionally for each unique value of
                                the attribute.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    sackins_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        sackin     = []
        node_attrs = []
        for node in tree.iter_leaves():
            sackin.append(tree.get_distance(node, topology_only=True))
            node_attrs.append(getattr(node, attr, "None")) if attr else None
        sackin = np.array(sackin)

        if normalize:
            sackins_df.loc[name, 'sackin'] = np.sum(sackin)/len(sackin)
        else:
            sackins_df.loc[name, 'sackin'] = np.sum(sackin)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                if normalize:
                    # If sackin[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        sackins_df.loc[name, 'sackin_' + attr_value] = np.sum(sackin[idx])/np.sum(idx)
                    else:
                        sackins_df.loc[name, 'sackin_' + attr_value] = 0.0
                else:
                    # If sackin[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        sackins_df.loc[name, 'sackin_' + attr_value] = np.sum(sackin[idx])
                    else:
                        sackins_df.loc[name, 'sackin_' + attr_value] = 0.0

    # Finalize and return
    return sackins_df
