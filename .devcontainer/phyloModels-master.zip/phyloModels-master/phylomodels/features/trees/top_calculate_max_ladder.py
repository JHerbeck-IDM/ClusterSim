import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param
from phylomodels.features.trees.helper.get_node_properties import is_semipreterminal, is_preterminal

@tree_param
@attr_param
def top_calculate_max_ladder(trees, attr, attr_values, **kwargs):
    """
    Return the maximum number of internal nodes in a ladder divided by the
    number of leaves. If an attribute is given than this returns a maximum for
    each unique value of the attribute in addition to all nodes. In order to be
    considered a ladder (per attribution) has to have at least one node with
    the approperiate value. A better definition might be the most, majority,
    or all of the nodes in the ladder have to have that value.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the size of the largest
                               ladder normalized by number of leaves for the
                               tree and if attr is provided the conditional
                               ladder size based on the node attribute (as
                               different columns). Each tree having its own row.

    """

    def ladder_chain(root, ladder):
        if(root in ladder):
            ladder.remove(root)
            curr_size = 1
            for child in root.children:
                curr_size += ladder_chain(child, ladder)
            return curr_size
        else:
            return 0

    def ladder_chain_ID(root, ladder):
        if(root in ladder):
            ladder.remove(root)
            curr_size = {}
            curr_size[getattr(root, attr, "None")] = 1
            for child in root.children:
                temp = ladder_chain_ID(child, ladder)
                curr_size = {key: curr_size.get(key,0) + temp.get(key,0) for key in set(curr_size) | set(temp)}
            return curr_size
        else:
            return {}

    # Initialize output dataframe
    max_ladders_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        ladder = []
        num_leaves = len(tree)
        for node in tree.traverse('levelorder'):
            if(is_semipreterminal(node) and not is_preterminal(node)):
                ladder.append(node)
        # If using attr option get list of values alongside the branch length
        # for conditional calculations
        if attr:
            ladder_temp = ladder.copy()
            ladder_size = {}
            while(ladder_temp):
                curr_size = {}
                root = ladder_temp[0]
                ladder_temp.remove(root)
                curr_size[getattr(root, attr, "None")] = 1
                for child in root.children:
                    temp = ladder_chain_ID(child, ladder_temp)
                    curr_size = {key: curr_size.get(key,0) + temp.get(key,0) for key in set(curr_size) | set(temp)}
                for key in set(curr_size) - set(ladder_size):
                    ladder_size[key] = 0
                for key in curr_size.keys():
                    ladder_size[key] = max(curr_size[key], ladder_size[key])

            for key, value in ladder_size.items():
                ladder_size[key] = value/num_leaves

            keys = ladder_size.keys()
            for attr_value in attr_values:
                max_ladders_df.loc[name, 'max_ladder_' + attr_value] = 0
                if attr_value in keys:
                    max_ladders_df.loc[name, 'max_ladder_' + attr_value] = ladder_size[attr_value]

        ladder_size = []
        while(ladder):
            curr_size = 1
            root = ladder[0]
            ladder.remove(root)
            for child in root.children:
                curr_size += ladder_chain(child, ladder)
            ladder_size.append(curr_size)

        if len(ladder_size) < 1:
            ladder_size.append(0)
        max_ladders_df.loc[name, 'max_ladder'] = max(ladder_size)/num_leaves

    # Finalize and return
    return max_ladders_df
