import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, normalize_param

@tree_param
@attr_param
def top_calculate_B2(trees, attr, attr_values, **kwargs):
    """
    Return the B_2 statistic which is based on the Shannon-Wiener statistic
    (reminiscent of the Shannon entropy), based on the number of nodes between
    the leaves and root. If an attribute is given, this is calculated for each
    unique value of the attribute among the leaf nodes.
    Shao and Sokal, Systematic Zoology 39(3) p. 266-276 1990

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use when
                                conditionally calculating the statistic
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and
                                building a list of values found in them.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics.

    Returns:
        DataFrame             : The B_2 statistic is based on the number of
                                nodes between the leaves and the root for the
                                whole tree and, if an attr is provided,
                                conditionally for each unique value of the
                                attribute.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    B2_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        N          = []
        node_attrs = []
        for node in tree.iter_leaves():
            # add 1 so a pretermius node is not 0, seems to be what the
            # definition intended
            N.append(tree.get_distance(node, topology_only=True)+1)
            node_attrs.append(getattr(node, attr, "None")) if attr else None
        N = np.array(N)

        if normalize:
            B2_df.loc[name, 'B2'] = np.sum(N/(2**N))/len(N)
        else:
            B2_df.loc[name, 'B2'] = np.sum(N/(2**N))
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                if normalize:
                    # If N[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        B2_df.loc[name, 'B2_' + attr_value] = np.sum(N[idx]/(2**N[idx]))/np.sum(idx)
                    else:
                        B2_df.loc[name, 'B2_' + attr_value] = 0.0
                else:
                    # If N[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        B2_df.loc[name, 'B2_' + attr_value] = np.sum(N[idx]/(2**N[idx]))
                    else:
                        B2_df.loc[name, 'B2_' + attr_value] = 0.0

    # Finalize and return
    return B2_df
