import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, topology_param, adj_eigenvalues_param

@tree_param
def spectral_calculate_min_adj_eigen(trees, **kwargs):
    """
    Return the minimum (positive) eigenvalue from the adjacency matrix. This
    can be calculated using weights (default) or unweighted.
    Chindelevitch et al bioRxiv https://doi.org/10.1101/608646

    Args:
        trees (dict)            : The dict of trees to calculate the statistic
                                  from.
        topology_only (bool)    : Optional. If set to True (default False)
                                  calculate the height using the "topology"
                                  (number of branches) instead of branch
                                  lengths.
        eigenvalues_adj (dict)  : Optional. A dictionary containing the
        eigenvalues_adj_topology  eigenvalues of the adjacency matrix for each
                                  tree. If the matrix was calculated with branch
                                  lengths it should be have the shorter name. If
                                  instead the matrix was calculated with the
                                  "topology" distance then the name with the
                                  topology suffix should be used.

    Returns:
        DataFrame               : The minimum postive eigenvalue of the
                                  adjacency matrix for the tree.

    """

    topology_only, kwargs = topology_param(**kwargs)
    eigenvalues, kwargs   = adj_eigenvalues_param(trees, topology_only, **kwargs)

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'eigenvalue_min_adj_topology'
    else:
        feature_name = 'eigenvalue_min_adj'

    # Initialize output dataframe
    eigenvalue_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        w = eigenvalues[name]
        eig = np.amin(w[w>0])
        eigenvalue_df.loc[name, feature_name] = np.real(eig)

    return eigenvalue_df
