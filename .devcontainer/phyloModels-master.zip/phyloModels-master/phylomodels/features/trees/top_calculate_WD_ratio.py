import pandas as pd
from collections import Counter
from phylomodels.features.trees.helper.process_optional_arguements import tree_param

@tree_param
def top_calculate_WD_ratio(trees, **kwargs):
    """
    Return ratio of the maximal width and maximal depth. Depth is measured by
    number of branches to the root. Width is number of nodes at a specific depth.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.

    Returns:
        DataFrame   : The maximum width of the tree divided by the maximum depth.

    """

    # Initialize output dataframe
    WD_ratios_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        depths = []
        for node in tree.iter_descendants():
            depths.append( tree.get_distance(node, topology_only=True) )

        widths = Counter(depths)
        max_depth = max(depths)
        max_width = max(widths.values())
        WD_ratios_df.loc[name, 'WD_ratio'] = max_width/max_depth

    # Finalize and return
    return  WD_ratios_df
