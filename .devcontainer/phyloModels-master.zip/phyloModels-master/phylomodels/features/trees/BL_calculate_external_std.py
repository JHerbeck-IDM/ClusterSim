from numpy import std
from phylomodels.features.trees.helper.calculate_branch_length_metrics import calculate_branch_length_metrics

#TODO add ability to calculate it over different time intervals
def BL_calculate_external_std(trees, **kwargs):
    """
    Return the standard deviation of the internal branch lengths. If an
    attribute is provided these statistics are calculated for all internal
    branch lengths and condtionally for each unique value of the attribute.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and
                               building a list of values found in them.

    Returns:
        DataFrame            : Data frame containing the standard deviation
                               internal branch length for the tree and if attr
                               is provided the conditional standard deviation
                               based on the node attribute (as different
                               columns). Each tree having its own row.

    """

    # Initialize output dataframe
    std_BLs_df = calculate_branch_length_metrics(trees, functions_dict={'std': std}, branch_type='external', **kwargs)

    # Finalize and return
    return std_BLs_df
