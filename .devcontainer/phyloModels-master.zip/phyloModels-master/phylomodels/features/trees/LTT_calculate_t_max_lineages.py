import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, LTT_param

@tree_param
@LTT_param
def LTT_calculate_t_max_lineages(trees, LTTs, **kwargs):
    """
    Returns the time of maximum number of lineages from the lineages through
    time plot/view of the tree.
    Saulnier et al. https://doi.org/10.1371/journal.pcbi.1005416 (2017)

    Args:
        trees (dict): The dict of trees to calculate the statistic from.
        LTTs (dict) : Optional. A dictionary with each key being one of the
                      input trees. The value is a dictionary represention of
                      the lineage through time plot.

    Returns:
        DataFrame   : Data frame containing the "time" of the maximum number of
                      lineages.

    """

    # Initialize output dataframe
    t_max_Ls_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        t_max_Ls_df.loc[name, 't_max_lineages'] = max(LTTs[name], key=LTTs[name].get)

    # Finalize and return
    return  t_max_Ls_df
