import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, normalize_param
from phylomodels.features.trees.helper.get_node_properties import is_semipreterminal, is_preterminal

@tree_param
@attr_param
#TODO normalize somehow
def smallConfig_calculate_pitchforks(trees, attr, attr_values, **kwargs):
    """
    Return the number of nodes with a cherry (2 tips as child) and a ladder of
    size one as children. Currently, we are not checking if the tree is
    bifurcating so we are really checking for internal nodes with tip child and
    a preterminal child. If an attribute is suppled this fraction is also
    calculated conditionally for each value of the attribute.
    Rosenberg Annals of Combinatorics 10 p.129-146 (2006)

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use in
                                conditionally calculating the statistic.
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and
                                building a list of values found in them.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics.

    Returns:
        DataFrame             : Data frame containing the number of nodes are
                                the stem of pitchforks for the tree and if attr
                                is provided the conditional fraction of nodes
                                in pitchfork_arrays based on the node attribute
                                (as different columns). Each tree having its
                                own row.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    picchforks_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        pitchfork_array = []
        node_attrs      = []
        for node in tree.traverse('levelorder'):
            if not node.is_leaf():
                # If we require bifurcating this can be simplified
                if is_semipreterminal(node) and not is_preterminal(node) and any(is_preterminal(child) for child in node.children) and all(is_preterminal(child) or child.is_leaf() for child in node.children):
                    pitchfork_array.append(True)
                else:
                    pitchfork_array.append(False)
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        pitchfork_array = np.array(pitchfork_array)

        if normalize:
            picchforks_df.loc[name, 'pitchforks'] = np.sum(pitchfork_array)/len(pitchfork_array)
        else:
            picchforks_df.loc[name, 'pitchforks'] = np.sum(pitchfork_array)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                if normalize:
                    # If pitchfork_array[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        picchforks_df.loc[name, 'pitchforks_' + attr_value] = np.sum(pitchfork_array[idx])/np.sum(idx)
                    else:
                        picchforks_df.loc[name, 'pitchforks_' + attr_value] = 0.0
                else:
                    # If pitchfork_array[idx] returns an empty array the numpy functions will fail
                    if np.any(idx):
                        picchforks_df.loc[name, 'pitchforks_' + attr_value] = np.sum(pitchfork_array[idx])
                    else:
                        picchforks_df.loc[name, 'pitchforks_' + attr_value] = 0.0

    # Finalize and return
    return picchforks_df
