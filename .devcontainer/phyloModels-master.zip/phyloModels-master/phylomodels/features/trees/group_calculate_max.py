import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param, groups_param, normalize_param

@tree_param
@attr_param
@groups_param
def group_calculate_max(trees, attr, attr_values, group_sizes, **kwargs):
    """
    Return the maximum group size, where a group is defined as a connected
    group of nodes with the same value for an attribute. If no attribute is
    given the function will determine that all nodes belong to the same group
    and return the number of nodes (instead of throwing an error).

    Args:
        trees (dict)          : The dict of trees to calculate the statistic
                                from.
        attr (str)            : Optional. The name of the attribute to use in
                                conditionally calculating the statistic.
        attr_values (ndarray) : Optional. List of the unique values that attr
                                could take (or at least the ones we are
                                interested) in. If not provided it will be
                                calculated by looping over all trees and
                                building a list of values found in them.
        group_sizes (dict)    : Optional. The dictionary with the list of group
                                sizes for each value of the provided attribute.
        normalize_param (bool): Optional. Whether or not to normalize the
                                statistics based on the number of nodes.

    Returns:
        DataFrame             : The maximum group size for each value of the
                                provided attribute.

    """

    # Process optional arguements
    normalize, kwargs = normalize_param(**kwargs)

    # Initialize output dataframe
    group_max_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        num_nodes = len(list(tree.traverse("levelorder")))
        if normalize:
            group_max_df.loc[name, 'group_max'] = 1  # num_nodes/num_nodes
        else:
            group_max_df.loc[name, 'group_max'] = num_nodes
        if attr:
            groups = group_sizes[name]
            for key, group in groups.items():
                if normalize:
                    if len(group)<1:
                        group_max_df.loc[name, 'group_max_' + key] = 0
                    else:
                        group_max_df.loc[name, 'group_max_' + key] = max(group)/sum(group)
                else:
                    if len(group)<1:
                        group_max_df.loc[name, 'group_max_' + key] = 0
                    else:
                        group_max_df.loc[name, 'group_max_' + key] = max(group)

    return group_max_df
