import numpy as np
from phylomodels.features.trees.helper.process_optional_arguements import tree_param

@tree_param
def get_LTT(trees):
    """
    Returns a dictionary representing the lineages through time plot for each
    tree that is in the input dictionary of trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.

    Returns:
        dict                     : A dictionary with each key being one of the
                                   input trees. The value is a dictionary
                                   representation of the lineage through time
                                   plot.

    """

    ## Check if we got a dict or a single tree
    #if not isinstance(trees, dict):
    #    trees = {"tree": trees}

    # Initialize dictionary for output
    LTTs = {}

    # Compute the LTT "plot"
    for name, tree in trees.items():
        depths = []
        nodes = []
        for node in tree.traverse('levelorder'):
            depths.append( tree.get_distance(node, topology_only=False) )
            nodes.append( node )
        depths = np.array(depths)
        nodes = np.array(nodes)
        idx = np.argsort(depths)
        depths = depths[idx]
        nodes = nodes[idx]
        LTT = {}
        num_lin = 1
        for i in np.arange(len(depths)):
            LTT[depths[i]] = num_lin + len(nodes[i].children) - 1
            num_lin = LTT[depths[i]]
        LTTs[name] = LTT

    return {'LTTs': LTTs}
