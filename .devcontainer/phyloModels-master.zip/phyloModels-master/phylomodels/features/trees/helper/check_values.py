import numpy as np
from pandas import isna

def check_branch_lengths(branch_lengths):
    if np.any(branch_lengths < 0):
        raise Exception('The tree has negative (< 0) branch lengths. This should not happen.')
    if np.any(isna(branch_lengths)):
        raise Exception('The tree has undefined (NaN) branch lengths. This should not happen.')

