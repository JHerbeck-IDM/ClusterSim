
def is_semipreterminal(node):
    """
    Return whether a node is semipreterminal or not. Being semipreterminal
    means that at least one of your children is a leaf node, but the other
    child(ren) can be leaf nodes or internal nodes.

    Args:
        Node (TreeNode): The node to check.

    Returns:
        bool           : Boolean answering whether the node is semipreterminal.

    """

    if len(node.children) < 1:
        return False
    return any(child.is_leaf() for child in node.children)

def is_preterminal(node):
    """
    Return whether a node is preterminal or not. Being preterminal means that
    all your children are leaf nodes.

    Args:
        Node (TreeNode): The node to check.

    Returns:
        bool           : Boolean answering whether the node is preterminal.

    """

    if len(node.children) < 1:
        return False
    return all(child.is_leaf() for child in node.children)
