import numpy as np

def unique_node_attr(trees, attr):
    """
    Return a list of unique attribution values (of attr) from all trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to explore attr
                                   values of.

    Returns:
        ndarray                 : A list of unique attribute values that attr
                                  takes among all the trees.

    """

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Loop through all trees and get a list of unique attribute values
    attr_values = []
    for name, tree in trees.items():
        node_attrs = []
        for node in tree.traverse():
            node_attrs.append(getattr(node, attr, "None"))
        node_attrs = np.array(node_attrs)
        attr_values = np.concatenate((attr_values, np.unique(node_attrs)))
    attr_values = np.unique(attr_values)

    return {'attr_values': attr_values}
