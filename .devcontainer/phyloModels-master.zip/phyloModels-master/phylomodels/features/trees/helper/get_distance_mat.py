import numpy as np

def get_distance_mat(trees, **kwargs):
    """
    Returns a dictionary containing the distance matrix for each tree that is
    in the input dictionary of trees.

    Args:
        trees (ete3.Tree or dict): The tree (or dict of trees) to calculate the
                                   statistic from.
        topology_only (bool)     : If set to True (default False) calculate the
                                   height using the "topology" (number of
                                   branches) instead of branch lengths.

    Returns:
        dict                     : A dictionary with each key being one of the
                                   input trees. The value is a the distance
                                   maxtrix for the tree.

    """

    def walk_up (nodes, curnode, pathlen, topology_only=False):
        """
        Recursive function for traversing up a tree.
        """
        if topology_only:
            pathlen += 1
            if curnode.is_leaf():
                nodes.append( (curnode.name, pathlen) )
            else:
                nodes.append( (curnode.name, pathlen) )
                for c in curnode.children:
                    nodes = walk_up(nodes, c, pathlen, topology_only)
        else:
            pathlen += curnode.dist
            if curnode.is_leaf():
                nodes.append( (curnode.name, pathlen) )
            else:
                nodes.append( (curnode.name, pathlen) )
                for c in curnode.children:
                    nodes = walk_up(nodes, c, pathlen, topology_only)

        return nodes
        
    def find_short_edges(tree, topology_only=False):
        """
        Find the shortest edge from the earliest sequence of a patient to a
        any sequence from any other patient.
        minimize = keep only edge from earliest seq to the closest other seq
        keep_ties = [to be used in conjunction with minimize]
                    report all edges with the same minimum distance
        """

        # generate dictionary of child->parent associations
        parents = {}
        for clade in tree.traverse('levelorder'):
            for child in clade.children:
                parents.update({child: clade})

        nodes = tree.get_descendants('levelorder')
        num_nodes = len(nodes)
        distance = np.zeros((num_nodes+1, num_nodes+1), dtype=np.float32)
        index = {tree.name: 0}
        count = 1
        for node in nodes:
            index.update({node.name: count})
            count += 1
            
        # Get distances from root
        node2 = walk_up([], tree, {True: -1, False: -tree.dist}[topology_only], topology_only)
        
        i = index[tree.name]
        for n2, dist in node2:
            j = index[n2]
            distance[i, j] = dist
        distance[i, i] = 0
        
        for node in nodes:
            i = index[node.name]
            j = index[parents[node].name]
            dist = {True: 1, False: node.dist}[topology_only]
            distance[i, :] = distance[j, :] + dist
            node2 = walk_up([], node, {True: -1, False: -node.dist}[topology_only], topology_only)
            
            
            for n2, dist in node2:
                j = index[n2]
                distance[i, j] = dist
            distance[i, i] = 0
                
        return distance

    # Check if we got a dict or a single tree
    if not isinstance(trees, dict):
        trees = {"tree": trees}

    # Check if topology_only was given
    if 'topology_only' in kwargs:
        topology_only = kwargs['topology_only']
    else:
        topology_only = False

    # If we are using the topology measure of height (instead of branch length)
    # change the feature name to reflect that
    if topology_only:
        feature_name = 'distance_mat_topology'
    else:
        feature_name = 'distance_mat'

    # Initialize dictionary for output
    distance_mats = {}

    # Compute the eigenvalues
    for name, tree in trees.items():
        distance = find_short_edges(tree, topology_only)
        distance_mats[name] = distance

    return {feature_name: distance_mats}
