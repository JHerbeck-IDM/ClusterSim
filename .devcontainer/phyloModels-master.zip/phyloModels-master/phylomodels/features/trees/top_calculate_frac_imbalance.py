import numpy as np
import pandas as pd
from phylomodels.features.trees.helper.process_optional_arguements import tree_param, attr_param

@tree_param
@attr_param
def top_calculate_frac_imbalance(trees, attr, attr_values, **kwargs):
    """
    Return the fraction of internal nodes that have different numbers of leaves
    on any of its children.
    Colijn and Gardy Evolution, Medicine, and Public Health 2014(1) p.96-108 (2014)

    Args:
        trees (dict)         : The dict of trees to calculate the statistic
                               from.
        attr (str)           : Optional. The name of the attribute to use in
                               conditionally calculating the statistic.
        attr_values (ndarray): Optional. List of the unique values that attr
                               could take (or at least the ones we are
                               interested) in. If not provided it will be
                               calculated by looping over all trees and buildng
                               a list of values found in them.

    Returns:
        DataFrame            : The fraction of internal nodes that are
                               imbalanced for the whole tree and if an attr is
                               provided conditionally for each unique value of
                               the attribute.
    """

    # Initialize output dataframe
    frac_imbalances_df = pd.DataFrame( {'tree_id': list(trees.keys())} ).set_index('tree_id')

    # Compute the statistic
    for name, tree in trees.items():
        leaf_not_equals = []
        node_attrs      = []
        for node in tree.traverse():
            if not node.is_leaf():
                children = node.children
                # Start by assuming the tree is not imbalanced (False)
                leaf_not_equals.append(False)
                # Loop there all pairs of children and check if they are imbalanced
                for i in np.arange(len(children)):
                    for j in np.arange(i+1, len(children)):
                        leaf_not_equals[-1] |= ( len(children[i]) != len(children[j]) )
                node_attrs.append(getattr(node, attr, "None")) if attr else None
        leaf_not_equals = np.array(leaf_not_equals)

        frac_imbalances_df.loc[name, 'frac_imbalance'] = np.mean(leaf_not_equals)
        if attr:
            node_attrs = np.array(node_attrs)
            for attr_value in attr_values:
                idx = attr_value==node_attrs
                # If leaf_not_equals[idx] returns an empty array the numpy functions will fail
                if np.any(idx):
                    frac_imbalances_df.loc[name, 'frac_imbalance_' + attr_value] = np.mean(leaf_not_equals[attr_value==node_attrs])
                else:
                    frac_imbalances_df.loc[name, 'frac_imbalance_' + attr_value] = 0.0

    # Finalize and return
    return frac_imbalances_df
