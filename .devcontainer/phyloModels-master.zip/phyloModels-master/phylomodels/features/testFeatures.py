import numpy
import pandas

from features import features


# Initialize variables
m = 2
n = 5
seed = 1000




# Generate test data
numpy.random.seed( seed=seed )
x = numpy.random.rand( m,n )
xref = numpy.random.rand( 1, n )

x_df    = pandas.DataFrame(x)     # Inputs must be pandas dataframes
xref_df = pandas.DataFrame(xref)

print("*** Test data: ***\n")
print(x_df)
print("\n")
print(xref_df)
print("******************\n")




# Create and manipulate object for features/summary statistics
f = features( x=x_df, xref=xref_df )

#f.listFeatures()
f.listActiveFeatures()
f.disableFeature(name="series_derivative")
f.listActiveFeatures()
f.disableFeature(group="all")
#f.enableFeature(0)
f.enableFeature(name="series_sum")
f.listActiveFeatures()

f.disableStatistic(name="skew")
f.disableStatistic(name="std")
f.enableStatistic(name="skew")

f.compute()
f.printFeatures(); print("\n")
#f.printFeatures( filename="f.csv" )
f.printStats()


quit()
