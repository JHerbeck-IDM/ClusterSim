import numpy
import pandas


def series_sum(x, *args):
    """
    Returns the sum of elements of each the time series as a pandas dataframe.
    """

    sum = x.sum( axis=1 )
    sum_df = pandas.DataFrame( {"sum_x": sum} )
    return sum_df
