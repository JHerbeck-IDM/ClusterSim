import numpy
import pandas
import math


def series_diff_Linf(x, xref):
    """
    Returns the L_{\inf} norm of the difference between each time series in x
    and xref. The output is a pandas dataframe.
    """

    m = len(x)
    diff = numpy.add( x, -numpy.repeat( xref, m, axis=0 ) )
    diff_Linf = numpy.linalg.norm( diff, ord=math.inf, axis=1 )
    diff_Linf_df = pandas.DataFrame( {"diff_Linf": diff_Linf} )
    return diff_Linf_df
