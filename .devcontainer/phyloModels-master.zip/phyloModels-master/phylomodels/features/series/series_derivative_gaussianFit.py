import numpy
import pandas


def series_derivative_gaussianFit(x, *args):
    """
    Returns the parameters of a Gaussian distribution that fits the
    derivative of the input time series. The output is a pandas dataframe.
    """

    dx   = numpy.gradient(x,  axis=1)
    mean = numpy.mean(dx, axis=1)
    var  = numpy.var(dx, axis=1)
    dxGaussianFit_df = pandas.DataFrame( { "dx_mean": mean,
                                           "dx_var" : var,
                                          }
                                        )
    return dxGaussianFit_df
