import numpy
import pandas


def series_partialSum30(x, *args):
    """
    Returns the time series obtained from adding up groups of 30 values from the
    input time series. The output is a pandas dataframe.
    """

    intervalSize = 30
    n = x.shape[1]
    nIntervals = int( numpy.floor( (n-1)/intervalSize ) )
    partialSum = numpy.full( (len(x), nIntervals+1), numpy.nan )
    for i in range(0,nIntervals):
        xSample = x[:, i*intervalSize:(i+1)*intervalSize]
        partialSum[:,i] = xSample.sum( axis=1 )
    xSample = x[:, nIntervals*intervalSize:n]
    partialSum[:,nIntervals] = xSample.sum( axis=1 )
    partialSum_df = pandas.DataFrame( partialSum )
    for i in partialSum_df:
        partialSum_df.rename( \
            columns={ partialSum_df.columns[i]: "partialSum"          \
                                                + str(intervalSize)   \
                                                + "_"                 \
                                                + str(i)              \
                     },
            inplace=True
        )
    return partialSum_df
