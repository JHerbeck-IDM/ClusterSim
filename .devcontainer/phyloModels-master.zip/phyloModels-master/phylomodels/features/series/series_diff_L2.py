import numpy
import pandas


def series_diff_L2(x, xref):
    """
    Returns the L2 norm of the difference between each time series in x and
    xref. The output is a pandas dataframe.
    """

    m = len(x)
    diff = numpy.add( x, -numpy.repeat( xref, m, axis=0 ) )
    diff_L2 = numpy.linalg.norm( diff, ord=2, axis=1 )
    diff_L2_df = pandas.DataFrame( {"diff_L2": diff_L2} )
    return diff_L2_df
