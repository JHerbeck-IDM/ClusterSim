import numpy
import pandas


def series_derivative(x, *args):
    """
    Returns the derivative of time series as a pandas dataframe.
    """

    dx = numpy.gradient(x, axis=1)
    dx_df = pandas.DataFrame(dx)
    for i in dx_df:
        dx_df.rename( columns={ dx_df.columns[i]: "dx_" + str(i) },
                      inplace=True
                     )
    return dx_df
