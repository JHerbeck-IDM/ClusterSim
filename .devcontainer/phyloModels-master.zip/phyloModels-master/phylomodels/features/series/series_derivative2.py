import numpy
import pandas


def series_derivative2(x, *args):
    """
    Returns the second derivative of time series as a pandas dataframe.
    """

    dx  = numpy.gradient(x,  axis=1)
    dx2 = numpy.gradient(dx, axis=1)
    dx2_df = pandas.DataFrame(dx2)
    for i in dx2_df:
        dx2_df.rename( columns={ dx2_df.columns[i]: "dx2_" + str(i) },
                      inplace=True
                     )
    return dx2_df
