"""
  Class for computation of features (i.e., summary statistics) obtained from
  both time series and graphs (i.e., trees), as well as statistics on these
  features.

  See features.md in the documentation folder for more information.

"""
# Python libraries (native, 3rd party)
import collections
import math
import numpy
import pandas
import scipy.stats
from pandas.api.types import is_numeric_dtype

# Python libraries (internal)
from phylomodels.features.inventory  import *






#-------------------------------------------------------------------------------
#   features
#-------------------------------------------------------------------------------
class features:
    def __init__( self,
                  x   : pandas.DataFrame = numpy.nan,  # Array of time series
                  xref: pandas.DataFrame = numpy.nan,  # Reference/baseline time series
                  g    = numpy.nan,  # Graph
                  gref = numpy.nan   # Reference/baseline graph
                 ):

        """Create new features object.
        Args:
         x   : Time series table. This is a Pandas DataFrame containing
               numeric data. Each row of this table contains a time series.
               Column t, t=0,1,... of the table contains the values at time
               t.
         xref: Reference time series. This is a Pandas DataFrame with the
               same number of columns of x, but with only one row (i.e.,
               only one time series).
         g   : List of graphs. A graph (or, alternatively, a tree, or a
               network) is a NetworkX element.
         gref: Reference graph in NetworkX format.
        """
        # Verify inputs
        if not isinstance(x, pandas.DataFrame) or not isinstance(xref, pandas.DataFrame):
            raise ValueError("Both x and xref must be Pandas DataFrame.\n")
        elif x.empty or xref.empty:
            raise ValueError("Both x and xref should not be empty DataFrame.\n")
        else:
            x_filter_table = x.isin([numpy.nan, numpy.inf, -numpy.inf])
            if x_filter_table.values.sum():
                # drop rows that contains Nan, inf or -inf
                print("Warning: some rows in x contains Nan, inf or -inf, removing these rows.")
                x = x[~x_filter_table.any(1)]

            if xref.isin([numpy.nan, numpy.inf, -numpy.inf]).values.sum():
                raise ValueError("xref should not contains NaN or infinite data.\n")

        for df in [x, xref]:
            for index, row in df.iterrows():
                if not is_numeric_dtype(row):
                    raise ValueError("Both x and xref should only contain numeric data.\n")
        # ToDo: Verify graph inputs

        # Parameters and constants
        nFeatures = 100
        nStats = 100
        featureCard \
            = collections.namedtuple(
                    "featureCard",
                    ["id", "name", "description", "subroutine"]
              )

        # Allocate/initialize arrays/dataframes
        self.availableFeatures = []
        self.availableStats = []
        self.activeFeatures =numpy.full(nFeatures, fill_value=False, dtype=bool)
        self.activeStats = numpy.full(nStats, fill_value=False, dtype=bool)
        self.f = pandas.DataFrame()
        self.fStats = pandas.DataFrame()

        # Initialize variables: Read inputs
        self.x    = x
        self.xref = xref
        self.g    = g
        self.gref = gref

        # Data transformations
        self.x_np    = x.to_numpy(copy=True)
        self.xref_np = xref.to_numpy(copy=True)

        # Populate list of available features and statistics
        self.availableFeatures, self.nAvailableFeatures \
                           = populateAvailableFeatures( self.availableFeatures )
        self.availableStats, self.nAvailableStats \
                           = populateAvailableStatistics( self.availableStats )

        # Enable all features
        self.enableFeature( group="all" )
        self.enableStatistic( group="all" )




    #==== Core operations ======================================================

    def compute( self ):

        del self.f
        del self.fStats
        self.f = pandas.DataFrame()
        self.fStats = pandas.DataFrame()

        # Compute features
        for i in range(0,self.nAvailableFeatures):
            if (self.activeFeatures[i] == True):

                currentSubroutine = self.availableFeatures[i].subroutine
                xPartial_df = currentSubroutine( self.x_np,
                                                 self.xref_np
                                                 )
                self.f = pandas.concat( [self.f, xPartial_df], axis=1 )


        # Compute feature statistics
        for i in range(0,self.nAvailableStats):
            if (self.activeStats[i] == True):

                currentSubroutine = self.availableStats[i].subroutine
                fStatsPartial_df = currentSubroutine( self.f )
                self.fStats = pandas.concat( [self.fStats, fStatsPartial_df],
                                             axis=1
                                            )


        return self.f, self.fStats


    def get( self ):
        return self.f, self.fStats




    #==== Feature inventory management =========================================

    def enableFeature( self, id=None, name=None, group=None ):

        if (id != None):   # Enable by ID
            self.activeFeatures[id] = True

        elif (name != None): # Enable by name
            for i in range(0, self.nAvailableFeatures):
                if (self.availableFeatures[i].name == name):
                    self.activeFeatures[i] = True
                    break

        else: # Enable by group
            if (group == "all"):
                for i in range(0,self.nAvailableFeatures):
                    self.activeFeatures[i] = True


    def disableFeature( self, id=None, name=None, group=None ):

        if (id != None):   # Disable by ID
            self.activeFeatures[id] = False

        elif (name != None):    # Disable by name
            for i in range(0, self.nAvailableFeatures):
                if (self.availableFeatures[i].name == name):
                    self.activeFeatures[i] = False
                    break

        else: # Disable by group
            if (group == "all"):
                for i in range(0,self.nAvailableFeatures):
                    self.activeFeatures[i] = False


    def enableStatistic( self, id=None, name=None, group=None ):

        if (id != None):   # Enable by ID
            self.activeStats[id] = True

        elif (name != None): # Enable by name
            for i in range(0, self.nAvailableStats):
                if (self.availableStats[i].name == name):
                    self.activeStats[i] = True
                    break

        else: # Enable by group

            if (group == "all"):
                for i in range(0, self.nAvailableStats):
                    self.activeStats[i] = True


    def disableStatistic( self, id=None, name=None, group=None ):

        if (id != None):   # Disable by ID
            self.activeStats[id] = False

        elif (name != None):    # Disable by name
            for i in range(0, self.nAvailableStats):
                if (self.availableStats[i].name == name):
                    self.activeStats[i] = False
                    break

        else: # Disable by group

            if (group == "all"):
                for i in range(0,self.nAvailableStats):
                    self.activeStats[i] = False

    #==== Utilities ============================================================

    def getArguments( self ):
        return self.x, self.xref, self.g, self.gref


    def listFeatures( self ):
        print( "availableFeatures = \n" )
        for i in range(0,self.nAvailableFeatures):
            print( "id         : ", self.availableFeatures[i].id          )
            print( "name       : ", self.availableFeatures[i].name        )
            print( "description: ", self.availableFeatures[i].description )
            print( "subroutine : ", self.availableFeatures[i].subroutine  )
            print( "\n" )


    def listActiveFeatures( self ):
        print( "activeFeatures = " )
        print( "  id \t feature" )
        print( "-"*72 )
        for i in range(0,self.nAvailableFeatures):
            if (self.activeFeatures[i] == True):
                print( "  ", i, "\t", self.availableFeatures[i].name )
        print("\n")


    def listActiveStats( self ):
        print( "activeStats = " )
        print( "  id \t statistic" )
        print( "-"*72 )
        for i in range(0,self.nAvailableStats):
            if (self.activeStats[i] == True):
                print( "  ", i, "\t", self.availableStats[i].name )
        print("\n")


    def printArguments( self ):
        print( "x =    \n"   , self.x   , "\n" )
        print( "xref = \n", self.xref   , "\n" )
        print( "g =    \n"   , self.g   , "\n" )
        print( "gref = \n", self.gref          )


    def printFeatures( self, filename=None ):
        print( "f = \n", self.f )
        if (filename != None):
            self.f.to_csv( filename )


    def printStats( self, filename=None ):
        print( "fStats = \n", self.fStats )
        if (filename != None):
            self.fStats.to_csv( filename )




