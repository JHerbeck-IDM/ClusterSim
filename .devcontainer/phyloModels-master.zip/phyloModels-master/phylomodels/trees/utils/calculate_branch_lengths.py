
def calculate_branch_lengths(in_trees, inplace=False):
    """
    Calculate branch lengths from the time attribute of each node.

    Args:
        in_trees (list)  : The node of the tree that contains the current
                           infector.
        inplace (boolean): Optional (default False). Whether to do an inplace
                           branch calculation or to return a new set of trees.

    Returns:
        out_trees (list) : The function will do an inplace edit of the trees or
                           return a list with copies of the trees.
    """

    if not hasattr(in_trees, "__len__"):
        in_trees = [in_trees]
        
    if inplace:
        out_trees = in_trees
    else:
        out_trees = []
        for tree in in_trees:
            out_trees.append(tree.copy('deepcopy'))
        
    for tree in out_trees:
        tree.dist = 0
        for node in tree.iter_descendants():
            node.dist = getattr(node, 'time') - getattr(node.up, 'time')
                
    if not inplace:
        return out_trees

