from ete3 import Tree
from numpy import isnan

def clone_node(node_in):
    """
    Take in a TreeNode and create a copy of it (copies all features) without
    its connections (parent or children).
    
    Args:
        node_in (TreeNode): A ete3 TreeNode to clone.

    Returns:
        TreeNode          : The clone of the node passed in.
        
    """
    
    # Create a node
    node_out = Tree(name=getattr(node_in, 'name', None))
    
    # Clone a node (not cloning descendents)
    features = node_in.features
    for feature in features:
        value = getattr(node_in, feature)
        try:
            if not isnan(value):
                node_out.add_feature(feature, getattr(node_in, feature))
        except TypeError:
            node_out.add_feature(feature, getattr(node_in, feature))
        
    return node_out

