import numpy as np
from ete3 import Tree

def getPopSize(trees, **kwargs):
    """
    Estimate the population size for each disconnected tree. We will then add
    the population sizes together to estimate the population size for the full
    connected tree.

    Args:
        trees (list): List of ete3 trees to join together into one tree.

    Returns:
        float      : The total (effective) population size.

    """

    pop_size = np.zeros(len(trees))

    for i in range(len(trees)):
        # We need to iterate over the tree by time.
        times = []
        nodes = []
        num_leaves = 0
        for node in trees[i].traverse(strategy='levelorder'):
            times.append(node.time)
            nodes.append(node)
            num_leaves += node.is_leaf()

        # Get the indices needed for the time array to be
        # sorted.
        idx_sort = np.argsort(times)
        N = 0
        k = len(trees[i].children)
        # Iterate forward (skipping the root node) keeping
        # track of the number of lineages and calculating
        # the appropriate contribution to the MLE theta estimate.
        for idx in range(1,len(idx_sort)):
            N += k*(k-1)*(times[idx_sort[idx]] - times[idx_sort[idx-1]])
            k = k - 1 + len(nodes[idx_sort[idx]].children)

        # Normalize based on number of coalescent events
        if num_leaves>1:
            pop_size[i] = N/(num_leaves-1)
        else:
            # If there is only one linage we will get
            # a divide by zero error. Instead set
            # N to 0 for this subtree.
            pop_size[i] = 0

    # Sum the individual population estimates from
    # each tree
    N = sum(pop_size)

    return N

def joinUsingConstantCoalescent(trees):
    """
    Coalesce trees together using serial-sample coalescence (assuming constant
    population size).
    
    Args:
        trees (list): List of ete3 trees to join together into one tree.

    Returns:
        Tree        : An ete3 tree containing the trees that were passed in.
        
    """
    
    # Estimate population size
    N = getPopSize(trees)

    # Randomly coalesce roots until there
    # is only one.
    k = len(trees)
    for i in range(1,k):
        nodes = np.random.choice(trees, size=2, replace=False)
        new_node = 'JOIN_' + str(nodes[0].name) + '_' + str(nodes[1].name)
        t = min(nodes[0].time, nodes[1].time) - np.random.exponential(N/(k*(k-1)))
        new_tree = Tree(name=new_node)
        new_tree.add_feature('time', t)
        new_tree.add_child(nodes[0])
        new_tree.add_child(nodes[1])
        nodes[0].dist = nodes[0].time - new_tree.time
        nodes[1].dist = nodes[1].time - new_tree.time
        trees.append(new_tree)
        trees.remove(nodes[0])
        trees.remove(nodes[1])
        
    return trees[0]

def joinUsingStar(trees):
    """
    Join all subtrees directly into a single root node which is at the earlist
    root.
    
    Args:
        trees (list): List of ete3 trees to join together into one tree.

    Returns:
        Tree        : An ete3 tree containing the trees that were passed in.
        
    """
   
    # Find the time of the earliest root
    min_time = trees[0].time
    for tree in trees:
        min_time = min(min_time, tree.time)

    # Create root
    new_tree = Tree(name='ROOT', dist=0)
    new_tree.add_feature('time', min_time)

    # Loop through trees and add them as children of the root
    for tree in trees:
        new_tree.add_child(tree)
        tree.dist = tree.time - new_tree.time
        
    return new_tree
    
def transform_joinTrees(trees, method='constant_coalescent', **kwargs):
    """
    Taking in a list of trees (transmission chains) join them together into a
    single tree according to requested method. For now we only have serial-
    sample coalescence (assuming constant population size) implemented.
    
    Args:
        trees (list): List of ete3 trees to join together into one tree.
        method (str): Optional (default 'constant_coalescent'). The name of the
                      to use for joining the trees
                          constant_coalescent - coalescent roots of trees
                              together drawing branch lengths from an
                              exponential distribution (assumes constant
                              populaiton size).
                    TODO add more methods

    Returns:
        Tree        : An ete3 tree containing the trees that were passed in.
        
    """
    
    # Create a copy of the trees
    trees_copy = []
    for tree in trees:
        if tree:
            trees_copy.append(tree.copy('deepcopy'))
        
    if method.casefold() == 'constant_coalescent'.casefold():
        combined_tree = joinUsingConstantCoalescent(trees_copy)
    elif method.casefold() == 'star'.casefold():
        combined_tree = joinUsingStar(trees_copy)
    else:
        print('ERROR: ', method, ' not an implemented or recongized method.')

    return combined_tree
