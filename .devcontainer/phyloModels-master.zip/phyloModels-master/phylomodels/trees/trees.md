# **trees**

The **trees** module contains a set of functions for creating, modifying, and
uses trees. 

Several types of tasks that can be done using the functions in this module, 
namely:

* **generating trees** (e.g., reading from files, converting into 
  phyloModels' standard format, creating trees with particular 
  characteristics/topologies);
  
* **transforming trees** (e.g., building a phylogenetic tree from a 
  transmission tree); and
  
* **extracting subtrees** (e.g., extracting the subset of a tree that 
  satisfies a particular property, extracting a randomply-sampled subtree).




## File structure

This directory is organized as a collection of python files. Each file should 
contain __only one__ function executing __only one__ of the tasks described 
above (each file could contain any number of auxiliary functions, but only one
is designed for being called directly by the library user). The name of this
function must the same name of the file that contains it (without the `.py` file
extension). 

*Example*: The file called `generate_tree_balanced.py` contains a function 
called ``generate_tree_balanced()`. This function generates a perfectly balanced
tree based on some input parameters.

In addition to the collection of python files, subroutines that are used by more
than one function should be coded in separate files. These files should be 
placed in a subdirectory whose name describes the type of operation that is
being done. The name of the subdirectories are:

* `networks/io`, which contains functions for reading or writing from/to files;

* `networks/utils`, for generic operations on trees;

* `networks/misc`, for any other type of operation.




## Naming conventions

Functions in the `trees` module should be named as follows:
```
    [type of function]_[descriptive name of the function]
```
with:

* `type of function` indicating the type of operation being done. It can be:
  - `generate`, for the generation of trees;
  - `transform`, for transformations on trees; or
  - `extract`, for subtree extraction.

The following are examples of functions that could be part of the `networks`
module:
```
    generate_treeFromNewickFile
    generate_balancedTree
    transform_transmissionToPhylogeneticTree
    extract_NodeAttributeFilter
```



## Inputs

Each function may receive any number of input arguments. The following 
conditions should be satisfied:

* Any input that is a tree or list of trees must be formatted as an ete3
  tree.
  
* Inputs must not be modified neither by functions nor by subroutines unless
  'inplace' is True.


## Outputs

Each function returns a single output. The output is an ete3 tree, or list of
trees. Auxiliary subroutines may return any number of outputs.
