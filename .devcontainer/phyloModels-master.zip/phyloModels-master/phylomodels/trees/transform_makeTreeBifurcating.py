import numpy as np
from ete3 import Tree
from phylomodels.trees.utils.calculate_branch_lengths import calculate_branch_lengths
from phylomodels.trees.utils.clone_node import clone_node
   
def transform_makeTreeBifurcating(tree_in, **kwargs):
    """
    Taking a (transmission or phylogenetic) tree and adding "fake" nodes to
    resolve polytomies and monotomies. These changes can be done in place or
    (default) in a copy of the tree.
    
    Args:
        tree_in (Tree)   : An ete3 tree that needs to become bifurcating.
        inplace (boolean): Optional (default False). Whether to do an inplace
                           edit of the tree or create a copy of the tree.

    Returns:
        Tree             : An ete3 bifurcating tree.
        
    """
    #TODO should we prune monotomies instead of making them leaves?
    
    inplace = kwargs.pop('inplace', False)
    if inplace:
        tree_out = tree_in
    else:
        tree_out = tree_in.copy('deepcopy')

    nodes = [tree_out] + tree_out.get_descendants('levelorder')
    for node in nodes:
        children = node.children
        while(len(children)!=0 and len(children)!=2):
            if len(children) > 2:
                new_node = clone_node(node)
                new_node.name = node.name + '_desc'
                node.add_child(new_node)
                new_node.dist = 0
                #TODO based on some simple tests I determined that new children
                # are added on the back so the first two children should be
                # original children, but there is nothing specifying this in
                # the docs so we should do something more defensive here.
                child1 = node.children[0]
                child2 = node.children[1]
                child1.detach()
                new_node.add_child(child1)
                child2.detach()
                new_node.add_child(child2)
            elif len(children) == 1:
                if node.up:
                    node.up.add_child(node.children[0])
                    node.detach()
                    break
                else:
                    tree_out = node.children[0].detach()
                    break
                
    calculate_branch_lengths([tree_out], inplace=True)

    if not inplace:
        return tree_out
