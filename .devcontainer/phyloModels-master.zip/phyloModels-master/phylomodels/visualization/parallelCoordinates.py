
# Python libraries (native, 3rd party)
import numpy
import pandas
import matplotlib
from matplotlib import pyplot as plt
#matplotlib.pyplot.switch_backend('TKAgg')




#-------------------------------------------------------------------------------
#   parallelCoordinates
#-------------------------------------------------------------------------------
def parallelCoordinates( x     : pandas.DataFrame,
                         xInfo : pandas.DataFrame,
                         c    = None,
                         clog = False
                        ):
    """
    Draw a parallel coordinates plot.

    Args:
     x     : Pandas DataFrame. Each row contains a set of values that define a
             curve in the parallel coordinate plot.
     xInfo : Pandas DataFrame. Each row in this dataframe defines a coordinate
             to display. The following columns of the dataframe characterize
             each coordinate axis:
             
             Name
                (required) Name of the axis. There must be a column
                in dataframe "x" with this name.
             Min
                (required) Lower bound of the axis.
             Max
                (required) Upper bound of the axis.
             logaxis
                (optional) Boolean indicating of a logarithmic axis
                should be used (when set to True). Otherwise the axis
                uses a linear scale.
             revaxis
                (optional/experimental) Boolean indicating if the
                axis should be reversed. At this point, only the last
                (coordinate) axis can be reversed, and only when the
                next to last axis is using a logarithmic scale. Any
                other case is not supported yet.

     c     : (optional) Name of column of x that defines a scale to be used in
             the colormap.
     clog  : (optional) Boolean indicating if a log scale should be used for
             the colormap.
    """

    # Initialization
    nParams   = len(xInfo)
    nSubplots = nParams - 1
    if c:   # Get weight, a normalized value between 0 and 1 based on a column
            # in "x" called as defined by string "c"
        if clog:
            weight_values = numpy.log10( x[c].to_numpy().flatten() )
        else:
            weight_values = x[c].to_numpy().flatten()

        weight_min = numpy.amin( weight_values )
        weight_max = numpy.amax( weight_values )
        weight_range = weight_max - weight_min
        weight = numpy.divide( weight_values-weight_min, weight_range )
    else:
        weight = numpy.nan


    # Generate plot
    plt.figure(frameon=False)
    for i in range(1,nParams):

        # Create subplot
        plt.subplot( 1, nParams, i )

        # Get data and parameters for left coordinate
        xLeft_name    = xInfo["Name"][i-1]
        xLeft_min     = xInfo["Min" ][i-1]
        xLeft_max     = xInfo["Max" ][i-1]
        xLeft_values  = x[xLeft_name].to_numpy().flatten()
        xLeft_logaxis = xInfo["logaxis"][i-1]  if "logaxis" in xInfo  else False
        xLeft_revaxis = xInfo["revaxis"][i-1]  if "revaxis" in xInfo  else False

        # Get data and parameters for right coordinate
        xRight_name    = xInfo["Name"][i]
        xRight_min     = xInfo["Min" ][i]
        xRight_max     = xInfo["Max" ][i]
        xRight_values  = x[xRight_name].to_numpy().flatten()
        xRight_logaxis = xInfo["logaxis"][i]  if "logaxis" in xInfo  else False
        xRight_revaxis = xInfo["revaxis"][i]  if "revaxis" in xInfo  else False

        # Draw subplot
        drawParallelCoordinatesPair(  xLeft_name,
                                      xLeft_min,
                                      xLeft_max,
                                      xLeft_values,
                                      xLeft_logaxis,
                                      xLeft_revaxis,
                                      xRight_name,
                                      xRight_min,
                                      xRight_max,
                                      xRight_values,
                                      xRight_logaxis,
                                      xRight_revaxis,
                                      weight
                                    )


    # Draw last coordinate
    plt.subplot( 1, nParams, nParams )
    plt.plot( [0, 0.01], [numpy.nan, numpy.nan] )

    plt.xlim( 0, 1 )
    plt.xticks([])

    plt.ylim( xRight_min, xRight_max )
    plt.ylabel( xRight_name )
    if xRight_logaxis:
        plt.yscale("log")

    ax = plt.gca()
    ax.yaxis.set_label_coords(0, 1.1)
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if xRight_revaxis:
        ax.invert_yaxis()


    # Final formatting
    if c:
        cax = plt.gcf().add_axes([0.8, 0.12, 0.02, 0.7]) # [x0,y0,width,height]
        cmap = matplotlib.cm.bone
        norm = matplotlib.colors.Normalize(vmin=weight_min, vmax=weight_max)
        colorbar = matplotlib.colorbar.ColorbarBase( cax, cmap=cmap, norm=norm )
        if clog:
            colorbar.set_label( "log10(" + c + ")" )
        else:
            colorbar.set_label(c)

    plt.subplots_adjust(wspace=0, hspace=0)


    # Finalize and return
    return




#-------------------------------------------------------------------------------
#   drawParallelCoordinatesPair
#-------------------------------------------------------------------------------
def drawParallelCoordinatesPair( xLeft_name,
                                 xLeft_min,
                                 xLeft_max,
                                 xLeft_values,
                                 xLeft_logaxis,
                                 xLeft_revaxis,
                                 xRight_name,
                                 xRight_min,
                                 xRight_max,
                                 xRight_values,
                                 xRight_logaxis,
                                 xRight_revaxis,
                                 weight
                                ):
    """
    Draw curves within a pair of parallel coordinates.
    """

    # Initialization
    axisId = [0, 1]  # x-axis in plots (0: left coordinate; 1: right coordinate)
    n = len( xLeft_values )


    # Prepare data (apply transformations as needed)
    dataLeft  = xLeft_values
    dataRight = getRightCoordinateValues( xRight_values,
                                          n,
                                          xLeft_min,
                                          xLeft_max,
                                          xLeft_logaxis,
                                          xLeft_revaxis,
                                          xRight_min,
                                          xRight_max,
                                          xRight_logaxis,
                                          xRight_revaxis
                                         )


    # Draw lines
    for j in range(n-1, -1, -1): # Draw the "best" cases last
        if numpy.isnan( weight ).any():
            plt.plot( axisId, [dataLeft[j], dataRight[j]] )
        else:
            plt.plot( axisId,
                      [dataLeft[j], dataRight[j]],
                      c = matplotlib.cm.bone( weight[j] )
                     )


    # Format figure
    plt.xlim( 0, 1 )
    plt.xticks([])

    plt.ylim( xLeft_min, xLeft_max )
    plt.ylabel( xLeft_name )
    if xLeft_logaxis:
        plt.yscale("log")

    ax = plt.gca()
    ax.yaxis.set_label_coords(0, 1.1)
    ax.spines["top"].set_visible(False)
    ax.spines["bottom"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if xLeft_revaxis:
        ax.invert_yaxis()


    # Finalize and return
    return




#-------------------------------------------------------------------------------
#   getRightCoordinateValues
#-------------------------------------------------------------------------------
def getRightCoordinateValues( x, n, srcMin, srcMax, srcLogAxis, srcRevAxis,
                                    dstMin, dstMax, dstLogAxis, dstRevAxis
                             ):
    """
    Transform right-coordinate values to match the left-coordinate axis.
    """

    if srcLogAxis:
        if dstLogAxis:
            if dstRevAxis:
                y = getRightCoordinateValuesLogRevLogSrc( x, n,
                                                          srcMin, srcMax,
                                                          dstMin, dstMax
                                                         )
            else:
                y = getRightCoordinateValuesLinear( x, n,
                                                    srcMin, srcMax,
                                                    dstMin, dstMax
                                                   )
        else:
            y = getRightCoordinateValuesLogSrc( x, n,
                                                srcMin, srcMax,
                                                dstMin, dstMax
                                               )
    else:   # linear axis on src
        if dstLogAxis:
            y = getRightCoordinateValuesLog( x, n,
                                             srcMin, srcMax,
                                             dstMin, dstMax
                                            )
        else:
            y = getRightCoordinateValuesLinear( x, n,
                                                srcMin, srcMax,
                                                dstMin, dstMax
                                               )
    return y




#-------------------------------------------------------------------------------
#   point-wise tranformations
#-------------------------------------------------------------------------------
def getRightCoordinateValuesLinear( x, n, srcMin, srcMax, dstMin, dstMax ):
    y = numpy.zeros(n)
    srcRange = srcMax - srcMin
    dstRange = dstMax - dstMin
    for j in range(0,n):
        xNormalized = ( x[j] - dstMin ) / dstRange
        y[j] = srcMin + srcRange*xNormalized
    return y


def getRightCoordinateValuesLog( x, n, srcMin, srcMax, dstMin, dstMax ):
    y = numpy.zeros(n)
    srcRange = srcMax - srcMin
    dstBase = numpy.log10(dstMin)
    dstRange = numpy.log10(dstMax) - numpy.log10(dstMin)
    for j in range(0,n):
        xNormalized = ( numpy.log10(x[j]) - dstBase ) / dstRange
        y[j] = srcMin + srcRange*xNormalized
    return y


def getRightCoordinateValuesLogSrc( x, n, srcMin, srcMax, dstMin, dstMax ):
    y = numpy.zeros(n)
    srcLogMin = numpy.log10(srcMin)
    srcLogMax = numpy.log10(srcMax)
    srcLogRange = srcLogMax - srcLogMin
    dstRange = dstMax - dstMin
    for j in range(0,n):
        xNormalized = ( x[j] - dstMin ) / dstRange
        y[j] = 10**( srcLogMin + srcLogRange*xNormalized )
    return y


def getRightCoordinateValuesLogRevLogSrc( x, n, srcMin, srcMax, dstMin, dstMax ):
    y = numpy.zeros(n)
    srcLogMin = numpy.log10(srcMin)
    srcLogMax = numpy.log10(srcMax)
    srcLogRange = srcLogMax - srcLogMin
    dstLogMin = numpy.log10(dstMin)
    dstLogMax = numpy.log10(dstMax)
    dstLogRange = dstLogMax - dstLogMin
    for j in range(0,n):
        xNormalized = 1 - ( numpy.log10(x[j]) - dstLogMin ) / dstLogRange
        y[j] = 10**( srcLogMin + srcLogRange*xNormalized )
    return y


def getRightCoordinateValuesRevLogSrc( x, n, srcMin, srcMax, dstMin, dstMax ):
    y = numpy.zeros(n)
    srcLogMin = numpy.log10(srcMin)
    srcLogMax = numpy.log10(srcMax)
    srcLogRange = srcLogMax - srcLogMin
    dstRange = dstMax - dstMin
    for j in range(0,n):
        xNormalized = 1 - ( x[j] - dstMin ) / dstRange
        y[j] = 10**( srcLogMin + srcLogRange*xNormalized )
    return y
