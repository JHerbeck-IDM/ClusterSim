# Python libraries (native, 3rd party)
import numpy
import pandas
import warnings
import logging


# Python libraries (IDM)
from history_matching import HistoryMatching,    \
                             HistoryMatchingCut, \
                             Basis


# Python libraries (internal)
import phylomodels.calibration.constants as constants


#-------------------------------------------------------------------------------
#   historyMatchingIteration
#-------------------------------------------------------------------------------
def historyMatchingIteration( iteration,
                              xInfo         : pandas.DataFrame,
                              x             : pandas.DataFrame,
                              yObservation,
                              yModel        : pandas.DataFrame,
                              params
                             ):
    """
      Execution of history matching a single history matching iteration using a
      basic set of parameters and a Poisson GLM basis.

      Args:
       iteration    : Integer indicating the iteration number. This number is
                      used by history matching for labeling output files.
       xInfo        : Name and range of model parameters. The columns of xInfo
                      are: "Name", "Min", and "Max", which refer to the name of
                      a parameter, its lower bound, and its upper bound,
                      respectively. Each row of xInfo contains information of
                      one model parameter.
       x            : Set of parameters to use for emulator fitting. These
                      parameters are used by history matching (see history
                      matching documentation for details on the characteristics
                      of x).
       yObservation : Scalar used by history matching for emulator fitting. This
                      value corresponds to the "desired_result" parameter in
                      history matching.
       yModel       : Simulation results used by history matching for emulator
                      fitting. This dataframe corresponds to the "results"
                      parameter in history matching.
       params       : Python dictionary with other history matching parameters.

    """

    # Read history matching parameters
    cutName                 = params.get("cut_name"                )
    yObservationSigma       = params.get("observation_uncertainty" )
    discrepancySigma        = params.get("model_discrepancy"       )
    implausibilityThreshold = params.get("implausibility_threshold")
    trainingFraction        = params.get("training_fraction"       )
    nCandidates             = params.get("n_candidates"            )
    if "glm_family" in params.keys():
        glmFamily = params.get("glm_family")
    else:
        glmFamily = "Poisson"


    # Set additional (hard-coded) history matching parameters
    glmBasis = Basis.polynomial_basis( params       =xInfo.index.values,
                                       intercept    = True,
                                       first_order  = True,
                                       second_order = False,
                                       third_order  = False,
                                       param_info   = xInfo
                                      )

    gprBasis = Basis.polynomial_basis( params      = xInfo.index.values,
                                       intercept   = False,
                                       first_order = True,
                                       param_info  = xInfo
                                      )


    # History matching init
    hm = HistoryMatching( cut_name                 = cutName,
                          param_info               = xInfo,
                          inputs                   = x,
                          results                  = yModel,
                          desired_result           = yObservation,
                          desired_result_var       = yObservationSigma**2,
                          iteration                = iteration,
                          implausibility_threshold = implausibilityThreshold,
                          discrepancy_var          = discrepancySigma**2,
                          training_fraction        = trainingFraction
                         )
    hm.save()


    # History matching computations
    try:
        # GLM Fit
        hm.glm( basis              = glmBasis,
                family             = glmFamily,
                force_optimize_glm = True,
                glm_fit_maxiter    = int(1e5),
                plot               = True,
                plot_data          = True
               )

        # GPR fit
        hm.gpr( basis              = gprBasis,
                force_optimize_gpr = True,
                optimize_sigma2_n  = True,
                log_transform      = True,
                verbose            = False,
                optimizer_options  = { "eps"     : 1e-3,
                                       "disp"    : False,  # Does this work?
                                       "maxiter" : int(1e5),
                                       "gtol"    : 1e-9,   # This was 1e16
                                      },  # "ftol" not used in log_transform
                plot               = True,
                plot_data          = True
               )


        # Compute implausibility
        hm.calc_and_plot_implausibility( plot              = True,
                                       do_plot_data        = True,
                                       plot_data_highlight = pandas.DataFrame(),
                                       log_scale           = True
                                      )
        hm.training_data.to_excel("train_data__iter" + str(iteration) + ".xlsx")
        hm.test_data.to_excel( "test_data__iter" + str(iteration) + ".xlsx" )


        # Select samples for next iteration
        hmc = HistoryMatchingCut( cut_dir = 'Cuts', iteration = iteration )
        ( nonImplausibleCandidates, rejectedPercent ) \
            = hmc.cut( num_desired_candidates = nCandidates, constraint = None )
        rejectionRate = rejectedPercent.get("Rejected Percent")
        status = constants.SUCCESS

    except Exception as e:  # Manage error conditions (when executing history
                            # matching operations

        logging.error( e, exc_info=True )
        warnings.warn( "An exception occurred during the execution of "    +  \
                       "history matching operations. Calibration process " +  \
                       "aborted:\n"                                        +  \
                        str(e)
                      )

        rejectionRate = numpy.nan
        status = constants.ERROR__HISTORY_MATCHING__UNCLASSIFIED_EXCEPTION


    # Finalize and return
    return rejectionRate, status

