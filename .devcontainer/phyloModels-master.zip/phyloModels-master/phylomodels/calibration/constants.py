"""
  Constant definitions for calibration functions.
"""


# Error conditions
SUCCESS = 0

WARNING__UNKNOWN = 1000

ERROR__UNKNOWN                                  = 2000
ERROR__HISTORY_MATCHING__UNCLASSIFIED_EXCEPTION = 2001




# Feature selection
FEATURE_SELECTION__QUARANTINE_PERIOD           = 8
FEATURE_SELECTION__CLOSE_CORRELATION_THRESHOLD = 0.90




# History matching
HISTORY_MATCHING__MAX_TRIALS = 10
