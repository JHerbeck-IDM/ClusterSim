"""
  Execution of history matching jobs using a basic set of parameters and a
  Poisson GLM basis. The main function is init_historyMatching_poissonGlmBasis.
  Other functions in this file are auxililary functions for init_historyMatching_poissonGlmBasis.
"""
# Python libraries (native, 3rd party)
import pandas
import copy
import warnings



# Python libraries (internal)
from phylomodels.calibration.init_historyMatching_base    \
     import init_historyMatching_base




#-------------------------------------------------------------------------------
#   init_historyMatching_poissonGlmBasis
#-------------------------------------------------------------------------------
def init_historyMatching_poissonGlmBasis( xInfo  : pandas.DataFrame,
                                          y      : pandas.DataFrame,
                                          model,
                                          label,
                                          params
                                         ):
    """
    Run a history matching job with a basic configuration for the emulator that
    uses a Poisson GLM basis. The emulator model uses a first order polynomial
    basis.

    Args:
     xInfo  : Name and range of model parameters. This is a pandas dataframe.
              The columns of xInfo are: "Name", "Min", and "Max", which refer
              to the name of a parameter, its lower bound, and its upper bound,
              respectively. Each row of xInfo contains information of one
              model parameter.
     y      : Observations. This is a pandas dataframe of the same
              characteristics of the model output.
     model  : Pointer to the model wrapper (or subroutine).
     label  : Short string identifying the history matching job. This argument
              may be used for naming the results directory, files, and text in
              plots.
     params : History matching parameters. This is a python dictionary that can
              be used for setting other parameters history matching parameters.
              The parameters that can be defined in params are (please refer to
              the history matching library documentation for description of
              history matching library parameters):

                [history matching library parameters]
                  * cut_name
                  * implausibility_threshold
                  * observation_uncertainty
                  * max_rejection_rate
                  * max_iter
                  * model_discrepancy
                  * n_candidates
                  * training_fraction

                [others]

                  relative_model_uncertainty
                    (optional) Factor used for
                    computing model_uncertainty. If provided,
                    model_uncertainty is computed, for each
                    simulation, as the value returned by the model
                    multiplied by this parameter.
                  relative_obs_uncertainty
                    (optional) Factor used for
                    computing observation_uncertainty. If provided,
                    observation_uncertainty is computed as the value
                    of the observation multiplied by this parameter.
                  restart_dir
                    (optional) Path to directory with previous
                    calibration job to be restarted/continued with
                    this call to init_historyMatching_base().
    """

    # Add Poisson basis to params
    if "glm_family" in params.keys():
        glmFamilyInParams = params.get("glm_family")
        if glmFamilyInParams != "Poisson":
            warnings.warn( "glm_family will be updated to Poisson "         +  \
                           "(user indicated glm_family = "                  +  \
                           glmFamilyInParams                                +  \
                           " but called "                                   +  \
                           "init_historyMatching_poissonGlmBasis(), which " +  \
                           "forces the use of Poisson basis)"
                          )

    paramsInternal = copy.deepcopy( params )
    paramsInternal.update( { "glm_family" : "Poisson" } )

    # Call generic history matching function
    x = init_historyMatching_base( xInfo, y, model, label, paramsInternal )

    # Finalize and return
    return x
#
#   End of init_historyMatching_poissonGlmBasis
#-------------------------------------------------------------------------------
