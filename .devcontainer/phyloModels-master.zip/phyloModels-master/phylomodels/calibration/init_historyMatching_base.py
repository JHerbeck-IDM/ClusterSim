"""
  Execution of history matching jobs. The main function is
  init_historyMatching_base. Other functions in this file are auxililary
  functions for init_historyMatching_base.
"""
# Python libraries (native, 3rd party)
import numpy
import pandas
import copy
import logging
import warnings
import re
import os
import sys
import time
import datetime
import matplotlib
from   matplotlib import pyplot as plt
from sys import platform

"""
if platform == "linux" or platform == "linux2":
    #print('Linux OS. Using non-interactive Agg backend')
    matplotlib.use('Agg')
else:
    matplotlib.use('TKAgg')
"""


from pyDOE              import lhs
from distutils.dir_util import copy_tree


# Python libraries (internal)
import phylomodels.calibration.constants as constants

from phylomodels.features.features import features
from phylomodels.calibration.init_historyMatching.historyMatchingIteration \
     import historyMatchingIteration




#-------------------------------------------------------------------------------
#   init_historyMatching_base
#-------------------------------------------------------------------------------
def init_historyMatching_base( xInfo  : pandas.DataFrame,
                               y      : pandas.DataFrame,
                               model,
                               label,
                               params
                              ):
    """
    Run a history matching job with a basic configuration for the emulator that
    uses a Poisson GLM basis. The emulator model uses a first order polynomial
    basis.

    Args:
     xInfo  : Name and range of model parameters. This is a pandas dataframe.
              The columns of xInfo are: "Name", "Min", and "Max", which refer
              to the name of a parameter, its lower bound, and its upper bound,
              respectively. Each row of xInfo contains information of one
              model parameter.
     y      : Observations. This is a pandas dataframe of the same
              characteristics of the model output.
     model  : Pointer to the model wrapper (or subroutine).
     label  : Short string identifying the history matching job. This argument
              may be used for naming the results directory, files, and text in
              plots.
     params : History matching parameters. This is a python dictionary that can
              be used for setting other parameters history matching parameters.
              The parameters that can be defined in params are (please refer to
              the history matching library documentation for description of
              history matching library parameters):

                [history matching library parameters]
                  * cut_name
                  * implausibility_threshold
                  * observation_uncertainty
                  * max_rejection_rate
                  * max_iter
                  * model_discrepancy
                  * n_candidates
                  * training_fraction

                [others]

                  relative_model_uncertainty
                    (optional) Factor used for
                    computing model_uncertainty. If provided,
                    model_uncertainty is computed, for each
                    simulation, as the value returned by the model
                    multiplied by this parameter.

                  relative_obs_uncertainty
                    (optional) Factor used for
                    computing observation_uncertainty. If provided,
                    observation_uncertainty is computed as the value
                    of the observation multiplied by this parameter.
                  restart_dir
                    (optional) Path to directory with previous
                    calibration job to be restarted/continued with
                    this call to init_historyMatching_base().
    """

    # Initialization
    validateInputs( xInfo, y, model, params )
    hmParams = setHistoryMatchingParameters( params )
    initializeOutputDirectory( label, hmParams, xInfo )
    featureSelectionMetric = hmParams.get("feature_selection_metric")
    featurePool = hmParams.get("feature_pool")
    if "restart_dir" in hmParams.keys():
        xInitFile, \
        lastIter       = restorePreviousSession( hmParams.get("restart_dir") )
        newJob = False
    else:
        newJob = True


    # Get initial candidates
    if ( newJob == True ):
        x = getInitialCandidatesLHS( xInfo, hmParams.get("n_candidates") )
    else:
        x = getInitialCandidatesFromFile( xInfo, xInitFile )


    # Get ready for history matching iterations
    xInfo_trimmed, x_trimmed = trimParameters( xInfo, x )   # Remove parameters
                                                            # whose range is 0
                                                            # (i.e., where
                                                            # xmin = xmax)

    y_features, y_featureStats = getFeatures( x=y,
                                              xref=y,
                                              featurePool=featurePool
                                             )
    logging.debug( "%s\n%s", "y_features:", y_features )


    # History matching iterations
    if ( newJob == True ):
        i = 0
    else:
        i = lastIter

    while ( i < hmParams.get("max_iter") ):

        print( "... History matching iteration ", i,
               " (max_iter = ", hmParams.get("max_iter"), "\b)" )
        logging.debug( "%s %d", "Iteration", i )
        hmErrorCount = 0
        tic_iter = time.time()


        # Run model simulations and extract features
        plotParameters( i, x_trimmed, xInfo )

        ySim = model(x)
        plotSimulations( i, y, ySim )
        logging.debug( "%s\n%s", "ySim", ySim )

        ySim_features, ySim_featureStats = getFeatures( x=ySim,
                                                        xref=y,
                                                        featurePool=featurePool
                                                       )
        logging.debug( "%s\n%s", "ySim_features",     ySim_features     )
        logging.debug( "%s\n%s", "ySim_featureStats", ySim_featureStats )


        # Select target feature
        targetForHistoryMatching,         \
        simulationDataForHistoryMatching, \
        selectedFeature                = selectFeatures( y_features,
                                                         ySim_features,
                                                         ySim_featureStats,
                                                         featureSelectionMetric,
                                                         i
                                                        )
        logging.debug( "%s\n%s", "targetForHistoryMatching:",
                       targetForHistoryMatching )
        logging.debug( "%s\n%s", "simulationDataForHistoryMatching:", simulationDataForHistoryMatching )


        # Prepare (format) history matching parameters
        yObservation = float( targetForHistoryMatching )
        yModel = pandas.DataFrame(
                { "Sample_Id" : range(0, len(simulationDataForHistoryMatching)),
                  "Sim_Id"    : range(0, len(simulationDataForHistoryMatching)),
                  "Sim_Result"   : simulationDataForHistoryMatching.values,
                 }
        ).set_index( ["Sample_Id", "Sim_Id"] )["Sim_Result"]

        hmParamsThisIter = validateHistoryMatchingParameters( hmParams,
                                                              yObservation,
                                                              yModel
                                                             )


        # Run history matching iteration
        rejectionRate, status = historyMatchingIteration( i,
                                                          xInfo_trimmed,
                                                          x_trimmed,
                                                          yObservation,
                                                          yModel,
                                                          hmParamsThisIter
                                                         )
        validateHistoryMatchingOutput( i, status )
        if status != constants.SUCCESS:
            continue


        # Get ready for next iteration
        toc_iter = time.time()
        i = i + 1
        del x, x_trimmed
        x_trimmed \
                = pandas.read_csv( os.path.join('Candidates_for_iter%d.csv'%i) )
        x_trimmed.index.name = "Sample_Id"
        x = setConstantParameters( xInfo, x_trimmed )
        updateHistory( i, rejectionRate, selectedFeature, tic_iter, toc_iter )


        # Exit loop if rejection rate achieved
        if ( rejectionRate > hmParams.get("max_rejection_rate") ):
            break


    # Finalize and return
    plotParameters( i, x_trimmed, xInfo )
    print( open("history.txt").read() )
    logging.debug("Leaving init_historyMatching_poissonBasis")
    return x
#
#   End of init_historyMatching_poissonGlmBasis
#-------------------------------------------------------------------------------




#-------------------------------------------------------------------------------
#   validateInputs
#-------------------------------------------------------------------------------
def validateInputs( xInfo, y, model, params ):
    """
      Placeholder for input validation. It logs input arguments when debug mode
      is used.
    """

    logging.debug( "Entering init_historyMatching_poissonBasis" )
    logging.debug( "%s\n%s", "xInfo:" , xInfo     )
    logging.debug( "%s\n%s", "y:"     , y         )
    logging.debug( "%s %s" , "model:" , model     )
    logging.debug( "%s %s" , "params:", params    )

    return




#-------------------------------------------------------------------------------
#   setHistoryMatchingParameters
#-------------------------------------------------------------------------------
def setHistoryMatchingParameters( params ):
    """
      Build dictionary with history matching parameters based on defaults and
      user arguments.
    """

    # Set defaults
    hmParams = {}
    hmParams.update( { "model_discrepancy"        : 1    } )
    hmParams.update( { "observation_uncertainty"  : 1    } )
    hmParams.update( { "max_rejection_rate"       : 99   } )
    hmParams.update( { "max_iter"                 : 10   } )
    hmParams.update( { "n_candidates"             : 1000 } )
    hmParams.update( { "implausibility_threshold" : 3    } )
    hmParams.update( { "training_fraction"        : 0.80 } )
    hmParams.update( { "glm_family"               : "Gaussian"             } )
    hmParams.update( { "cut_name"                 : "history_matching_cut" } )
    hmParams.update( { "feature_selection_metric" : "fano"                 } )

    # Overwrite defaults with values in params
    for key, value in params.items():
        hmParams.update( { key : value } )

    # Finalize and return
    logging.debug( "%s %s", "History matching parameters (hmParams):", hmParams)
    return hmParams




#-------------------------------------------------------------------------------
#   validateHistoryMatchingParameters
#-------------------------------------------------------------------------------
def validateHistoryMatchingParameters( params, yObservation, yModel ):

    # Initialize output parameter dictionary
    updatedParams =copy.deepcopy( params )


    # Update/validate observation uncertainty
    if "relative_obs_uncertainty" in params.keys():
        observationUncertainty = params.get("relative_obs_uncertainty")  \
                                 * abs( yObservation )
        updatedParams.update( \
                       { "observation_uncertainty"  : observationUncertainty } )
        logging.debug( "%s %s", "observation_uncertainty set to ",
                       observationUncertainty
                      )


    # Update/validate model uncertainty
    if "relative_model_discrepancy" in params.keys():
        modelUncertainty = params.get("relative_model_discrepancy")  \
                           * abs( yObservation )
        updatedParams.update( { "model_discrepancy"  : modelUncertainty    } )
        logging.debug( "%s %s", "model_discrepancy set to ", modelUncertainty )


    # Validate GLM basis
    if "glm_family" in params.keys():
        glmFamily = params.get("glm_family")

        if glmFamily == "Poisson":   # Both observation and model data
                                     # must be nonnegative

            usePoisson = True  # This flag will switch to false if potential
                               # issues are detected for the use of Poisson
                               # GLM basis

            if ( yModel.to_numpy() < 0 ).any():
                warnings.warn( "Negative value found in simulation "         + \
                               "results. Poisson GLM basis cannot be used. " + \
                               "Switching to Gaussian basis."
                              )
                usePoisson = False

            if ( yObservation < 0 ):
                warnings.warn( "Negative value found in observation. "       + \
                               "Poisson GLM basis cannot be used. " + \
                               "Switching to Gaussian basis."
                              )
                usePoisson = False

            if usePoisson == False:
                updatedParams.update( { "glm_family" : "Gaussian" } )


    # Finalize and return
    return updatedParams




#-------------------------------------------------------------------------------
#   initializeOutputDirectory
#-------------------------------------------------------------------------------
def initializeOutputDirectory( label, params, xInfo ):
    """
      Creates and moves to a new directory for saving results and other
      information from the history matching run..
    """

    # Create output directory and move to main subdirectory
    timestamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    path      = os.path.dirname( sys.argv[0] )
    fullPath  = os.path.abspath( path )
    newPath   = fullPath + "/" + label + "--" + timestamp
    os.makedirs( newPath )
    os.chdir ( newPath )
    os.makedirs( "./main" )
    os.chdir( "./main" )

    # Save file with job information
    filename = "parameters_init_historyMatching.txt"
    with open( filename, "w" ) as initialFile:
        jobIdString = "Job ID (label):" + label + "\n\n"
        timestampString = "Timestamp: " + timestamp + "\n\n"
        initialFile.write( jobIdString )
        initialFile.write( timestampString  )
        initialFile.write( "Model parameter space (xInfo):\n" )
        initialFile.write( xInfo.to_string() )
        initialFile.write( "\n\n" )
        initialFile.write( "params:\n" )
        for key, value in params.items():
            paramString = "  " + str(key) + " : " + str(value) + "\n"
            initialFile.write( paramString )


    # Initialize history file
    filename = "history.txt"
    with open( filename, "w" ) as historyFile:
        historyFile.write( \
                    "Iteration  \t  Rejection  \t Selected \t Time (s) \n"   )
        historyFile.write( \
                    "           \t  Rate (%)   \t Feature  \t          \n\n" )

    # Finalize and return
    logging.debug( "%s %s", "New directory created: ", newPath )
    return




#-------------------------------------------------------------------------------
#   restorePreviousSession
#-------------------------------------------------------------------------------
def restorePreviousSession( restartDir ):

    # Initialization
    logging.info( "%s %s", "Restoring session from ", restartDir )
    currentPath = os.getcwd( )

    # Copy last session to current path
    copy_tree( restartDir, currentPath + "/../" )

    # Identify last iteration and its corresponding candidates
    candidatesFilePattern = currentPath + "/Candidates_for_iter*"
    allFilesInCurrentPath = os.listdir( currentPath )
    lastIter  = 0
    xInitFile = None
    for file in allFilesInCurrentPath:
        match = re.search( "Candidates_for_iter(\d+)\.csv", file )
        if ( match != None ):
            iter = int( match.group(1) )
            if ( iter >= lastIter ):
                lastIter  = iter
                xInitFile = file

    # Finalize and return
    logging.info( "%s %s", "lastIter  = ", lastIter )
    logging.info( "%s %s", "xInitFile = ", xInitFile )
    return xInitFile, lastIter




#-------------------------------------------------------------------------------
#   updateHistory
#-------------------------------------------------------------------------------
def updateHistory( iteration,
                   rejectionRate,
                   selectedFeature,
                   tic_iter,
                   toc_iter
                  ):
    """
      Write summary information about the progress of the init calibration job
      in the history file.
    """

    filename = "history.txt"
    with open( filename, "a" ) as historyFile:
        summaryString = "    " + str(iteration)                              \
                        + "\t\t" + "{:.4f}".format( rejectionRate )          \
                        + "\t\t" + selectedFeature                           \
                        + "\t\t" + "{:.2f}".format( toc_iter - tic_iter )    \
                        + "\n"
        historyFile.write( summaryString )

    return




#-------------------------------------------------------------------------------
#   getInitialCandidates
#-------------------------------------------------------------------------------
def getInitialCandidatesLHS( xInfo, N ):
    """
      Return a dataframe with a set of uniformly sampled parameters.
    """

    # Initialize informational variables
    cols = xInfo.index.values
    nParams = len(cols)

    # Generate random samples
    x = pandas.DataFrame( lhs(nParams, N), columns=cols )
    x.index.name = "Sample_Id" # This index name is required by history matching

    # Scale samples to range of parameters
    for i in range(0,nParams):
        name   = xInfo.index.values[i]
        min    = xInfo["Min"][i]
        max    = xInfo["Max"][i]
        irange = max - min
        x.loc[:,name] = min + irange*x.loc[:,name]

    # Finalize and return
    logging.debug( "%s\n%s",
                   "Initial non-implausible candidates for History Matching:",
                   x
                  )
    return x




#-------------------------------------------------------------------------------
#   getInitialCandidatesFromFile
#-------------------------------------------------------------------------------
def getInitialCandidatesFromFile( xInfo, filename ):
    """
      Return a dataframe with a set of parameters read from a csv file.
    """

    # Read parameters from file
    x = pandas.read_csv( filename )
    x.index.name = "Sample_Id" # Name required by history matching
    logging.debug( "%s %s", "Initial parameters read from file ", filename )
    n = len(x)

    # Complete parameter set with constant values
    for index, row in xInfo.iterrows():
        xmin = row["Min"]
        xmax = row["Max"]
        if (xmin==xmax) and (not index in x.columns):
            x[index] = numpy.full( n, xmin )

    # Finalize and return
    return x




#-------------------------------------------------------------------------------
#   trimParameters
#-------------------------------------------------------------------------------
def trimParameters( xInfo, x ):
    """
      Remove parameters whose range is 0 (i.e., where xmin = xmax). History
      matching does not work with this type of interval.
    """

    # Initialize output dataframes
    xInfo_trimmed = xInfo.copy()
    x_trimmed     = x.copy()

    # Delete unnecessary entries
    for index, row in xInfo.iterrows():
        xmin = row["Min"]
        xmax = row["Max"]
        if (xmin == xmax):
            logging.debug(  \
                   "%s %s", "Dropping as model parameter for history matching:",
                   index
            )
            xInfo_trimmed.drop( index, inplace=True )
            x_trimmed.drop( index, axis=1, inplace=True )

    # Finalize and return
    return xInfo_trimmed, x_trimmed




#-------------------------------------------------------------------------------
#   setConstantParameters
#-------------------------------------------------------------------------------
def setConstantParameters( xInfo, x_trimmed ):
    """
      Restore constant parameters (i.e., those whose range is 0) that are not
      generated as candidates by history matching. These parameters are needed
      for the correct execution of model simulations.
    """

    # Initialize output dataframe
    x = x_trimmed.copy()

    # Add columns with constant parameters
    for index, row in xInfo.iterrows():
        xmin = row["Min"]
        xmax = row["Max"]
        if (xmin == xmax):
            logging.debug( "%s %s","Restoring parameter for model simulations:",
                           index
                          )
            x[index] = pandas.Series( [xmin for i in range( len(x.index) )],
                                      index=x.index
                                     )

    # Finalize and return
    return x




#-------------------------------------------------------------------------------
#   plotParameters
#-------------------------------------------------------------------------------
def plotParameters( iteration, x_trimmed, xInfo ):
    """
      Generate and save plots with model parameter candidates.
    """

    # Open figure
    fig, (ax1) = plt.subplots(1,1)

    # Plot scatter matrix
    nBins = 25
    pandas.plotting.scatter_matrix( x_trimmed,
                                    alpha      = 1,
                                    #ax         = ax1,
                                    marker     = ".",
                                    grid       = True,
                                    hist_kwds  = { "bins"     : nBins,
                                                   "density"  : True,
                                                   "histtype" : "step"
                                                  }
                                   )

    # Save figure
    fig.tight_layout()
    filename = "parameters_iter_" + str(iteration) + ".png"
    plt.savefig( filename, bbox_inches="tight", dpi=250 )

    # Save parameter data
    filename_csv = "parameters_data_iter_" + str(iteration) + ".csv"
    x_trimmed.to_csv( filename_csv )

    # Finalize and return
    plt.close()
    plt.close(fig)
    return




#-------------------------------------------------------------------------------
#   plotSimulations
#-------------------------------------------------------------------------------
def plotSimulations( iteration, y, ySim ):
    """
      Generate and save plots with simulation and observation results.
    """

    # Open figure
    fig, (ax1, ax2) = plt.subplots(2,1)

    # Plot observations
    y.transpose().plot( ax     = ax1,
                        title  = "Observations",
                        legend = False
                       )

    # Plot simulations
    ySim.transpose().plot( ax     = ax2,
                           title  = "Simulations",
                           legend = False,
                           colormap = "nipy_spectral"
                          )

    # Save figure
    fig.tight_layout()
    filename = "simulations_iter_" + str(iteration) + ".png"
    plt.savefig( filename, bbox_inches="tight", dpi=250 )

    # Save simulation data
    filename_csv = "simulations_data_iter_" + str(iteration) + ".csv"
    ySim.to_csv( filename_csv )

    # Finalize and return
    plt.close(fig)
    return




#-------------------------------------------------------------------------------
#   validateHistoryMatchingOutput
#-------------------------------------------------------------------------------
def validateHistoryMatchingOutput( i, status ):

    # Init: Need to keep track of unsuccessful attempts, so we create a
    # "static variable" for that.
    validateHistoryMatchingOutput.__dict__.setdefault( "attempts", 0 )


    # Update count of unsuccessful attempts (and reset to 0 if successful trial)
    if status != constants.SUCCESS:
        validateHistoryMatchingOutput.attempts \
                                    = validateHistoryMatchingOutput.attempts + 1

        # Need to rename folder created by history matching
        oldDir = os.path.join( os.getcwd(), "../iter" + str(i) )
        for j in range(1, constants.HISTORY_MATCHING__MAX_TRIALS + 1):
            newDir = oldDir +  "-trial" + str(j)
            if not os.path.isdir( newDir ):
                os.rename( oldDir, newDir )
                break

    else:
        validateHistoryMatchingOutput.attempts = 0

    # Raise error if tolerance for unsuccessful attempts is reached
    if ( validateHistoryMatchingOutput.attempts \
         > constants.HISTORY_MATCHING__MAX_TRIALS ):

        raise RuntimeError( "Multiple exceptions occurred during " +   \
                            "the execution of history matching. "  +   \
                            "Calibration process aborted:\n"           \
                           )

    # Finalize and return
    return




#-------------------------------------------------------------------------------
#   getFeatures
#-------------------------------------------------------------------------------
def getFeatures( x, xref, featurePool ):
    """
      Compute and return selected features from the input data.
    """

    # Instantiate features class and select features to compute
    f = features( x=x, xref=xref )
    f.disableFeature( group = "all" )

    if featurePool:   # User-listed features
        for i in range(0, len(featurePool)):
            logging.debug( "%s %s", "enabling feature: ", featurePool[i] )
            f.enableFeature( name = featurePool[i] )

    else: # Default features
        logging.debug( "enabling default features" )
        f.enableFeature( name = "series"            )
        f.enableFeature( name = "series_sum"        )
        f.enableFeature( name = "series_sum_log10"  )
        f.enableFeature( name = "series_derivative" )
        f.enableFeature( name = "series_diff_L1"    )
        f.enableFeature( name = "Series_diff_Linf"  )


    # Compute features and statistics
    ySim_features, ySim_featureStats = f.compute()

    # Finalize and return
    return ySim_features, ySim_featureStats




#-------------------------------------------------------------------------------
#   selectFeatures
#-------------------------------------------------------------------------------
def selectFeatures( fref, f, fStats, metric, iteration ):
    """
      Select target feature for history matching.
    """

    # Init: Need to keep track of features that have been selected. This
    # initializes a "static variable" called to do that.
    selectFeatures.__dict__.setdefault( "featuresUsed", [] )
    quarantinePeriod = constants.FEATURE_SELECTION__QUARANTINE_PERIOD # Number
                                 # of iterations that we should wait before
                                 # selecting a feature again
    closeCorrelationThreshold \
                      = constants.FEATURE_SELECTION__CLOSE_CORRELATION_THRESHOLD
                                 # Do not select features that are highly
                                 # correlated with quarantined features


    # Select feature
    unsortedFeatureSelectionMetric = -numpy.abs( fStats[metric].values )
    sortedFeatureIndex = numpy.argsort( unsortedFeatureSelectionMetric )
    logging.debug( "%s %s", "unsortedFeatureSelectionMetric",
                            str(unsortedFeatureSelectionMetric)
                  )
    logging.debug( "%s %s", "sortedFeatureIndex =", str(sortedFeatureIndex) )

    nFeatures = len( f.columns )
    for i in range(0, nFeatures):
        incumbentIndex = i
        incumbentLoc = sortedFeatureIndex[incumbentIndex]

        # Check that feature stats are neither NaN nor Inf (which would be the
        # last indices in sortedFeatureIndex
        if not numpy.isfinite( unsortedFeatureSelectionMetric[incumbentLoc] ):

            warnings.warn( "Unable to find valid feature (stopping search " + \
                           "at position " + str(i) +                          \
                           " of " + str(nFeatures) +                          \
                           " potential features)"                             \
                          )
            incumbentLoc = sortedFeatureIndex[0]
            break

        # Check that feature is not highly correlated with other already in
        # the quarantine list (i.e., with a recently-selected feature)
        acceptIncumbent = True
        incumbentCor = f.corr(method="pearson").iloc[:, incumbentLoc]
        for recentFeature in selectFeatures.featuresUsed:
            if ( f.columns[incumbentLoc] == recentFeature ):
                acceptIncumbent = False

            if ( numpy.abs(incumbentCor.loc[recentFeature]) \
                 > closeCorrelationThreshold
                ):
                acceptIncumbent = False
        if (acceptIncumbent):
            break

    feature = f.columns[incumbentLoc]


    # Extract values for the selected feature
    frefTarget = fref[feature][0]
    fTarget    = f[feature]

    # Update history of selected features
    selectFeatures.featuresUsed.append( feature )
    if (  len( selectFeatures.featuresUsed ) > quarantinePeriod  ):
        selectFeatures.featuresUsed.pop(0)   # Enable features that have not
                                             # been used in a while


    # Finalize and return
    f.to_csv( "features_iter_" + str(iteration) + ".csv" )
    fStats.to_csv( "featureStats_iter_" + str(iteration) + ".csv" )
    logging.debug( "%s %s", "Target feature selected for history matching:",
                   feature
                  )
    logging.debug( "%s %s", "Features used: ", str(selectFeatures.featuresUsed) )
    return frefTarget, fTarget, feature


