###############
Getting started
###############


.. toctree::

   overview
   introduction
   generated_rst/notebooks
   generated_rst/pandas
   generated_rst/dplyr
